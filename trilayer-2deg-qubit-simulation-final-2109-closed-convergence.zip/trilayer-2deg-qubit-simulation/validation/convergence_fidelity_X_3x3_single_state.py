#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Convergência numérica da fidelidade da porta X — Hamiltoniano completo 3x3.

OBJETIVO
--------
Responder diretamente ao comentário 2.8 do parecer:

    "É preciso dizer em qual malha F_X foi calculada e dar uma barra de
     erro numérica; caso contrário, o 0,992 não é defensável com três casas."

Este script NÃO usa o modelo efetivo 2x2. A fidelidade é calculada a partir da
propagação completa do Hamiltoniano 3x3 da tricamada:

    H = [[U1, Delta12, 0],
         [Delta12, U2, Delta23],
         [0, Delta23, U3]]

na simulação coerente da porta X (V0 = 0).

A perturbação espacial V(r), usada posteriormente no estudo de dephasing, NÃO
entra nesta convergência da fidelidade da porta X. Assim se evita misturar o
benchmark da porta com a análise de inhomogeneous broadening.

A "barra de erro" aqui é uma ESTIMATIVA DETERMINÍSTICA DE CONVERGÊNCIA:
para a malha de produção (N=384, dt=0.5 fs), comparamos F_X com uma execução
refinada (N_ref, dt_ref). Ela não é erro estatístico nem um intervalo formal
de truncamento; é a diferença entre a configuração de produção e a
configuração numericamente refinada.

Também são reportadas separadamente:
    delta_F_spatial = |F_X(384,0.5) - F_X(512,0.5)|
    delta_F_temporal = |F_X(384,0.5) - F_X(384,0.25)|
    delta_F_ref = |F_X(384,0.5) - F_X(512,0.25)|

Além disso, o script verifica explicitamente que, no resultado final,
1-F_X NÃO deve ser identificado com P2_max. Para o instante t_X,

    1-F_X = P1(t_X) + P2(t_X),

pois a norma total é P1+P2+P3=1 e F_X=P3 para a entrada |1> e alvo |3>.
"""

from __future__ import annotations

import argparse
import csv
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np


# =============================================================================
# PARÂMETROS FÍSICOS FINAIS DO PAPER
# =============================================================================

@dataclass(frozen=True)
class PhysicalParameters:
    hbar_ev_s: float = 6.58211928e-16
    e_charge_c: float = 1.602176634e-19
    m_e_kg: float = 9.1093837015e-31

    m_eff_factor: float = 0.067

    Delta12: float = 0.005      # eV = 5 meV
    Delta23: float = 0.005      # eV = 5 meV
    Delta13: float = 0.0        # eV

    U1: float = 0.0             # eV
    U2: float = 0.100           # eV = 100 meV
    U3: float = 0.0             # eV

    # IMPORTANTE: convergência da fidelidade da porta X é feita com V=0.
    V0: float = 0.0

    sigma_nm: float = 15.0
    k0_nm_inv: float = 0.0


@dataclass(frozen=True)
class NumericalParameters:
    # Caixa final usada no paper
    W_nm: float = 1200.0

    # Configuração de produção do paper
    N_prod: int = 384
    dt_prod_fs: float = 0.5

    # Refinamento usado para a barra de erro
    N_ref: int = 512
    dt_ref_fs: float = 0.25

    # Resolução auxiliar para os sweeps
    N_spatial: Tuple[int, ...] = (256, 320, 384, 448, 512)
    dt_temporal_fs: Tuple[float, ...] = (1.0, 0.5, 0.25)

    # Diagnóstico
    edge_margin_nm: float = 20.0


# =============================================================================
# CONSTANTES / CONVERSÕES
# =============================================================================

def hbar_ev_fs(phys: PhysicalParameters) -> float:
    return phys.hbar_ev_s * 1.0e15


def kinetic_coefficient_ev_nm2(phys: PhysicalParameters) -> float:
    """hbar^2/(2m*) em eV nm^2, com conversão SI consistente."""
    m_eff = phys.m_eff_factor * phys.m_e_kg
    hbar_j_s = phys.hbar_ev_s * phys.e_charge_c
    return hbar_j_s**2 * 1.0e18 / (2.0 * m_eff * phys.e_charge_c)


def effective_parameters(phys: PhysicalParameters) -> Dict[str, float]:
    J_signed = -(phys.Delta12 * phys.Delta23) / phys.U2
    J_abs = abs(J_signed)
    tX_theory_fs = np.pi * phys.hbar_ev_s / (2.0 * J_abs) * 1.0e15
    T_eff_fs = 2.0 * tX_theory_fs
    Omega_eff_fs_inv = 2.0 * J_abs / hbar_ev_fs(phys)
    return {
        "J_signed_meV": J_signed * 1000.0,
        "J_abs_meV": J_abs * 1000.0,
        "tX_theory_fs": tX_theory_fs,
        "T_eff_fs": T_eff_fs,
        "Omega_eff_fs_inv": Omega_eff_fs_inv,
    }


# =============================================================================
# GRADE / PACOTE
# =============================================================================

def make_grid(N: int, W_nm: float):
    dx = W_nm / N
    x = -W_nm / 2.0 + np.arange(N) * dx
    y = x.copy()
    X, Y = np.meshgrid(x, y, indexing="ij")

    kx = 2.0 * np.pi * np.fft.fftfreq(N, d=dx)
    ky = 2.0 * np.pi * np.fft.fftfreq(N, d=dx)
    KX, KY = np.meshgrid(kx, ky, indexing="ij")
    K2 = KX**2 + KY**2

    return x, y, X, Y, dx, K2


def initial_wavepacket(
    X: np.ndarray,
    Y: np.ndarray,
    sigma_nm: float,
    k0_nm_inv: float,
    dx: float,
) -> np.ndarray:
    psi = np.exp(
        -(X**2 + Y**2) / (2.0 * sigma_nm**2)
        + 1j * k0_nm_inv * X
    ).astype(np.complex128)
    norm = np.sum(np.abs(psi) ** 2) * dx * dx
    psi /= np.sqrt(norm)
    return psi


# =============================================================================
# HAMILTONIANO COMPLETO 3x3
# =============================================================================

def build_full_3x3_hamiltonian(phys: PhysicalParameters) -> np.ndarray:
    """Hamiltoniano de camada COMPLETO 3x3 para a etapa coerente V0=0."""
    H = np.array(
        [
            [phys.U1, phys.Delta12, phys.Delta13],
            [phys.Delta12, phys.U2, phys.Delta23],
            [phys.Delta13, phys.Delta23, phys.U3],
        ],
        dtype=np.complex128,
    )
    return H


def build_local_propagator_3x3(
    phys: PhysicalParameters,
    dt_fs: float,
) -> np.ndarray:
    H = build_full_3x3_hamiltonian(phys)
    eigvals, eigvecs = np.linalg.eigh(H)
    phases = np.exp(-1j * eigvals * dt_fs / hbar_ev_fs(phys))
    U = eigvecs @ np.diag(phases) @ np.conjugate(eigvecs).T
    return U


# =============================================================================
# PASSO CINÉTICO
# =============================================================================

def kinetic_half_step(
    Psi: np.ndarray,
    T_half: np.ndarray,
) -> np.ndarray:
    Psi_k = np.fft.fft2(Psi, axes=(-2, -1))
    Psi_k *= T_half[None, :, :]
    return np.fft.ifft2(Psi_k, axes=(-2, -1))


# =============================================================================
# DIAGNÓSTICOS
# =============================================================================

def reduced_density_matrix(Psi: np.ndarray, dx: float) -> np.ndarray:
    return np.einsum(
        "ixy,jxy->ij",
        Psi,
        np.conjugate(Psi),
        optimize=True,
    ) * dx * dx


def edge_probability(Psi: np.ndarray, X: np.ndarray, Y: np.ndarray, dx: float, margin: float) -> float:
    outside = (
        (np.abs(X) > (np.max(np.abs(X)) - margin))
        | (np.abs(Y) > (np.max(np.abs(Y)) - margin))
    )
    return float(np.sum(np.abs(Psi) ** 2 * outside[None, :, :]) * dx * dx)


# =============================================================================
# SIMULAÇÃO COMPLETA 3x3 PARA F_X
# =============================================================================

def simulate_FX(
    phys: PhysicalParameters,
    N: int,
    dt_fs: float,
    W_nm: float,
    edge_margin_nm: float,
    target_t_fs: float | None = None,
    progress: bool = True,
) -> Dict[str, float]:
    """
    Entrada: |1> (índice 0), alvo: |3> (índice 2).
    Propaga o Hamiltoniano completo 3x3 até t_X numérico.
    """
    if abs(phys.V0) > 0.0:
        raise ValueError("Esta rotina de convergência da porta X exige V0=0.")

    eff = effective_parameters(phys)
    tX_theory = eff["tX_theory_fs"]
    if target_t_fs is None:
        target_t_fs = int(round(tX_theory / dt_fs)) * dt_fs
    if target_t_fs <= 0.0:
        raise ValueError("target_t_fs deve ser positivo.")

    _, _, X, Y, dx, K2 = make_grid(N, W_nm)

    phi0 = initial_wavepacket(
        X,
        Y,
        phys.sigma_nm,
        phys.k0_nm_inv,
        dx,
    )

    initial_norm = float(np.sum(np.abs(phi0) ** 2) * dx * dx)

    # Estado de camada inicial |1>
    Psi = np.zeros((3, N, N), dtype=np.complex128)
    Psi[0] = phi0

    coeff = kinetic_coefficient_ev_nm2(phys)

    # Todas as malhas são comparadas no MESMO instante físico. Isso evita
    # contaminar a estimativa temporal com a diferença entre 4135.5 fs e
    # 4135.75 fs, por exemplo. A produção usa exatamente 4135.5 fs.
    n_full = int(np.floor(target_t_fs / dt_fs + 1e-12))
    remainder = float(target_t_fs - n_full * dt_fs)
    if abs(remainder) < 1e-10:
        remainder = 0.0
    total_steps = n_full + (1 if remainder > 0.0 else 0)

    def propagate_one_step(Psi_local: np.ndarray, step_dt_fs: float) -> np.ndarray:
        T_half_local = np.exp(
            -1j * coeff * K2 * step_dt_fs / (2.0 * hbar_ev_fs(phys))
        )
        U_local_local = build_local_propagator_3x3(phys, step_dt_fs)
        Psi_local = kinetic_half_step(Psi_local, T_half_local)
        Psi_local = np.einsum(
            "ab,bxy->axy",
            U_local_local,
            Psi_local,
            optimize=True,
        )
        Psi_local = kinetic_half_step(Psi_local, T_half_local)
        return Psi_local, U_local_local

    # Verificação de unitariedade local no dt nominal.
    U_local = build_local_propagator_3x3(phys, dt_fs)
    unitary_err = float(
        np.max(np.abs(U_local.conjugate().T @ U_local - np.eye(3)))
    )

    norm_error_max = 0.0
    P2_max = 0.0
    edge_at_tX = 0.0

    t0 = time.perf_counter()
    report_every = max(1, total_steps // 20)
    elapsed_fs = 0.0

    for step in range(1, total_steps + 1):
        step_dt = dt_fs if step <= n_full else remainder
        Psi, _ = propagate_one_step(Psi, step_dt)
        elapsed_fs += step_dt

        norm = float(np.sum(np.abs(Psi) ** 2) * dx * dx)
        norm_error_max = max(norm_error_max, abs(norm - 1.0))

        P2_step = float(np.sum(np.abs(Psi[1]) ** 2) * dx * dx)
        P2_max = max(P2_max, P2_step)

        if progress and (step % report_every == 0 or step == total_steps):
            frac = step / total_steps
            elapsed = time.perf_counter() - t0
            eta = elapsed * (1.0 - frac) / frac
            print(
                f"  [{100*frac:6.1f}%] t={elapsed_fs:9.2f} fs "
                f"| ETA={eta:8.1f} s",
                flush=True,
            )

    tX_numeric = elapsed_fs

    runtime_s = time.perf_counter() - t0

    rho3 = reduced_density_matrix(Psi, dx)
    P1 = float(np.real(rho3[0, 0]))
    P2 = float(np.real(rho3[1, 1]))
    P3 = float(np.real(rho3[2, 2]))
    F_X = P3
    infidelity = 1.0 - F_X
    rho_trace = float(np.real(np.trace(rho3)))

    edge_at_tX = edge_probability(
        Psi,
        X,
        Y,
        dx,
        edge_margin_nm,
    )

    # Identidade física do benchmark |1> -> |3>
    decomposition_residual = abs(infidelity - (P1 + P2))

    return {
        "N": float(N),
        "dt_fs": float(dt_fs),
        "dx_nm": float(dx),
        "W_nm": float(W_nm),
        "nsteps": float(total_steps),
        "tX_theory_fs": float(tX_theory),
        "tX_numeric_fs": float(tX_numeric),
        "F_X": float(F_X),
        "infidelity": float(infidelity),
        "P1_tX": P1,
        "P2_tX": P2,
        "P3_tX": P3,
        "P2_max": float(P2_max),
        "rho_trace_tX": rho_trace,
        "norm_error_max": float(norm_error_max),
        "unitary_local_error": unitary_err,
        "edge_probability_tX": float(edge_at_tX),
        "decomposition_residual": float(decomposition_residual),
        "runtime_s": float(runtime_s),
        "initial_norm": initial_norm,
    }


# =============================================================================
# SWEEPS
# =============================================================================

def run_spatial_sweep(
    phys: PhysicalParameters,
    num: NumericalParameters,
    output_dir: Path,
) -> List[Dict[str, float]]:
    print("\n" + "=" * 96)
    print("CONVERGÊNCIA ESPACIAL — HAMILTONIANO COMPLETO 3x3")
    print("=" * 96)
    print(f"W = {num.W_nm:.1f} nm | dt = {num.dt_prod_fs:.3f} fs")

    rows = []
    for N in num.N_spatial:
        print(f"\n--- N = {N} ({N}x{N}) ---")
        row = simulate_FX(
            phys,
            N=N,
            dt_fs=num.dt_prod_fs,
            W_nm=num.W_nm,
            edge_margin_nm=num.edge_margin_nm,
            target_t_fs=(int(round(effective_parameters(phys)["tX_theory_fs"] / num.dt_prod_fs)) * num.dt_prod_fs),
        )
        rows.append(row)
        print(
            f"F_X={row['F_X']:.12f} | 1-F={row['infidelity']:.6e} | "
            f"P2(tX)={row['P2_tX']:.6e} | P2max={row['P2_max']:.6e}"
        )
    return rows


def run_temporal_sweep(
    phys: PhysicalParameters,
    num: NumericalParameters,
    output_dir: Path,
) -> List[Dict[str, float]]:
    print("\n" + "=" * 96)
    print("CONVERGÊNCIA TEMPORAL — HAMILTONIANO COMPLETO 3x3")
    print("=" * 96)
    print(f"N = {num.N_prod} ({num.N_prod}x{num.N_prod}) | W = {num.W_nm:.1f} nm")

    rows = []
    for dt in num.dt_temporal_fs:
        print(f"\n--- dt = {dt:.3f} fs ---")
        row = simulate_FX(
            phys,
            N=num.N_prod,
            dt_fs=dt,
            W_nm=num.W_nm,
            edge_margin_nm=num.edge_margin_nm,
            target_t_fs=(int(round(effective_parameters(phys)["tX_theory_fs"] / num.dt_prod_fs)) * num.dt_prod_fs),
        )
        rows.append(row)
        print(
            f"F_X={row['F_X']:.12f} | 1-F={row['infidelity']:.6e} | "
            f"tX_num={row['tX_numeric_fs']:.3f} fs"
        )
    return rows


def run_reference(
    phys: PhysicalParameters,
    num: NumericalParameters,
) -> Dict[str, float]:
    print("\n" + "=" * 96)
    print("CÁLCULO DE REFERÊNCIA REFINADO PARA A BARRA DE ERRO")
    print("=" * 96)
    print(f"N_ref = {num.N_ref} | dt_ref = {num.dt_ref_fs:.3f} fs")
    return simulate_FX(
        phys,
        N=num.N_ref,
        dt_fs=num.dt_ref_fs,
        W_nm=num.W_nm,
        edge_margin_nm=num.edge_margin_nm,
        target_t_fs=(int(round(effective_parameters(phys)["tX_theory_fs"] / num.dt_prod_fs)) * num.dt_prod_fs),
    )


# =============================================================================
# ANÁLISE DA BARRA DE ERRO
# =============================================================================

def nearest(rows: List[Dict[str, float]], N: int, dt: float) -> Dict[str, float]:
    candidates = [
        r for r in rows
        if int(r["N"]) == int(N) and abs(r["dt_fs"] - dt) < 1e-12
    ]
    if not candidates:
        raise KeyError(f"Não encontrei N={N}, dt={dt} nos resultados.")
    return candidates[0]


def build_analysis(
    spatial: List[Dict[str, float]],
    temporal: List[Dict[str, float]],
    reference: Dict[str, float],
    num: NumericalParameters,
) -> Dict[str, float]:
    production = nearest(temporal, num.N_prod, num.dt_prod_fs)

    # Todas as comparações usam o mesmo instante físico tX da produção.
    spatial_ref_candidates = [
        r for r in spatial if int(r["N"]) == int(num.N_ref)
    ]
    if not spatial_ref_candidates:
        raise KeyError("N_ref não está no sweep espacial.")
    spatial_ref = spatial_ref_candidates[0]

    temporal_ref_candidates = [
        r for r in temporal if abs(r["dt_fs"] - num.dt_ref_fs) < 1e-12
    ]
    if not temporal_ref_candidates:
        raise KeyError("dt_ref não está no sweep temporal.")
    temporal_ref = temporal_ref_candidates[0]

    delta_spatial = abs(production["F_X"] - spatial_ref["F_X"])
    delta_temporal = abs(production["F_X"] - temporal_ref["F_X"])
    delta_reference = abs(production["F_X"] - reference["F_X"])

    # Uma barra conservadora, mas transparente: a maior das duas diferenças
    # unidimensionais em torno da configuração de produção.
    delta_conservative = max(delta_spatial, delta_temporal)

    # Relações úteis para o comentário do parecer.
    I = production["infidelity"]
    P2_tX = production["P2_tX"]
    P2_max = production["P2_max"]
    P1_tX = production["P1_tX"]

    return {
        "F_production": production["F_X"],
        "infidelity_production": I,
        "delta_F_spatial": delta_spatial,
        "delta_F_temporal": delta_temporal,
        "delta_F_reference": delta_reference,
        "delta_F_conservative": delta_conservative,
        "F_reference": reference["F_X"],
        "I_over_delta_reference": I / delta_reference if delta_reference > 0 else np.inf,
        "I_over_delta_conservative": I / delta_conservative if delta_conservative > 0 else np.inf,
        "P1_tX_production": P1_tX,
        "P2_tX_production": P2_tX,
        "P2_max_production": P2_max,
        "P1_fraction_of_infidelity": P1_tX / I if I > 0 else np.nan,
        "P2_fraction_of_infidelity": P2_tX / I if I > 0 else np.nan,
        "P2max_over_infidelity": P2_max / I if I > 0 else np.nan,
        "identity_residual": abs(I - (P1_tX + P2_tX)),
    }


# =============================================================================
# SAÍDAS
# =============================================================================

def save_csv(path: Path, rows: List[Dict[str, float]], extra: Dict[str, float] | None = None):
    if extra is not None:
        rows_to_write = [
            {"type": "summary", "key": k, "value": v}
            for k, v in extra.items()
        ]
        with path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["type", "key", "value"])
            for row in rows_to_write:
                writer.writerow([row["type"], row["key"], row["value"]])
            return

    if not rows:
        return
    keys = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def save_report(
    path: Path,
    phys: PhysicalParameters,
    num: NumericalParameters,
    analysis: Dict[str, float],
    reference: Dict[str, float],
):
    eff = effective_parameters(phys)
    with path.open("w", encoding="utf-8") as f:
        f.write("CONVERGÊNCIA NUMÉRICA DA FIDELIDADE DA PORTA X — HAMILTONIANO 3x3\n")
        f.write("=" * 90 + "\n\n")
        f.write("PARÂMETROS\n")
        f.write("-" * 90 + "\n")
        f.write(f"Delta12 = {phys.Delta12*1000:.6f} meV\n")
        f.write(f"Delta23 = {phys.Delta23*1000:.6f} meV\n")
        f.write(f"U2 = {phys.U2*1000:.6f} meV\n")
        f.write(f"J_signed = {eff['J_signed_meV']:.9f} meV\n")
        f.write(f"|J| = {eff['J_abs_meV']:.9f} meV\n")
        f.write(f"tX_theory = {eff['tX_theory_fs']:.9f} fs\n")
        f.write(f"sigma = {phys.sigma_nm:.6f} nm\n")
        f.write(f"k0 = {phys.k0_nm_inv:.6f} nm^-1\n")
        f.write(f"V0 = {phys.V0*1000:.6f} meV\n")
        f.write(f"W = {num.W_nm:.6f} nm\n")
        f.write(f"produção: N = {num.N_prod}, dt = {num.dt_prod_fs:.6f} fs\n")
        f.write(f"referência: N = {num.N_ref}, dt = {num.dt_ref_fs:.6f} fs\n\n")

        f.write("RESULTADO PRINCIPAL\n")
        f.write("-" * 90 + "\n")
        f.write(f"F_X(produção) = {analysis['F_production']:.12f}\n")
        f.write(f"1-F_X = {analysis['infidelity_production']:.12e}\n")
        f.write(f"F_X(referência refinada) = {analysis['F_reference']:.12f}\n")
        f.write(f"delta_F_spatial = {analysis['delta_F_spatial']:.12e}\n")
        f.write(f"delta_F_temporal = {analysis['delta_F_temporal']:.12e}\n")
        f.write(f"delta_F_reference = {analysis['delta_F_reference']:.12e}\n")
        f.write(f"barra conservadora = {analysis['delta_F_conservative']:.12e}\n\n")

        f.write("DECOMPOSIÇÃO DA INFIDELIDADE EM tX\n")
        f.write("-" * 90 + "\n")
        f.write(f"P1(tX) = {analysis['P1_tX_production']:.12e}\n")
        f.write(f"P2(tX) = {analysis['P2_tX_production']:.12e}\n")
        f.write(f"P2_max = {analysis['P2_max_production']:.12e}\n")
        f.write(f"P1(tX)/[1-F] = {analysis['P1_fraction_of_infidelity']:.8f}\n")
        f.write(f"P2(tX)/[1-F] = {analysis['P2_fraction_of_infidelity']:.8f}\n")
        f.write(f"P2_max/[1-F] = {analysis['P2max_over_infidelity']:.8f}\n")
        f.write(f"|[1-F]-(P1+P2)| = {analysis['identity_residual']:.3e}\n\n")

        f.write("INTERPRETAÇÃO NUMÉRICA\n")
        f.write("-" * 90 + "\n")
        f.write(
            "A barra reportada é uma estimativa determinística baseada na mudança de F_X\n"
            "entre a configuração de produção e cálculos refinados. Ela não é uma incerteza\n"
            "estatística nem um erro formal de truncamento.\n"
        )
        f.write(
            "No benchmark final, P2_max não deve ser usado como estimativa da infidelidade:\n"
            "a relação exata no instante tX é 1-F_X = P1(tX)+P2(tX), pois F_X=P3(tX).\n"
        )


def save_figure(
    output_dir: Path,
    spatial: List[Dict[str, float]],
    temporal: List[Dict[str, float]],
    reference: Dict[str, float],
    analysis: Dict[str, float],
    num: NumericalParameters,
):
    try:
        import matplotlib.pyplot as plt
    except Exception as exc:
        print(f"Matplotlib indisponível; figura não será gerada: {exc}")
        return None

    plt.rcParams.update({
        "font.family": "serif",
        "font.size": 10,
        "axes.labelsize": 10,
        "xtick.labelsize": 9,
        "ytick.labelsize": 9,
        "legend.fontsize": 9,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })

    fig, axes = plt.subplots(1, 2, figsize=(8.0, 3.4))

    # Espaço
    dx = np.array([r["dx_nm"] for r in spatial])
    Fsp = np.array([r["F_X"] for r in spatial])
    axes[0].plot(dx, Fsp, "o-")
    prod_sp = nearest(spatial, num.N_prod, num.dt_prod_fs)
    axes[0].errorbar(
        prod_sp["dx_nm"],
        prod_sp["F_X"],
        yerr=analysis["delta_F_spatial"],
        fmt="none",
        capsize=3.0,
        linewidth=1.0,
    )
    axes[0].axhline(reference["F_X"], linestyle="--", linewidth=1.0, label="refined")
    axes[0].set_xlabel(r"$\Delta x$ (nm)")
    axes[0].set_ylabel(r"$F_X(t_X)$")
    axes[0].invert_xaxis()
    axes[0].legend(frameon=False)

    # Tempo
    dts = np.array([r["dt_fs"] for r in temporal])
    Ft = np.array([r["F_X"] for r in temporal])
    axes[1].plot(dts, Ft, "o-")
    prod_t = nearest(temporal, num.N_prod, num.dt_prod_fs)
    axes[1].errorbar(
        prod_t["dt_fs"],
        prod_t["F_X"],
        yerr=analysis["delta_F_temporal"],
        fmt="none",
        capsize=3.0,
        linewidth=1.0,
    )
    axes[1].axhline(reference["F_X"], linestyle="--", linewidth=1.0, label="refined")
    axes[1].set_xlabel(r"$\Delta t$ (fs)")
    axes[1].set_ylabel(r"$F_X(t_X)$")
    axes[1].legend(frameon=False)

    for ax in axes:
        ax.tick_params(direction="in", top=True, right=True)
        for spine in ax.spines.values():
            spine.set_linewidth(0.8)

    fig.tight_layout()
    path = output_dir / "convergencia_FX_barra_erro_3x3.pdf"
    fig.savefig(path, bbox_inches="tight", transparent=True)
    fig.savefig(
        output_dir / "convergencia_FX_barra_erro_3x3.png",
        dpi=400,
        bbox_inches="tight",
        transparent=True,
    )
    plt.close(fig)
    return path


def save_combined_table(
    path: Path,
    spatial: List[Dict[str, float]],
    temporal: List[Dict[str, float]],
    reference: Dict[str, float],
):
    """Tabela compacta para o parecer: observáveis e desvio da referência refinada."""
    rows = []
    for r in spatial + temporal:
        rows.append({
            "N": int(r["N"]),
            "dt_fs": r["dt_fs"],
            "dx_nm": r["dx_nm"],
            "tX_fs": r["tX_numeric_fs"],
            "F_X": r["F_X"],
            "1_minus_F": r["infidelity"],
            "P2_tX": r["P2_tX"],
            "P2_max": r["P2_max"],
            "norm_error_max": r["norm_error_max"],
            "abs_delta_F_vs_ref": abs(r["F_X"] - reference["F_X"]),
        })

    rows.append({
        "N": int(reference["N"]),
        "dt_fs": reference["dt_fs"],
        "dx_nm": reference["dx_nm"],
        "tX_fs": reference["tX_numeric_fs"],
        "F_X": reference["F_X"],
        "1_minus_F": reference["infidelity"],
        "P2_tX": reference["P2_tX"],
        "P2_max": reference["P2_max"],
        "norm_error_max": reference["norm_error_max"],
        "abs_delta_F_vs_ref": 0.0,
    })

    keys = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


# =============================================================================
# CLI / MAIN
# =============================================================================

def parse_args():
    p = argparse.ArgumentParser(
        description="Convergência da fidelidade F_X com Hamiltoniano completo 3x3."
    )
    p.add_argument("--output", default="convergencia_FX_3x3_final")
    p.add_argument("--smoke-test", action="store_true")
    p.add_argument("--no-figure", action="store_true")
    return p.parse_args()


def run_smoke_test():
    phys = PhysicalParameters()
    row = simulate_FX(
        phys,
        N=32,
        dt_fs=2.0,
        W_nm=200.0,
        edge_margin_nm=15.0,
        progress=False,
    )
    print("\nSMOKE TEST")
    print(f"F_X = {row['F_X']:.12f}")
    print(f"1-F_X = {row['infidelity']:.6e}")
    print(f"P1(tX) = {row['P1_tX']:.6e}")
    print(f"P2(tX) = {row['P2_tX']:.6e}")
    print(f"P2_max = {row['P2_max']:.6e}")
    print(f"norm_error_max = {row['norm_error_max']:.3e}")
    print(f"identity residual = {row['decomposition_residual']:.3e}")


def main():
    args = parse_args()
    if args.smoke_test:
        run_smoke_test()
        return

    output_dir = Path(args.output).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    phys = PhysicalParameters()
    num = NumericalParameters()

    eff = effective_parameters(phys)

    print("\n" + "=" * 96)
    print("CONVERGÊNCIA DA FIDELIDADE F_X — HAMILTONIANO COMPLETO 3x3")
    print("=" * 96)
    print(f"Delta12 = Delta23 = {phys.Delta12*1000:.3f} meV")
    print(f"U2 = {phys.U2*1000:.3f} meV")
    print(f"J_signed = {eff['J_signed_meV']:.9f} meV")
    print(f"|J| = {eff['J_abs_meV']:.9f} meV")
    print(f"tX teórico = {eff['tX_theory_fs']:.9f} fs")
    print(f"produção = {num.N_prod}x{num.N_prod}, dx = {num.W_nm/num.N_prod:.6f} nm, dt = {num.dt_prod_fs:.3f} fs")
    print(f"referência = {num.N_ref}x{num.N_ref}, dx = {num.W_nm/num.N_ref:.6f} nm, dt = {num.dt_ref_fs:.3f} fs")
    print("V0 = 0: benchmark coerente da porta X")
    print("=" * 96)

    spatial = run_spatial_sweep(phys, num, output_dir)
    temporal = run_temporal_sweep(phys, num, output_dir)
    reference = run_reference(phys, num)

    analysis = build_analysis(spatial, temporal, reference, num)

    # CSVs
    save_csv(output_dir / "convergencia_espacial_3x3.csv", spatial)
    save_csv(output_dir / "convergencia_temporal_3x3.csv", temporal)
    save_csv(output_dir / "resumo_barra_erro_FX_3x3.csv", [], extra=analysis)
    save_combined_table(
        output_dir / "tabela_II_convergencia_FX_3x3.csv",
        spatial,
        temporal,
        reference,
    )

    report_path = output_dir / "relatorio_barra_erro_FX_3x3.txt"
    save_report(report_path, phys, num, analysis, reference)

    if not args.no_figure:
        fig_path = save_figure(
            output_dir,
            spatial,
            temporal,
            reference,
            analysis,
            num,
        )
    else:
        fig_path = None

    print("\n" + "=" * 96)
    print("RESULTADO QUE ENTRA NO PAPER")
    print("=" * 96)
    print(
        f"F_X(produção) = {analysis['F_production']:.12f} ± "
        f"{analysis['delta_F_conservative']:.2e} "
        f"na malha {num.N_prod}x{num.N_prod}, dt={num.dt_prod_fs:.3f} fs"
    )
    print(f"1-F_X = {analysis['infidelity_production']:.8e}")
    print(f"delta_F espacial   = {analysis['delta_F_spatial']:.8e}")
    print(f"delta_F temporal   = {analysis['delta_F_temporal']:.8e}")
    print(f"delta_F referência = {analysis['delta_F_reference']:.8e}")
    print(f"barra conservadora = {analysis['delta_F_conservative']:.8e}")
    print(f"F_X(referência)    = {analysis['F_reference']:.12f}")

    print("\nDECOMPOSIÇÃO DE 1-F_X EM t_X")
    print("-" * 96)
    print(f"P1(tX)   = {analysis['P1_tX_production']:.8e}")
    print(f"P2(tX)   = {analysis['P2_tX_production']:.8e}")
    print(f"P2_max   = {analysis['P2_max_production']:.8e}")
    print(f"P1/(1-F) = {analysis['P1_fraction_of_infidelity']:.6f}")
    print(f"P2/(1-F) = {analysis['P2_fraction_of_infidelity']:.6f}")
    print(f"P2max/(1-F) = {analysis['P2max_over_infidelity']:.6f}")
    print(
        "Verificação: 1-F_X = P1(tX)+P2(tX), "
        f"resíduo = {analysis['identity_residual']:.3e}"
    )

    print("\nARQUIVOS")
    print("-" * 96)
    print(f"Relatório : {report_path}")
    print(f"Espacial  : {output_dir / 'convergencia_espacial_3x3.csv'}")
    print(f"Temporal  : {output_dir / 'convergencia_temporal_3x3.csv'}")
    print(f"Resumo    : {output_dir / 'resumo_barra_erro_FX_3x3.csv'}")
    print(f"Tabela II : {output_dir / 'tabela_II_convergencia_FX_3x3.csv'}")
    if fig_path is not None:
        print(f"Figura    : {fig_path}")
    print("=" * 96)


if __name__ == "__main__":
    main()
