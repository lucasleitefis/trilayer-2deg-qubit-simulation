# Trilayer 2DEG Qubit Simulation

Numerical simulations and figure-generation codes supporting the paper on an effective layer qubit in a trilayer 2DEG system.

The repository follows the **current 11-figure version of the paper**. Production figure scripts are kept under `figures/`, physical simulation engines under `simulations/`, numerical checks under `validation/`, and historical intermediate implementations under `archive/`. Generated numerical data are intentionally excluded by `.gitignore`.

## Repository structure

```text
simulations/
  core/                         Canonical full 3x3 solver
  coherent/                     Coherent layer-qubit dynamics
  perturbation/                 Full 3x3 dynamics with spatial perturbation
  tomography/                   Full 3x3 tomography-data generation

figures/
  fig02_coherent_dynamics/      Fig. 2
  fig11_tomography/             Current Fig. 11 tomography renderer
  fig04_x_gate_detuning/        Fig. 4
  fig05_effective_model/        Fig. 5
  fig06-07_universal_control/   Figs. 6–7
  fig08_perturbation/           Fig. 8
  fig09_coherence/              Fig. 9
  fig10_dephasing/              Fig. 10

validation/                     Numerical/model validation
archive/historical_versions/    Historical intermediate versions
data/                            Reserved for generated data (ignored)
```

## Figure map

| Figure | Main content | Main code |
|---|---|---|
| Fig. 1 | Trilayer schematic | Graphical figure; no simulation script |
| Fig. 2 | Full 3x3 coherent dynamics vs effective 2x2 model; intermediate-layer population | `figures/fig02_coherent_dynamics/fig02_coherent_full3x3_vs_effective2x2.py` |
| Fig. 3 | Coherent-state tomography and Bloch-sphere representation | `simulations/coherent/coherent_layer_qubit_dynamics.py` + `simulations/tomography/full_3x3_tomography_data.py` |
| Fig. 4 | X-gate fidelity vs static interlayer imbalance | `figures/fig04_x_gate_detuning/x_gate_detuning_robustness.py` |
| Fig. 5 | Fidelity and intermediate-layer leakage vs $U_2/\Delta$ | `figures/fig05_effective_model/effective_model_validity_vs_U2_Delta.py` |
| Fig. 6 | Bloch-sphere trajectory for Z-X-Z control | `figures/fig06-07_universal_control/xz_control_sequence.py` |
| Fig. 7 | Time-dependent $J(t)$ and $\delta U(t)$ controls | `figures/fig06-07_universal_control/xz_control_sequence.py` |
| Fig. 8 | Perturbation-strength sweep in $\eta=V_0/(2|J|)$ | `figures/fig08_perturbation/perturbation_strength_eta_sweep.py` |
| Fig. 9 | Reduced coherence $C(t)$ vs analytical phase-dispersion reference | `figures/fig09_coherence/coherence_phase_dispersion_reference.py` |
| Fig. 10 | Reduced layer dynamics under spatial perturbation: populations, purity and coherence | `figures/fig10_dephasing/fig10_perturbed_layer_qubit_dynamics.py` |
| Fig. 11 | Perturbed-state tomography and Bloch-sphere representation | `figures/fig11_tomography/perturbed_state_tomography_bloch_sphere_final.py` |

## Validation

The `validation/` directory contains numerical and model checks used to verify the effective-coupling convention, convergence of the X-gate fidelity, and the 2x2 effective-model reduction.

Two convergence scripts are retained explicitly for the referee audit:

- `validation/convergence_fidelity_X_3x3_single_state.py`: full 3x3, single computational-basis input used to quantify the numerical sensitivity of the reported $F_X(t_X)$; production grid $384\times384$, with spatial, temporal and jointly refined calculations.
- `validation/convergence_fidelity_X_3x3.py`: optimized six-input/Bloch-state mean-fidelity convergence calculation, using exact linear reconstruction from two propagated basis states and the same three refinement configurations.

Both are validation-only scripts; they do not replace the production figure-generation codes.

## Historical versions

Intermediate implementations are retained in `archive/historical_versions/` for traceability. They are not part of the primary figure-generation workflow. Historical files may preserve the figure numbering used in earlier manuscript versions.

## Data and generated files

The `data/` directory is reserved for generated numerical data. Runtime/generated files are excluded through `.gitignore`, including `__pycache__/`, `*.py[cod]`, `*.so`, `.venv/`, `env/`, `*.npz`, `*.npy`, `*.dat`, `*.log`, `*.txt`, `results/`, and `tomography_3x3_results/`.
