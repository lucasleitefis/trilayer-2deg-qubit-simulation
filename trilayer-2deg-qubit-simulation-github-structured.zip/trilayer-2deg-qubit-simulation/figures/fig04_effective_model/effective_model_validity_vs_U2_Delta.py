#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
PAPER-ONLY — Validity of the effective 2x2 description

This script is a clean publication version of the U2/Delta validity scan.

It generates ONLY the two quantities used in the paper:
    (a) X-gate fidelity F_X(t_X)
    (b) maximum intermediate-layer population P2^max

as functions of U2/Delta.

The full homogeneous 3x3 Hamiltonian is the physical reference.
The effective model enters only through the Schrieffer-Wolff coupling
J = -Delta^2/U2 and the corresponding theoretical X-gate time.

No auxiliary validation figures, dynamical traces, infidelity figure,
reduction-error figure, t_X scaling figure, CSV tables, or diagnostic
reports are produced by this script.
"""

from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt


# =============================================================================
# 1. PARÂMETROS FÍSICOS
# =============================================================================

HBAR = 0.6582119569       # eV fs
DELTA = 0.005             # eV = 5 meV
U1 = 0.0                  # eV
U3 = 0.0                  # eV

RATIOS = np.linspace(5.0, 100.0, 96)

N_TIME = 5000
TIME_FACTOR = 5.1


# =============================================================================
# 2. ESTILO — MESMO PADRÃO DAS FIGURAS FINAIS DO PAPER
# =============================================================================

def configure_matplotlib():
    plt.rcParams.update({
        "text.usetex": True,
        "font.family": "serif",
        "font.serif": ["Computer Modern Roman"],
        "text.latex.preamble": r"\usepackage{amsmath}",
        "text.color": "black",
        "axes.labelcolor": "black",
        "xtick.color": "black",
        "ytick.color": "black",
        "axes.edgecolor": "black",
        "font.size": 18,
        "axes.labelsize": 19,
        "legend.fontsize": 14,
        "xtick.labelsize": 15,
        "ytick.labelsize": 15,
        "axes.labelweight": "normal",
        "font.weight": "normal",
        "axes.linewidth": 0.75,
        "lines.linewidth": 1.7,
        "xtick.direction": "in",
        "ytick.direction": "in",
        "xtick.top": True,
        "ytick.right": True,
        "xtick.major.size": 5,
        "ytick.major.size": 5,
        "xtick.major.width": 0.75,
        "ytick.major.width": 0.75,
        "xtick.minor.visible": True,
        "ytick.minor.visible": True,
        "xtick.minor.size": 2.5,
        "ytick.minor.size": 2.5,
        "xtick.minor.width": 0.55,
        "ytick.minor.width": 0.55,
        "legend.frameon": False,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "savefig.dpi": 600,
    })


def polish_axes(ax):
    for spine in ax.spines.values():
        spine.set_linewidth(0.75)

    ax.tick_params(
        axis="both",
        which="major",
        direction="in",
        top=True,
        right=True,
        length=5,
        width=0.75,
    )

    ax.tick_params(
        axis="both",
        which="minor",
        direction="in",
        top=True,
        right=True,
        length=2.5,
        width=0.55,
    )

    ax.minorticks_on()


def save_figure(fig, outdir):
    pdf_path = outdir / "Fig_effective_model_validity_U2_Delta_VERTICAL.pdf"
    png_path = outdir / "Fig_effective_model_validity_U2_Delta_VERTICAL.png"

    fig.savefig(
        pdf_path,
        format="pdf",
        dpi=600,
        bbox_inches="tight",
        pad_inches=0.02,
        transparent=True,
    )

    fig.savefig(
        png_path,
        format="png",
        dpi=600,
        bbox_inches="tight",
        pad_inches=0.02,
        transparent=True,
    )

    plt.close(fig)

    return pdf_path, png_path


configure_matplotlib()


# =============================================================================
# 3. HAMILTONIANO COMPLETO E MODELO EFETIVO
# =============================================================================

def hamiltonian_full(U2, Delta=DELTA, U1=U1, U3=U3):
    return np.array(
        [
            [U1, Delta, 0.0],
            [Delta, U2, Delta],
            [0.0, Delta, U3],
        ],
        dtype=float,
    )


def effective_coupling(U2, Delta=DELTA):
    # Convenção canônica: J = -Delta^2/U2 para U2 > 0.
    return -Delta**2 / U2


def t_x_theoretical(U2, Delta=DELTA):
    J = effective_coupling(U2, Delta)
    return np.pi * HBAR / (2.0 * abs(J))


def diagonalize_full(U2):
    H = hamiltonian_full(U2)
    evals, evecs = np.linalg.eigh(H)

    # Estado lógico inicial |1> = (1,0,0)^T.
    psi0 = np.array([1.0, 0.0, 0.0], dtype=complex)
    coeff = evecs.conj().T @ psi0
    return evals, evecs, coeff


def full_dynamics_P2(evals, evecs, coeff, times):
    phases = np.exp(
        -1j * np.outer(evals, np.asarray(times)) / HBAR
    )
    states = (evecs @ (phases * coeff[:, None])).T
    return np.abs(states[:, 1])**2


def full_state_at_time(evals, evecs, coeff, time):
    phase = np.exp(-1j * evals * time / HBAR)
    return evecs @ (phase * coeff)


# =============================================================================
# 4. GRANDEZAS USADAS NA FIGURA
# =============================================================================

def analyze_ratio(ratio):
    U2 = ratio * DELTA
    tX = t_x_theoretical(U2)

    times = np.linspace(
        0.0,
        TIME_FACTOR * tX,
        N_TIME,
    )

    evals, evecs, coeff = diagonalize_full(U2)

    P2 = full_dynamics_P2(
        evals,
        evecs,
        coeff,
        times,
    )

    # Fidelidade no tempo t_X teórico, sem depender da malha temporal.
    psi_tX = full_state_at_time(
        evals,
        evecs,
        coeff,
        tX,
    )

    FX_full = float(np.abs(psi_tX[2])**2)
    P2_max = float(P2.max())

    return FX_full, P2_max


# =============================================================================
# 5. EXECUÇÃO — SOMENTE OS DOIS PLOTS DO PAPER
# =============================================================================

def main():
    outdir = (
        Path(__file__).resolve().parent
        / "effective_model_validity_paper_results_vertical"
    )
    outdir.mkdir(parents=True, exist_ok=True)

    print("=" * 92)
    print("PAPER-ONLY — VALIDADE DA REDUÇÃO 3x3 -> 2x2")
    print("=" * 92)
    print(f"Delta = {DELTA * 1000:.3f} meV")
    print(
        f"U2/Delta = {RATIOS[0]:.1f} -> "
        f"{RATIOS[-1]:.1f} ({len(RATIOS)} pontos)"
    )
    print(f"N_TIME = {N_TIME} | TIME_FACTOR = {TIME_FACTOR:.1f}")
    print("J = -Delta^2/U2 | tX = pi*hbar/(2|J|)")
    print("Apenas: (a) F_X(t_X) e (b) P2^max")
    print("=" * 92)

    fidelity = []
    p2_max = []

    for i, ratio in enumerate(RATIOS):
        FX_full, P2 = analyze_ratio(ratio)

        fidelity.append(FX_full)
        p2_max.append(P2)

        if (
            i == 0
            or (i + 1) % 10 == 0
            or i == len(RATIOS) - 1
        ):
            print(
                f"[{i + 1:3d}/{len(RATIOS)}] "
                f"U2/Delta={ratio:6.2f} | "
                f"F_X={FX_full:.10f} | "
                f"P2max={P2:.6e}"
            )

    ratios = np.asarray(RATIOS)
    fidelity = np.asarray(fidelity)
    p2_max = np.asarray(p2_max)

    # -------------------------------------------------------------------------
    # FIGURA FINAL — somente os dois painéis usados no paper.
    # -------------------------------------------------------------------------
    fig, (axA, axB) = plt.subplots(
        2,
        1,
        figsize=(5.2, 7.6),
    )

    # (a) Fidelidade
    axA.plot(
        ratios,
        fidelity,
        linewidth=1.7,
    )
    axA.set_xlim(5, 100)
    axA.set_ylim(max(0.0, fidelity.min() - 0.01), 1.03)
    axA.set_xlabel(r"$U_2/\Delta$")
    axA.set_ylabel(r"$F_X(t_X)$")
    axA.text(
        0.035,
        0.965,
        r"(a)",
        transform=axA.transAxes,
        ha="left",
        va="top",
        fontsize=15,
    )

    # (b) População máxima da camada intermediária
    axB.plot(
        ratios,
        100.0 * p2_max,
        linewidth=1.7,
    )
    axB.set_xlim(5, 100)
    axB.set_ylim(0.0, max(5.0, 1.08 * 100.0 * p2_max.max()))
    axB.set_xlabel(r"$U_2/\Delta$")
    axB.set_ylabel(r"$P_2^{\max}$ (\%)")
    axB.text(
        0.035,
        0.965,
        r"(b)",
        transform=axB.transAxes,
        ha="left",
        va="top",
        fontsize=15,
    )

    polish_axes(axA)
    polish_axes(axB)

    fig.subplots_adjust(
        left=0.085,
        right=0.985,
        bottom=0.18,
        top=0.965,
        wspace=0.28,
    )

    pdf_path, png_path = save_figure(fig, outdir)

    print("\n" + "=" * 92)
    print("FIGURA FINAL GERADA")
    print("=" * 92)
    print(f"PDF : {pdf_path}")
    print(f"PNG : {png_path}")
    print(f"Dir : {outdir}")
    print("=" * 92)


if __name__ == "__main__":
    main()
