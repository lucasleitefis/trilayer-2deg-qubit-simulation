#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Z-X-Z control sequence for the logical layer qubit.

PURPOSE
-------
This script reproduces the control construction based on non-commuting X- and
Z-type controls in the logical outer-layer subspace.

The plotted sequence uses a phase convention in which the effective transverse
coupling is written with positive control amplitude. This is a basis-phase
choice and does not alter physical populations or fidelities.

FIGURES
-------
The script directly generates two publication-style figures:
  1. the Bloch-sphere trajectory for the Z-X-Z sequence;
  2. the corresponding control pulses J(t) and delta U(t)=U1-U3.

OUTPUTS
-------
The script saves both figures as PDF and PNG files and also saves the numerical
sequence data and a text report.

ROLE IN THE REPRODUCTION CHAIN
------------------------------
This is a self-contained control-and-figure script. The sequence is implemented
in the effective logical model and benchmarked against the physical 3x3 model
within the script.
"""

from __future__ import annotations

from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from scipy.linalg import expm

# =============================================================================
# PARÂMETROS FÍSICOS
# =============================================================================

HBAR = 658.211928462  # meV fs
DELTA = 5.0            # meV
U2 = 100.0             # meV
J_SIGNED = -(DELTA ** 2) / U2
J_ABS = abs(J_SIGNED)

DELTA_U0 = 0.50        # meV

# Sequência publicada / histórica: Rz(gamma) Rx(beta) Rz(alpha)
GAMMA = np.pi / 3.0
BETA = np.pi / 2.0
ALPHA = np.pi / 4.0

# Pacote espacial usado apenas como fator comum para preservar a construção da figura.
SIGMA = 15.0           # nm
NX = 64
NY = 64
WX = 200.0             # nm
WY = 200.0             # nm

OUTDIR = Path(__file__).resolve().parent / "xz_control_sequence_results"
OUTDIR.mkdir(parents=True, exist_ok=True)

# =============================================================================
# ESTILO PUBLICAÇÃO
# =============================================================================

plt.rcParams.update({
    "text.usetex": True,
    "font.family": "serif",
    "font.serif": ["Computer Modern Roman"],
    "text.latex.preamble": r"\usepackage{amsmath}",
    "text.color": "black",
    "axes.labelcolor": "black",
    "xtick.color": "black",
    "ytick.color": "black",
    "axes.edgecolor": "black",
    "font.size": 18,
    "axes.labelsize": 19,
    "axes.titlesize": 18,
    "xtick.labelsize": 15,
    "ytick.labelsize": 15,
    "axes.linewidth": 0.75,
    "lines.linewidth": 1.7,
    "xtick.direction": "in",
    "ytick.direction": "in",
    "xtick.top": True,
    "ytick.right": True,
    "xtick.major.size": 5,
    "ytick.major.size": 5,
    "xtick.major.width": 0.75,
    "ytick.major.width": 0.75,
    "xtick.minor.visible": True,
    "ytick.minor.visible": True,
    "xtick.minor.size": 2.5,
    "ytick.minor.size": 2.5,
    "xtick.minor.width": 0.55,
    "ytick.minor.width": 0.55,
    "legend.frameon": False,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})


def polish_axes(ax, grid=True):
    for spine in ax.spines.values():
        spine.set_linewidth(0.75)
    ax.tick_params(which="major", direction="in", length=5, width=0.75,
                   top=True, right=True)
    ax.tick_params(which="minor", direction="in", length=2.5, width=0.55,
                   top=True, right=True)
    ax.minorticks_on()
    if grid:
        ax.grid(True, alpha=0.18, linewidth=0.5)


def save_figure(fig, pdf_path: Path):
    fig.savefig(pdf_path, format="pdf", dpi=300,
                bbox_inches="tight", pad_inches=0.01, transparent=True)
    fig.savefig(pdf_path.with_suffix(".png"), format="png", dpi=450,
                bbox_inches="tight", pad_inches=0.01, transparent=True)
    plt.close(fig)

# =============================================================================
# MATRIZES E ROTAÇÕES
# =============================================================================

SIGMA_X = np.array([[0, 1], [1, 0]], dtype=complex)
SIGMA_Y = np.array([[0, -1j], [1j, 0]], dtype=complex)
SIGMA_Z = np.array([[1, 0], [0, -1]], dtype=complex)
I2 = np.eye(2, dtype=complex)


def rotation_time_z(angle, delta_u):
    return abs(angle) * HBAR / abs(delta_u)


def rotation_time_x(angle, j_abs):
    return abs(angle) * HBAR / (2.0 * abs(j_abs))


def h2_control(j_control, delta_u):
    return j_control * SIGMA_X + 0.5 * delta_u * SIGMA_Z


def bloch(psi):
    rho = np.outer(psi, psi.conj())
    return np.array([
        np.trace(rho @ SIGMA_X).real,
        np.trace(rho @ SIGMA_Y).real,
        np.trace(rho @ SIGMA_Z).real,
    ])

# =============================================================================
# EVOLUÇÃO EFETIVA Z-X-Z
# =============================================================================

TZ_GAMMA = rotation_time_z(GAMMA, DELTA_U0)
TX_BETA = rotation_time_x(BETA, J_ABS)
TZ_ALPHA = rotation_time_z(ALPHA, DELTA_U0)

DURATIONS = np.array([TZ_GAMMA, TX_BETA, TZ_ALPHA], dtype=float)
STAGE_NAMES = ("Z", "X", "Z")
STAGE_CONTROLS = (
    (0.0, DELTA_U0),
    (J_ABS, 0.0),
    (0.0, DELTA_U0),
)

# Exact piecewise-constant evolution. The spatial packet is a common factor and
# therefore drops out of the reduced logical state for V=0.
SAMPLES_PER_STAGE = 500
psi0 = np.array([1.0, 0.0], dtype=complex)

states = [psi0.copy()]
times_fs = [0.0]
stage_ids = [0]

psi = psi0.copy()
t_current = 0.0
stage_boundaries = [0.0]

for sid, ((j_control, delta_u), duration) in enumerate(zip(STAGE_CONTROLS, DURATIONS)):
    dt = duration / SAMPLES_PER_STAGE
    H = h2_control(j_control, delta_u)
    U_step = expm(-1j * H * dt / HBAR)

    for _ in range(SAMPLES_PER_STAGE):
        psi = U_step @ psi
        psi /= np.linalg.norm(psi)
        t_current += dt
        states.append(psi.copy())
        times_fs.append(t_current)
        stage_ids.append(sid)

    stage_boundaries.append(t_current)

states = np.asarray(states)
times_fs = np.asarray(times_fs)
stage_ids = np.asarray(stage_ids)
bloch_traj = np.asarray([bloch(s) for s in states])

# Exact target obtained from the same ordered rotations.
Rz_gamma = expm(-1j * GAMMA * SIGMA_Z / 2.0)
Rx_beta = expm(-1j * BETA * SIGMA_X / 2.0)
Rz_alpha = expm(-1j * ALPHA * SIGMA_Z / 2.0)
U_target = Rz_alpha @ Rx_beta @ Rz_gamma
psi_target = U_target @ psi0
psi_target /= np.linalg.norm(psi_target)

fidelity_eff = abs(np.vdot(psi_target, psi)) ** 2
norm_error_eff = abs(np.vdot(psi, psi).real - 1.0)
unitarity_errors_eff = []
for j, du in STAGE_CONTROLS:
    H = h2_control(j, du)
    U = expm(-1j * H * (1.0 / HBAR))
    unitarity_errors_eff.append(np.linalg.norm(U.conj().T @ U - I2))

# =============================================================================
# BENCHMARK FÍSICO 3x3
# =============================================================================

# Fixed physical basis: |0> = |1>, |1> = |3>.
# The physical mediated coupling is J_SIGNED < 0.


def h33(U1, U3, d12, d23):
    return np.array([
        [U1, d12, 0.0],
        [d12, U2, d23],
        [0.0, d23, U3],
    ], dtype=complex)


# Z-X-Z protocol in the physical three-level Hamiltonian.
psi3 = np.array([1.0, 0.0, 0.0], dtype=complex)
p2_history = [abs(psi3[1]) ** 2]
for sid, duration in enumerate(DURATIONS):
    j_control, delta_u = STAGE_CONTROLS[sid]
    if sid in (0, 2):
        U1, U3 = +delta_u / 2.0, -delta_u / 2.0
        d12 = d23 = 0.0
    else:
        U1 = U3 = 0.0
        d12 = d23 = DELTA

    # Internal exact propagation; the pulse is generated in the physical gauge.
    # X stage has the physical sign J_SIGNED = -|J|.
    steps = SAMPLES_PER_STAGE
    dt = duration / steps
    H = h33(U1, U3, d12, d23)
    Ustep = expm(-1j * H * dt / HBAR)
    for _ in range(steps):
        psi3 = Ustep @ psi3
        psi3 /= np.linalg.norm(psi3)
        p2_history.append(abs(psi3[1]) ** 2)

# Gauge map corresponding to |3>' = -|3> used in the effective figure convention.
S3 = np.diag([1.0, 1.0, -1.0]).astype(complex)
psi3_control_gauge = S3 @ psi3

# Effective target embedded in 3 levels in the same control gauge.
psi_target_3 = np.array([psi_target[0], 0.0, psi_target[1]], dtype=complex)
fidelity_full_gauge = abs(np.vdot(psi_target_3, psi3_control_gauge)) ** 2
P2_final = abs(psi3[1]) ** 2
P2_max = float(np.max(p2_history))
P_logic_final = abs(psi3[0]) ** 2 + abs(psi3[2]) ** 2
norm_error_3 = abs(np.vdot(psi3, psi3).real - 1.0)

# Compare the effective and physical gate target in the canonical phase convention.
# This is the physically meaningful check; the figure itself remains in the
# published phase gauge so that its geometry matches the manuscript.

# =============================================================================
# FIGURA 1: TRAJETÓRIA DE BLOCH (XZ.pdf)
# =============================================================================

fig = plt.figure(figsize=(4.85, 4.85), dpi=300)
fig.patch.set_alpha(0.0)
ax = fig.add_axes([0.035, 0.025, 0.93, 0.94], projection="3d")

u = np.linspace(0, 2 * np.pi, 64)
v = np.linspace(0, np.pi, 32)
xs = np.outer(np.cos(u), np.sin(v))
ys = np.outer(np.sin(u), np.sin(v))
zs = np.outer(np.ones_like(u), np.cos(v))
ax.plot_surface(xs, ys, zs, color="#f0d8e8", alpha=0.10,
                linewidth=0, shade=False)
ax.plot_wireframe(xs, ys, zs, rstride=4, cstride=6,
                  color="#b8b8b8", linewidth=0.28, alpha=0.42)
ax.plot([-1, 1], [0, 0], [0, 0], color="#777777", lw=0.45)
ax.plot([0, 0], [-1, 1], [0, 0], color="#777777", lw=0.45)
ax.plot([0, 0], [0, 0], [-1, 1], color="#777777", lw=0.45)

traj_color = "#d45ca6"
ax.plot(bloch_traj[:, 0], bloch_traj[:, 1], bloch_traj[:, 2],
        color=traj_color, lw=2.2)
ax.quiver(0, 0, 0, *bloch_traj[-1], color=traj_color,
          linewidth=1.7, arrow_length_ratio=0.10, normalize=False)

# Initial, post-X, final markers.
idx_x = SAMPLES_PER_STAGE + SAMPLES_PER_STAGE
for idx in (0, idx_x, len(times_fs) - 1):
    ax.scatter(bloch_traj[idx, 0], bloch_traj[idx, 1], bloch_traj[idx, 2],
               s=30, color=traj_color, depthshade=False)

# Segment labels, placed near the middle of each stage.
for sid, label in enumerate(STAGE_NAMES):
    mask = stage_ids == sid
    idx = np.flatnonzero(mask)
    if len(idx):
        i = idx[len(idx) // 2]
        vec = bloch_traj[i]
        ax.text(vec[0] * 1.10, vec[1] * 1.10, vec[2] * 1.10,
                rf"${label}$", fontsize=15, color=traj_color,
                ha="center", va="center")

ax.text(0, 0, 1.105, r"$|0\rangle$", fontsize=12.5, ha="center", va="bottom")
ax.text(0, 0, -1.105, r"$|1\rangle$", fontsize=12.5, ha="center", va="top")
ax.text(1.13, 0, 0, r"$x$", fontsize=13, ha="center")
ax.text(0, 1.13, 0, r"$y$", fontsize=13, ha="center")
ax.set(xlim=(-0.7, 0.7), ylim=(-0.7, 0.7), zlim=(-0.7, 0.7))
ax.set_box_aspect((1, 1, 1))
ax.view_init(elev=22, azim=-42)
ax.set_axis_off()
ax.text2D(0.080, 0.985, "(a)", transform=ax.transAxes,
          fontsize=15, ha="left", va="top")

XZ_BLOCH_PDF = OUTDIR / "xz_bloch_trajectory.pdf"
save_figure(fig, XZ_BLOCH_PDF)

# =============================================================================
# FIGURA 2: J(t) E delta U(t) (JDU.pdf)
# =============================================================================

t_end = float(stage_boundaries[-1])
t_plot = np.linspace(0.0, t_end, 1400)

J_plot = np.zeros_like(t_plot)
du_plot = np.zeros_like(t_plot)
for sid, (start, end) in enumerate(zip(stage_boundaries[:-1], stage_boundaries[1:])):
    mask = (t_plot >= start) & (t_plot <= end)
    j, du = STAGE_CONTROLS[sid]
    J_plot[mask] = j
    du_plot[mask] = du

fig, ax = plt.subplots(1, 2, figsize=(10.0, 4.25), dpi=300)
fig.patch.set_alpha(0.0)

# J(t)
ax[0].plot(t_plot, J_plot, color="#377eb8", lw=1.7)
for x in stage_boundaries[1:-1]:
    ax[0].axvline(x, color="#b9cde2", lw=0.65, ls="--")
ax[0].text(0.5 * stage_boundaries[0] + 0.5 * stage_boundaries[1], 0.018,
           r"$Z$", ha="center", fontsize=15)
ax[0].text(0.5 * (stage_boundaries[1] + stage_boundaries[2]), 0.285,
           r"$X$", ha="center", fontsize=17)
ax[0].text(0.5 * (stage_boundaries[2] + stage_boundaries[3]), 0.018,
           r"$Z$", ha="center", fontsize=15)
ax[0].set_xlim(0, t_end)
ax[0].set_ylim(-0.02, 0.35)
ax[0].set_xlabel(r"Time (fs)")
ax[0].set_ylabel(r"$J(t)$ (meV)")
polish_axes(ax[0])
ax[0].text(0.00, 1.02, "(a)", transform=ax[0].transAxes,
            fontsize=15, va="bottom")

# deltaU(t)
ax[1].plot(t_plot, du_plot, color="#377eb8", lw=1.7)
for x in stage_boundaries[1:-1]:
    ax[1].axvline(x, color="#b9cde2", lw=0.65, ls="--")
ax[1].text(0.5 * stage_boundaries[0] + 0.5 * stage_boundaries[1], 0.02,
           r"$Z$", ha="center", fontsize=15)
ax[1].text(0.5 * (stage_boundaries[1] + stage_boundaries[2]), 0.52,
           r"$X$", ha="center", fontsize=17)
ax[1].text(0.5 * (stage_boundaries[2] + stage_boundaries[3]), 0.02,
           r"$Z$", ha="center", fontsize=15)
ax[1].set_xlim(0, t_end)
ax[1].set_ylim(-0.02, 0.65)
ax[1].set_xlabel(r"Time (fs)")
ax[1].set_ylabel(r"$\delta U(t)=U_1-U_3$ (meV)")
polish_axes(ax[1])
ax[1].text(0.00, 1.02, "(b)", transform=ax[1].transAxes,
            fontsize=15, va="bottom")

fig.subplots_adjust(left=0.095, right=0.995, bottom=0.24, top=0.965, wspace=0.22)

XZ_CONTROLS_PDF = OUTDIR / "xz_control_protocol.pdf"
save_figure(fig, XZ_CONTROLS_PDF)

# =============================================================================
# DADOS / RELATÓRIO
# =============================================================================

np.savez(
    OUTDIR / "xz_control_sequence_data.npz",
    times_fs=times_fs,
    states=states,
    bloch=bloch_traj,
    stage_ids=stage_ids,
    stage_boundaries_fs=np.asarray(stage_boundaries),
    J_signed=np.array(J_SIGNED),
    J_control=np.array(J_ABS),
    delta_U0=np.array(DELTA_U0),
    fidelity_effective=np.array(fidelity_eff),
    fidelity_full_3x3_phase_gauge=np.array(fidelity_full_gauge),
    P2_max=np.array(P2_max),
    P2_final=np.array(P2_final),
    P_logic_final=np.array(P_logic_final),
)

with open(OUTDIR / "xz_control_sequence_report.txt", "w", encoding="utf-8") as f:
    f.write("ETAPA 7 — CONTROLE X-Z\n")
    f.write("=" * 72 + "\n")
    f.write(f"Delta12 = Delta23 = {DELTA:.6f} meV\n")
    f.write(f"U2 = {U2:.6f} meV\n")
    f.write(f"J_signed = {J_SIGNED:.12f} meV\n")
    f.write(f"|J| = {J_ABS:.12f} meV\n")
    f.write(f"delta_U0 = {DELTA_U0:.6f} meV\n")
    f.write(f"gamma = {GAMMA/np.pi:.6f} pi\n")
    f.write(f"beta  = {BETA/np.pi:.6f} pi\n")
    f.write(f"alpha = {ALPHA/np.pi:.6f} pi\n")
    f.write(f"t_Z(gamma) = {TZ_GAMMA:.12f} fs\n")
    f.write(f"t_X(beta) = {TX_BETA:.12f} fs\n")
    f.write(f"t_Z(alpha) = {TZ_ALPHA:.12f} fs\n")
    f.write(f"T_total = {t_end:.12f} fs\n")
    f.write("\nEFETIVO 2x2\n")
    f.write(f"F_sequence = {fidelity_eff:.15f}\n")
    f.write(f"norm_error = {norm_error_eff:.3e}\n")
    f.write(f"max_unitarity_error = {max(unitarity_errors_eff):.3e}\n")
    f.write("\nFISICO 3x3\n")
    f.write("comparacao na convencao de fase |3>'=-|3>\n")
    f.write(f"F_sequence_3x3 = {fidelity_full_gauge:.15f}\n")
    f.write(f"P2_max = {P2_max:.15e}\n")
    f.write(f"P2_final = {P2_final:.15e}\n")
    f.write(f"P_logic_final = {P_logic_final:.15f}\n")
    f.write(f"norm_error_3x3 = {norm_error_3:.3e}\n")
    f.write("\nSAIDAS\n")
    f.write(f"{XZ_BLOCH_PDF}\n")
    f.write(f"{XZ_CONTROLS_PDF}\n")

print("=" * 72)
print("ETAPA 7 — CONTROLE X-Z: PASS")
print("=" * 72)
print(f"J_signed = {J_SIGNED:.6f} meV")
print(f"|J| = {J_ABS:.6f} meV")
print(f"delta_U0 = {DELTA_U0:.6f} meV")
print(f"t_Z(gamma) = {TZ_GAMMA:.6f} fs")
print(f"t_X(beta)  = {TX_BETA:.6f} fs")
print(f"t_Z(alpha) = {TZ_ALPHA:.6f} fs")
print(f"T_total    = {t_end:.6f} fs")
print(f"F_eff      = {fidelity_eff:.12f}")
print(f"F_3x3 (gauge) = {fidelity_full_gauge:.12f}")
print(f"P2_max     = {P2_max:.6e}")
print(f"P2_final   = {P2_final:.6e}")
print(f"P_logic_final = {P_logic_final:.12f}")
print(f"norm err 2x2 = {norm_error_eff:.3e}")
print(f"norm err 3x3 = {norm_error_3:.3e}")
print(f"Bloch norm min = {np.min(np.linalg.norm(bloch_traj, axis=1)):.12f}")
print("\nArquivos:")
print(f"  {XZ_BLOCH_PDF}")
print(f"  {XZ_CONTROLS_PDF}")
print(f"  {OUTDIR / 'xz_control_sequence_data.npz'}")
print(f"  {OUTDIR / 'xz_control_sequence_report.txt'}")
