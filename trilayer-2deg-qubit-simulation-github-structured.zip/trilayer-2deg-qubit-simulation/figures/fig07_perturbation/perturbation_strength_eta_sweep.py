#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Production sweep of the spatial-perturbation strength.

PURPOSE
-------
This script generates the manuscript's eta-sweep result using the full 3x3
Hamiltonian for every point in

    eta = V0 / (2|J|).

For each eta, the complete spatial split-operator dynamics is performed with the
perturbation acting only on H_11.

FIGURES
-------
Publication figure corresponding to the perturbation-strength sweep. It reports
the main population-transfer, coherence, purity, and X-gate-fidelity indicators
as functions of eta.

OUTPUTS
-------
The script automatically saves:
  - one compressed dataset per eta;
  - a CSV summary table;
  - a text report;
  - the publication PDF;
  - the publication PNG.

ROLE IN THE REPRODUCTION CHAIN
------------------------------
This is a self-contained production script: it computes the sweep, saves the
numerical results, and creates the figure.

REFERENCE POINT
---------------
The frozen production convention uses eta = 10 as the reference point, which
corresponds to V0 = 5 meV for |J| = 0.25 meV.
"""

from __future__ import annotations

import argparse
import csv
import time
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt

try:
    from scipy import fft as spfft
    SCIPY_FFT = True
except Exception:
    spfft = None
    SCIPY_FFT = False


# =============================================================================
# PARÂMETROS FÍSICOS CONGELADOS
# =============================================================================
HBAR = 0.658211928               # eV fs
E_CHARGE = 1.60217662e-19        # C
M_EL = 9.1093837e-31             # kg
M_EFF = 0.067 * M_EL

DELTA12 = 0.005                  # eV
DELTA23 = 0.005                  # eV
DELTA13 = 0.0                    # eV
U1 = 0.0                         # eV
U2 = 0.100                       # eV
U3 = 0.0                         # eV

J_SIGNED = -DELTA12 * DELTA23 / U2
J_ABS = abs(J_SIGNED)

T_EFF_FS = np.pi * HBAR / J_ABS
tX_THEORY_FS = np.pi * HBAR / (2.0 * J_ABS)
DT = 0.5
tX_NUM_FS = round(tX_THEORY_FS / DT) * DT

ETA_PRODUCTION = (0.0, 0.25, 0.5, 1.0, 2.0, 4.0,
                  6.0, 8.0, 10.0, 12.0)

# Referência do manuscrito: eta=10 -> V0=5 meV.
REFERENCE_ETA = 10.0
REFERENCE_V0_MEV = REFERENCE_ETA * 2.0 * J_ABS * 1000.0


# =============================================================================
# PARÂMETROS NUMÉRICOS
# =============================================================================
NX_PROD = NY_PROD = 384
WX_PROD = WY_PROD = 1200.0      # nm
SIGMA = 15.0                    # nm
X0 = 40.0                       # nm
WIDTH = 10.0                    # nm

# Para a varredura é suficiente cobrir t_X,num exatamente.
NT_PROD = int(round(tX_NUM_FS / DT))
SAVE_STEP_PROD = 1

# Quick: mesma física e mesmo t_X, porém grade menor e apenas alguns eta.
NX_QUICK = NY_QUICK = 128
WX_QUICK = WY_QUICK = 400.0     # nm
NT_QUICK = NT_PROD
SAVE_STEP_QUICK = 1
ETA_QUICK = (0.0, 1.0, 10.0)


# =============================================================================
# ESTILO DA FIG. 10 ATUAL
# =============================================================================
plt.rcParams.update({
    "font.family": "serif",
    "mathtext.fontset": "cm",
    "font.size": 11,
    "axes.labelsize": 13,
    "xtick.labelsize": 10,
    "ytick.labelsize": 10,
    "axes.linewidth": 0.8,
    "xtick.direction": "in",
    "ytick.direction": "in",
    "xtick.minor.visible": True,
    "ytick.minor.visible": True,
    "legend.frameon": False,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})


def polish(ax: plt.Axes) -> None:
    ax.tick_params(axis="both", which="major", direction="in",
                   top=True, right=True, length=4.0, width=0.7)
    ax.tick_params(axis="both", which="minor", direction="in",
                   top=True, right=True, length=2.0, width=0.5)


def fft2(a: np.ndarray) -> np.ndarray:
    return spfft.fft2(a, workers=-1) if SCIPY_FFT else np.fft.fft2(a)


def ifft2(a: np.ndarray) -> np.ndarray:
    return spfft.ifft2(a, workers=-1) if SCIPY_FFT else np.fft.ifft2(a)


# =============================================================================
# MALHA E OPERADOR CINÉTICO
# =============================================================================
def build_grid(nx: int, ny: int, wx: float, wy: float):
    dx = wx / nx
    dy = wy / ny
    x = -wx / 2.0 + np.arange(nx) * dx
    y = -wy / 2.0 + np.arange(ny) * dy
    X, Y = np.meshgrid(x, y, indexing="ij")

    kx = 2.0 * np.pi * np.fft.fftfreq(nx, d=dx)
    ky = 2.0 * np.pi * np.fft.fftfreq(ny, d=dy)
    KX, KY = np.meshgrid(kx, ky, indexing="ij")
    K2_SI = (KX * 1.0e9) ** 2 + (KY * 1.0e9) ** 2

    hbar_si = HBAR * 1.0e-15 * E_CHARGE
    T_KIN_EV = (hbar_si ** 2 * K2_SI / (2.0 * M_EFF)) / E_CHARGE
    T_HALF = np.exp(-1j * T_KIN_EV * DT / (2.0 * HBAR))

    phi0 = np.exp(-(X ** 2 + Y ** 2) / (2.0 * SIGMA ** 2)).astype(np.complex128)
    phi0 /= np.sqrt(np.sum(np.abs(phi0) ** 2) * dx * dy)

    return X, Y, dx, dy, T_HALF, phi0


# =============================================================================
# PROPAGADOR LOCAL CANÔNICO 3x3
# =============================================================================
def local_propagator_3x3(V: np.ndarray) -> np.ndarray:
    H = np.zeros(V.shape + (3, 3), dtype=np.complex128)

    # MODELO FÍSICO CONGELADO: perturbação SOMENTE em A_11.
    H[..., 0, 0] = U1 + V
    H[..., 1, 1] = U2
    H[..., 2, 2] = U3

    H[..., 0, 1] = H[..., 1, 0] = DELTA12
    H[..., 1, 2] = H[..., 2, 1] = DELTA23
    H[..., 0, 2] = H[..., 2, 0] = DELTA13

    eigvals, eigvecs = np.linalg.eigh(H)
    phases = np.exp(-1j * eigvals * DT / HBAR)
    eigvecs_dag = np.swapaxes(eigvecs.conj(), -1, -2)
    Uloc = np.einsum("...ik,...k,...kj->...ij",
                     eigvecs, phases, eigvecs_dag, optimize=True)
    return Uloc


def local_unitarity_error(Uloc: np.ndarray) -> float:
    ident = np.eye(3, dtype=np.complex128)
    err = Uloc.conj().swapaxes(-1, -2) @ Uloc - ident
    return float(np.max(np.abs(err)))


# =============================================================================
# UM PASSO SPLIT-STEP 3x3
# =============================================================================
def split_step_3x3(psi1, psi2, psi3, Uloc, T_half):
    psi1 = ifft2(fft2(psi1) * T_half)
    psi2 = ifft2(fft2(psi2) * T_half)
    psi3 = ifft2(fft2(psi3) * T_half)

    old1, old2, old3 = psi1, psi2, psi3
    psi1 = (Uloc[..., 0, 0] * old1 + Uloc[..., 0, 1] * old2
            + Uloc[..., 0, 2] * old3)
    psi2 = (Uloc[..., 1, 0] * old1 + Uloc[..., 1, 1] * old2
            + Uloc[..., 1, 2] * old3)
    psi3 = (Uloc[..., 2, 0] * old1 + Uloc[..., 2, 1] * old2
            + Uloc[..., 2, 2] * old3)

    psi1 = ifft2(fft2(psi1) * T_half)
    psi2 = ifft2(fft2(psi2) * T_half)
    psi3 = ifft2(fft2(psi3) * T_half)

    return psi1, psi2, psi3


# =============================================================================
# OBSERVÁVEIS
# =============================================================================
def observables(psi1, psi2, psi3, dx: float, dy: float):
    p1 = float(np.sum(np.abs(psi1) ** 2) * dx * dy)
    p2 = float(np.sum(np.abs(psi2) ** 2) * dx * dy)
    p3 = float(np.sum(np.abs(psi3) ** 2) * dx * dy)

    rho13 = np.sum(psi1 * np.conjugate(psi3)) * dx * dy
    rho = np.array([[p1, rho13], [np.conjugate(rho13), p3]], dtype=np.complex128)
    purity = float(np.real(np.trace(rho @ rho)))
    return p1, p2, p3, abs(rho13), purity, p1 + p2 + p3


# =============================================================================
# UMA SIMULAÇÃO EM ETA
# =============================================================================
def simulate_eta(eta, X, Y, dx, dy, T_half, phi0, nt, save_step):
    V0 = float(eta) * 2.0 * J_ABS
    V = V0 * np.exp(-((X - X0) ** 2) / (2.0 * WIDTH ** 2))

    print(f"\n>>> eta={eta:.2f} | V0={V0 * 1000.0:.6f} meV")
    t_build = time.perf_counter()
    Uloc = local_propagator_3x3(V)
    build_s = time.perf_counter() - t_build
    print(f"    U_loc construído em {build_s:.2f} s")

    uerr = local_unitarity_error(Uloc)
    print(f"    erro de unitariedade local = {uerr:.3e}")

    psi1 = phi0.copy()
    psi2 = np.zeros_like(phi0)
    psi3 = np.zeros_like(phi0)

    nsave = nt // save_step + 1
    times = np.empty(nsave)
    p1 = np.empty(nsave)
    p2 = np.empty(nsave)
    p3 = np.empty(nsave)
    coh = np.empty(nsave)
    pur = np.empty(nsave)
    norm = np.empty(nsave)

    j = 0
    t0 = time.perf_counter()

    for it in range(nt + 1):
        if it % save_step == 0:
            vals = observables(psi1, psi2, psi3, dx, dy)
            times[j] = it * DT
            p1[j], p2[j], p3[j], coh[j], pur[j], norm[j] = vals
            j += 1

        if it == nt:
            break

        psi1, psi2, psi3 = split_step_3x3(
            psi1, psi2, psi3, Uloc, T_half
        )

        if it % 200 == 0 or it == nt - 1:
            frac = (it + 1) / nt
            width_bar = 36
            filled = int(frac * width_bar)
            bar = "█" * filled + "·" * (width_bar - filled)
            elapsed = time.perf_counter() - t0
            eta_s = elapsed * (1.0 - frac) / frac if frac > 0 else 0.0
            print(f"\r    [{bar}] {100 * frac:6.2f}% "
                  f"| elapsed {elapsed / 60:6.1f} min "
                  f"| ETA {eta_s / 60:6.1f} min",
                  end="", flush=True)

    print()
    elapsed = time.perf_counter() - t0

    iX = int(np.argmin(np.abs(times - tX_NUM_FS)))
    result = {
        "eta": float(eta),
        "V0_meV": V0 * 1000.0,
        "t": times,
        "p1": p1,
        "p2": p2,
        "p3": p3,
        "coherence": coh,
        "purity": pur,
        "norm": norm,
        "FX": float(p3[iX]),
        "tFX_fs": float(times[iX]),
        "P3max": float(np.max(p3)),
        "P2max": float(np.max(p2)),
        "P1min": float(np.min(p1)),
        "Cmax": float(np.max(coh)),
        "puritymin": float(np.min(pur)),
        "t_P3max_fs": float(times[np.argmax(p3)]),
        "normerr": float(np.max(np.abs(norm - 1.0))),
        "unitarity_local_err": uerr,
        "elapsed": elapsed,
    }

    print(f"    F_X(t={result['tFX_fs']:.1f} fs) = {result['FX']:.12f}")
    print(f"    P3_max = {result['P3max']:.12f}")
    print(f"    P2_max = {result['P2max']:.12e}")
    print(f"    P1_min = {result['P1min']:.12f}")
    print(f"    |rho13|_max = {result['Cmax']:.12f}")
    print(f"    purity_min = {result['puritymin']:.12f}")
    print(f"    norm error = {result['normerr']:.12e}")
    print(f"    runtime = {elapsed / 60:.2f} min")
    return result


# =============================================================================
# SAÍDAS
# =============================================================================
def save_results(results, outdir: Path):
    outdir.mkdir(parents=True, exist_ok=True)

    # Um arquivo por eta, para não perder resultados caso uma execução longa seja interrompida.
    for r in results:
        np.savez_compressed(
            outdir / f"eta_{r['eta']:05.2f}.npz",
            eta=r["eta"], V0_meV=r["V0_meV"], t_fs=r["t"],
            P1=r["p1"], P2=r["p2"], P3=r["p3"],
            coherence=r["coherence"], purity=r["purity"], norm=r["norm"],
        )

    csv_path = outdir / "eta_sweep_results.csv"
    fields = [
        "eta", "V0_meV", "P3max", "P2max", "P1min", "Cmax",
        "puritymin", "FX", "tFX_fs", "t_P3max_fs",
        "normerr", "unitarity_local_err", "elapsed",
    ]
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for r in results:
            writer.writerow({k: r[k] for k in fields})

    txt_path = outdir / "eta_sweep_report.txt"
    with txt_path.open("w", encoding="utf-8") as f:
        f.write("ETAPA 8 — VARREDURA eta = V0/(2|J|)\n")
        f.write("=" * 80 + "\n")
        f.write(f"Delta12 = Delta23 = {DELTA12 * 1000:.6f} meV\n")
        f.write(f"U2 = {U2 * 1000:.6f} meV\n")
        f.write(f"J_signed = {J_SIGNED * 1000:.9f} meV\n")
        f.write(f"|J| = {J_ABS * 1000:.9f} meV\n")
        f.write(f"2|J| = {2 * J_ABS * 1000:.9f} meV\n")
        f.write(f"tX theory = {tX_THEORY_FS:.9f} fs\n")
        f.write(f"tX numeric = {tX_NUM_FS:.3f} fs\n")
        f.write("Perturbacao: H11 = U1 + V(r); H33 = U3.\n")
        f.write("Eta values = " + ", ".join(f"{x:g}" for x in [r['eta'] for r in results]) + "\n")
        f.write("\n")
        for r in results:
            f.write(
                f"eta={r['eta']:.2f} | V0={r['V0_meV']:.6f} meV | "
                f"P3max={r['P3max']:.10f} | P2max={r['P2max']:.6e} | "
                f"P1min={r['P1min']:.10f} | Cmax={r['Cmax']:.10f} | "
                f"purity_min={r['puritymin']:.10f} | F_X={r['FX']:.10f} | "
                f"normerr={r['normerr']:.3e}\n"
            )
    return csv_path, txt_path


def make_publication_figure(results, outdir: Path):
    eta = np.array([r["eta"] for r in results])
    p3 = np.array([r["P3max"] for r in results])
    p2 = np.array([r["P2max"] for r in results])
    p1 = np.array([r["P1min"] for r in results])
    coh = np.array([r["Cmax"] for r in results])
    pur = np.array([r["puritymin"] for r in results])
    fx = np.array([r["FX"] for r in results])

    fig, axs = plt.subplots(1, 2, figsize=(10.6, 4.35), dpi=300)
    fig.patch.set_alpha(0.0)

    ax = axs[0]
    ax.plot(eta, p3, "o-", lw=1.6, ms=4.2, label=r"$\max_t P_3$")
    ax.plot(eta, p1, "s--", lw=1.4, ms=4.0, label=r"$\min_t P_1$")
    ax.plot(eta, p2, "^:", lw=1.3, ms=3.8, label=r"$\max_t P_2$")
    ax.axvline(1.0, lw=0.8, ls=":")
    ax.set_xlabel(r"$\eta=V_0/(2|J|)$")
    ax.set_ylabel(r"$\mathrm{Population}$")
    ax.set_xlim(float(eta.min()), float(eta.max()))
    ax.set_ylim(-0.05, 1.10)
    ax.text(0.03, 1.02, "(a)", transform=ax.transAxes, va="bottom", clip_on=False)
    ax.legend(loc="best")
    polish(ax)

    ax = axs[1]
    ax.plot(eta, coh, "o-", lw=1.6, ms=4.2, label=r"$\max_t|\rho_{13}|$")
    ax.plot(eta, pur, "s--", lw=1.4, ms=4.0,
            label=r"$\min_t\,\mathrm{Tr}(\rho_{\mathrm{layer}}^2)$")
    ax.plot(eta, fx, "^-.", lw=1.3, ms=3.8, label=r"$F_X(t_X)$")
    ax.axvline(1.0, lw=0.8, ls=":")
    ax.set_xlabel(r"$\eta=V_0/(2|J|)$")
    ax.set_ylabel(r"$\mathrm{Coherence/purity/fidelity}$")
    ax.set_xlim(float(eta.min()), float(eta.max()))
    ax.set_ylim(-0.05, 1.10)
    ax.text(0.03, 1.02, "(b)", transform=ax.transAxes, va="bottom", clip_on=False)
    ax.legend(loc="best")
    polish(ax)

    fig.subplots_adjust(left=0.075, right=0.985, bottom=0.20, top=0.95, wspace=0.28)
    pdf = outdir / "perturbation_strength_eta_sweep.pdf"
    png = outdir / "perturbation_strength_eta_sweep.png"
    fig.savefig(pdf, format="pdf", bbox_inches="tight", pad_inches=0.01, transparent=True)
    fig.savefig(png, format="png", dpi=450, bbox_inches="tight", pad_inches=0.01, transparent=True)
    plt.close(fig)
    return pdf, png


# =============================================================================
# MAIN
# =============================================================================
def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--quick", action="store_true",
                        help="grade 128x128 e eta=(0,1,10), mantendo t_X=4135.5 fs")
    return parser.parse_args()


def main():
    args = parse_args()

    if args.quick:
        nx = ny = NX_QUICK
        wx = wy = WX_QUICK
        nt = NT_QUICK
        save_step = SAVE_STEP_QUICK
        eta_values = ETA_QUICK
        mode = "QUICK"
        outdir = Path(__file__).resolve().parent / "perturbation_strength_eta_sweep_quick_results"
    else:
        nx = ny = NX_PROD
        wx = wy = WX_PROD
        nt = NT_PROD
        save_step = SAVE_STEP_PROD
        eta_values = ETA_PRODUCTION
        mode = "PRODUÇÃO"
        outdir = Path(__file__).resolve().parent / "perturbation_strength_eta_sweep_results"

    if not np.isclose(HBAR, 0.658211928, atol=1e-12):
        raise RuntimeError("hbar inconsistente")
    if not np.isclose(tX_NUM_FS, 4135.5, atol=1e-12):
        raise RuntimeError(f"t_X,num inesperado: {tX_NUM_FS}")

    X, Y, dx, dy, T_half, phi0 = build_grid(nx, ny, wx, wy)
    initial_norm = float(np.sum(np.abs(phi0) ** 2) * dx * dy)

    print("=" * 100)
    print(f"ETAPA 8 — VARREDURA eta = V0/(2|J|) [{mode}]")
    print("Hamiltoniano físico completo 3x3 + pacote 2D + Split-Step Fourier")
    print("=" * 100)
    print(f"Delta12 = Delta23 = {DELTA12 * 1000:.3f} meV")
    print(f"U2 = {U2 * 1000:.3f} meV")
    print(f"J_signed = {J_SIGNED * 1000:.9f} meV")
    print(f"|J| = {J_ABS * 1000:.9f} meV")
    print(f"2|J| = {2 * J_ABS * 1000:.9f} meV")
    print(f"t_X teórico = {tX_THEORY_FS:.9f} fs")
    print(f"t_X numérico = {tX_NUM_FS:.3f} fs")
    print(f"grid = {nx} x {ny}")
    print(f"caixa = {wx:.1f} x {wy:.1f} nm^2")
    print(f"dx = dy = {dx:.6f} nm")
    print(f"dt = {DT:.3f} fs | NT = {nt} | janela = {nt * DT:.1f} fs")
    print(f"sigma = {SIGMA:.1f} nm | x0 = {X0:.1f} nm | width = {WIDTH:.1f} nm")
    print(f"eta = {eta_values}")
    print(f"eta=10 -> V0 = {REFERENCE_V0_MEV:.3f} meV")
    print(f"norma inicial = {initial_norm:.12e}")
    print(f"SciPy FFT workers = {SCIPY_FFT}")
    print("Perturbacao: H11=U1+V(r), H22=U2, H33=U3")
    print("=" * 100)

    results = []
    total_start = time.perf_counter()

    for idx, eta in enumerate(eta_values, start=1):
        print(f"\nSIMULAÇÃO {idx}/{len(eta_values)}")
        results.append(simulate_eta(eta, X, Y, dx, dy, T_half, phi0, nt, save_step))

    total_time = time.perf_counter() - total_start
    csv_path, report_path = save_results(results, outdir)
    pdf_path, png_path = make_publication_figure(results, outdir)

    max_norm_err = max(r["normerr"] for r in results)
    max_local_unitarity = max(r["unitarity_local_err"] for r in results)

    print("\n" + "=" * 100)
    print("RESULTADO FINAL — ETAPA 8")
    print("=" * 100)
    print(f"{'eta':>7} {'V0(meV)':>10} {'P3max':>11} {'P2max':>12} {'P1min':>11} "
          f"{'Cmax':>11} {'pur_min':>11} {'F_X':>11}")
    print("-" * 100)
    for r in results:
        print(f"{r['eta']:7.2f} {r['V0_meV']:10.4f} {r['P3max']:11.6f} "
              f"{r['P2max']:12.4e} {r['P1min']:11.6f} {r['Cmax']:11.6f} "
              f"{r['puritymin']:11.6f} {r['FX']:11.9f}")
    print("-" * 100)
    print(f"max norm error = {max_norm_err:.3e}")
    print(f"max local unitarity error = {max_local_unitarity:.3e}")
    print(f"total runtime = {total_time / 60:.2f} min")
    print("=" * 100)

    # Referência física central: eta=10, V0=5 meV.
    r10 = min(results, key=lambda r: abs(r["eta"] - REFERENCE_ETA))
    print(f"\nPONTO DE REFERÊNCIA eta=10: F_X={r10['FX']:.9f}, "
          f"P2max={100*r10['P2max']:.6f} %, purity_min={r10['puritymin']:.6f}")
    print(f"Arquivos: {pdf_path}, {png_path}, {csv_path}, {report_path}")


if __name__ == "__main__":
    main()
