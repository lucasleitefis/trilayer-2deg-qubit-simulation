#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FIG. 2 — COHERENT DYNAMICS: FULL 3x3 VS EFFECTIVE 2x2
=======================================================

Purpose
-------
This is a post-processing/publication script for the revised coherent-dynamics
figure discussed in response to the referee's Sec. 2.4 comment.

The referee noted that the original Fig. 2 and Fig. 3 appeared to use
inconsistent dynamical periods and recommended putting the complete three-level
and effective two-level descriptions on the same time axis/panel.  This script
implements that comparison in one consolidated three-panel figure.

The script DOES NOT introduce a new dynamical model and does NOT alter any
physical parameter used in the manuscript.  It combines the already generated
canonical coherent-data output containing both descriptions:

    coherent_layer_qubit_dynamics_data.npz

That data file is produced by the final canonical coherent-dynamics solver:

    coherent_layer_qubit_dynamics.py

Frozen physical parameters
--------------------------
    Delta12 = Delta23 = 5 meV
    U1 = U3 = 0 meV
    U2 = 100 meV
    J = -Delta12*Delta23/U2 = -0.25 meV
    |J| = 0.25 meV
    Teff = pi*hbar/|J| = 8271.335 fs
    tX = Teff/2 = 4135.668 fs

Frozen numerical/time window used by the figure data
-----------------------------------------------------
    dt = 0.5 fs
    time window = 0--20 ps

Figure design
-------------
(a) Complete physical 3x3 dynamics: rho_11, rho_22, rho_33.
    This preserves the explicit intermediate-layer occupation.

(b) Direct comparison of the OUTER-LAYER populations from the complete 3x3
    model and the Schrieffer-Wolff effective 2x2 model on exactly the same
    0--20 ps time axis.  The same color identifies the same logical layer;
    line style distinguishes the full and effective descriptions.

(c) Zoom of rho_22(t), shown in green, including the 1% reference line
    and the maximum value. The annotations are kept above the trace so that
    the rapidly oscillating leakage signal remains readable.

Why this structure is used
--------------------------
The revised panel (b) directly implements the referee's requested
3x3-versus-2x2 overlay.  It makes the reduction test explicit instead of
forcing the reader to compare two separately scaled figures.  The full-3x3
curves are not replaced by the effective model: colors encode the logical
layer and line style encodes the model, while the panel-B legend contains
only the full-versus-effective distinction.

Important interpretation
------------------------
The effective model is a reference reduction, not an exact identity for the
full three-level dynamics at all times.  Small deviations are therefore
retained rather than hidden.  In particular, the full 3x3 dynamics contains
finite auxiliary-layer occupation and corresponding higher-order corrections.

Outputs
-------
    Fig02_coherent_3x3_vs_2x2.pdf
    Fig02_coherent_3x3_vs_2x2.png

No simulation is performed by this script.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt


# =============================================================================
# PUBLICATION STYLE
# =============================================================================

BLUE = "blue"
RED = "red"
GREEN = "#007A00"
BLACK = "black"
GRAY = "0.45"
LIGHT_GRAY = "0.55"



def configure_matplotlib() -> None:
    """Use exactly the typography conventions of the manuscript figures."""
    plt.rcParams.update({
        "text.usetex": True,
        "font.family": "serif",
        "font.serif": ["Computer Modern Roman"],
        "text.latex.preamble": r"\usepackage{amsmath}",
        "font.size": 17,
        "axes.labelsize": 20,
        "axes.titlesize": 17,
        "legend.fontsize": 17,
        "xtick.labelsize": 15,
        "ytick.labelsize": 15,
        "axes.linewidth": 0.8,
        "xtick.direction": "in",
        "ytick.direction": "in",
        "xtick.top": True,
        "ytick.right": True,
        "xtick.major.size": 4,
        "ytick.major.size": 4,
        "xtick.major.width": 0.8,
        "ytick.major.width": 0.8,
        "xtick.minor.visible": True,
        "ytick.minor.visible": True,
        "xtick.minor.size": 2,
        "ytick.minor.size": 2,
        "xtick.minor.width": 0.6,
        "ytick.minor.width": 0.6,
        "legend.frameon": False,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.03,
    })



def polish_axes(ax, grid: bool = True) -> None:
    ax.tick_params(
        which="major",
        direction="in",
        top=True,
        right=True,
        length=4.5,
        width=0.75,
    )
    ax.tick_params(
        which="minor",
        direction="in",
        top=True,
        right=True,
        length=2.2,
        width=0.55,
    )
    if grid:
        ax.grid(True, which="major", alpha=0.18, linewidth=0.45, linestyle="--")
    else:
        ax.grid(False)

    for spine in ax.spines.values():
        spine.set_linewidth(0.8)


# =============================================================================
# DATA LOADING
# =============================================================================


def load_data(data_path: Path) -> dict[str, np.ndarray]:
    """Load the canonical coherent 3x3/effective 2x2 data file."""
    if not data_path.exists():
        raise FileNotFoundError(
            f"Canonical data file not found:\n  {data_path}\n\n"
            "Run coherent_layer_qubit_dynamics.py in the same directory first "
            "to generate coherent_layer_qubit_dynamics_data.npz, or pass --data "
            "with the exact path to an existing .npz file."
        )

    with np.load(data_path) as z:
        required = [
            "times_fs",
            "P3",
            "P2_eff",
            "Teff_fs",
            "tx_fs",
            "J_abs_meV",
            "U2_meV",
            "Delta12_meV",
            "Delta23_meV",
        ]
        missing = [key for key in required if key not in z]
        if missing:
            raise KeyError(
                "The supplied canonical data file is missing required fields: "
                + ", ".join(missing)
            )

        return {key: np.asarray(z[key]) for key in z.files}


# =============================================================================
# FIGURE
# =============================================================================


def build_figure(data: dict[str, np.ndarray], output_pdf: Path, output_png: Path) -> None:
    times_ps = data["times_fs"] / 1000.0
    p3x3 = data["P3"]
    p2_eff = data["P2_eff"]

    if p3x3.shape[0] != 3 or p2_eff.shape[0] != 2:
        raise ValueError(
            "Unexpected population array shapes: "
            f"P3={p3x3.shape}, P2_eff={p2_eff.shape}."
        )

    # Full 3x3 populations.
    rho11_3 = p3x3[0]
    rho22_3 = p3x3[1]
    rho33_3 = p3x3[2]

    # Effective 2x2 populations.
    rho11_2 = p2_eff[0]
    rho33_2 = p2_eff[1]

    # Direct consistency diagnostics.
    max_diff_rho11 = float(np.max(np.abs(rho11_3 - rho11_2)))
    max_diff_rho33 = float(np.max(np.abs(rho33_3 - rho33_2)))
    max_diff_outer = max(max_diff_rho11, max_diff_rho33)
    p2_max = float(np.max(rho22_3))

    teff_ps = float(data["Teff_fs"]) / 1000.0
    tx_ps = float(data["tx_fs"]) / 1000.0
    time_end_ps = float(times_ps[-1])

    # The vertical scale is intentionally generous: panels (a) and (b) are
    # kept close to the standalone Fig. 2(a)/Fig. 3 height used in the paper,
    # so the three-panel consolidation does not compress the dynamics.
    fig, axes = plt.subplots(
        3,
        1,
        figsize=(7.2, 11.2),
        sharex=True,
        gridspec_kw={"height_ratios": [1.40, 1.40, 0.90]},
    )
    fig.patch.set_facecolor("white")

    ax_a, ax_b, ax_c = axes

    # -------------------------------------------------------------------------
    # Panel (a): complete physical dynamics
    # -------------------------------------------------------------------------
    ax_a.plot(
        times_ps,
        rho11_3,
        color=BLUE,
        linestyle="-",
        linewidth=1.55,
        label=r"$\rho_{11}$",
    )
    ax_a.plot(
        times_ps,
        rho22_3,
        color=GREEN,
        linestyle=":",
        linewidth=1.45,
        label=r"$\rho_{22}$",
    )
    ax_a.plot(
        times_ps,
        rho33_3,
        color=RED,
        linestyle="--",
        linewidth=1.55,
        label=r"$\rho_{33}$",
    )

    ax_a.text(
        0.025,
        0.96,
        r"(a)",
        transform=ax_a.transAxes,
        fontsize=18,
        va="top",
        ha="left",
        clip_on=True,
    )
    ax_a.set_ylabel("Population")
    # Extra headroom is deliberate: it keeps the legend and panel label
    # inside the axes, as in the other manuscript figures.
    ax_a.set_ylim(-0.05, 1.32)

    from matplotlib.lines import Line2D
    full_handle = Line2D([0], [0], color=BLACK, linestyle="-", linewidth=1.65,
                         label=r"Full $3\times3$")
    pop_handles = [
        Line2D([0], [0], color=BLUE, linestyle="-", linewidth=1.55, label=r"$\rho_{11}$"),
        Line2D([0], [0], color=GREEN, linestyle=":", linewidth=1.45, label=r"$\rho_{22}$"),
        Line2D([0], [0], color=RED, linestyle="--", linewidth=1.55, label=r"$\rho_{33}$"),
        full_handle,
    ]
    ax_a.legend(
        handles=pop_handles,
        loc="upper right",
        bbox_to_anchor=(0.97, 0.955),
        ncol=2,
        columnspacing=1.5,
        handlelength=2.1,
        handletextpad=0.5,
        borderaxespad=0.0,
        frameon=False,
        fontsize=17,
    )
    polish_axes(ax_a)

    # -------------------------------------------------------------------------
    # Panel (b): direct 3x3 vs 2x2 comparison
    # -------------------------------------------------------------------------
    # Color identifies the logical layer; line style identifies the model.
    ax_b.plot(
        times_ps,
        rho11_3,
        color=BLUE,
        linestyle="-",
        linewidth=1.65,
    )
    ax_b.plot(
        times_ps,
        rho33_3,
        color=RED,
        linestyle="-",
        linewidth=1.65,
    )
    ax_b.plot(
        times_ps,
        rho11_2,
        color=BLUE,
        linestyle="--",
        linewidth=1.35,
    )
    ax_b.plot(
        times_ps,
        rho33_2,
        color=RED,
        linestyle="--",
        linewidth=1.35,
    )

    ax_b.axvline(
        tx_ps,
        color=LIGHT_GRAY,
        linestyle=":",
        linewidth=0.85,
        alpha=0.9,
    )

    ax_b.text(
        0.025,
        0.96,
        r"(b)",
        transform=ax_b.transAxes,
        fontsize=18,
        va="top",
        ha="left",
        clip_on=True,
    )
    ax_b.set_ylabel("Population")
    ax_b.set_ylim(-0.05, 1.32)

    # The full 3x3 reference is already identified in panel (a).
    # Here only the effective 2x2 reduction is labeled, as requested.
    effective_handle = Line2D(
        [0], [0], color=BLACK, linestyle="--", linewidth=1.35,
        label=r"Effective $2\times2$"
    )
    ax_b.legend(
        handles=[effective_handle],
        loc="upper right",
        bbox_to_anchor=(0.97, 0.955),
        handlelength=2.2,
        handletextpad=0.55,
        borderaxespad=0.0,
        frameon=False,
        fontsize=17,
    )
    polish_axes(ax_b)

    # -------------------------------------------------------------------------
    # Panel (c): intermediate-state zoom
    # -------------------------------------------------------------------------
    ax_c.plot(
        times_ps,
        rho22_3,
        color=GREEN,
        linestyle="-",
        linewidth=0.60,
        alpha=1.0,
    )
    ax_c.axhline(
        0.01,
        color=BLACK,
        linestyle="--",
        linewidth=0.9,
    )

    ax_c.text(
        0.025,
        0.92,
        r"(c)",
        transform=ax_c.transAxes,
        fontsize=18,
        va="top",
        ha="left",
        clip_on=True,
    )
    ax_c.set_xlabel("Time (ps)")
    ax_c.set_ylabel(r"$\rho_{22}$")
    # Reserve a clearly visible white region above the leakage trace.
    ax_c.set_ylim(0.0, max(0.017, 1.72 * p2_max))
    polish_axes(ax_c)

    # Both labels stay above the green trace and the 1% reference line.
    ax_c.text(
        0.965,
        0.70,
        r"$1\%$",
        transform=ax_c.transAxes,
        ha="right",
        va="bottom",
        fontsize=16,
        color=BLACK,
    )
    ax_c.text(
        0.965,
        0.84,
        rf"$\rho_{{22}}^{{\max}}={100*p2_max:.3f}\%$",
        transform=ax_c.transAxes,
        ha="right",
        va="bottom",
        fontsize=16,
        color=BLACK,
    )

    xticks = np.arange(0.0, time_end_ps + 0.1, 2.5)
    ax_c.set_xticks(xticks)
    ax_c.set_xlim(0.0, time_end_ps)

    fig.tight_layout(h_pad=1.05, rect=(0.07, 0.035, 0.99, 0.985))
    for ax in axes:
        ax.set_facecolor("white")
    fig.savefig(output_pdf, format="pdf", dpi=600, transparent=False, facecolor="white")
    fig.savefig(output_png, format="png", dpi=600, transparent=False, facecolor="white")
    plt.close(fig)

    print("=" * 90)
    print("FIG. 2 — CONSOLIDATED COHERENT DYNAMICS")
    print("=" * 90)
    print(f"Delta12 = Delta23              : {float(data['Delta12_meV']):.6f} meV")
    print(f"U2                            : {float(data['U2_meV']):.6f} meV")
    print(f"|J|                            : {float(data['J_abs_meV']):.9f} meV")
    print(f"Teff                           : {teff_ps:.6f} ps")
    print(f"t_X                            : {tx_ps:.6f} ps")
    print(f"time window                    : 0 -- {time_end_ps:.6f} ps")
    print(f"P2_max                         : {p2_max:.9e} ({100*p2_max:.6f} %)")
    print(f"max |rho11_3x3-rho11_2x2|     : {max_diff_rho11:.9e}")
    print(f"max |rho33_3x3-rho33_2x2|     : {max_diff_rho33:.9e}")
    print(f"max outer-population deviation : {max_diff_outer:.9e}")
    print(f"PDF                            : {output_pdf}")
    print(f"PNG                            : {output_png}")
    print("=" * 90)


# =============================================================================
# MAIN
# =============================================================================


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Generate the consolidated Fig. 2 comparing full 3x3 and "
            "effective 2x2 coherent dynamics."
        )
    )
    script_dir = Path(__file__).resolve().parent
    default_data = script_dir / "coherent_layer_qubit_dynamics_data.npz"
    parser.add_argument(
        "--data",
        type=Path,
        default=default_data,
        help=(
            "Path to the canonical .npz generated by coherent_layer_qubit_dynamics.py. "
            "By default, the script looks beside this figure script."
        ),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=script_dir,
        help="Directory for the consolidated figure files (default: beside this script).",
    )
    return parser.parse_args()



def main() -> None:
    args = parse_args()
    configure_matplotlib()

    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    data = load_data(args.data.resolve())

    output_pdf = output_dir / "Fig02_coherent_3x3_vs_2x2.pdf"
    output_png = output_dir / "Fig02_coherent_3x3_vs_2x2.png"

    build_figure(data, output_pdf, output_png)


if __name__ == "__main__":
    main()
