#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
X-gate robustness against outer-layer energy detuning.

PURPOSE
-------
This script sweeps the detuning

    delta U = U1 - U3

and evaluates the X-gate fidelity at the nominal resonant gate time. The results
are computed for both the full 3x3 Hamiltonian and the effective 2x2 model.

FIGURES
-------
A two-panel publication figure is generated:
  - X-gate fidelity versus physical detuning delta U;
  - X-gate fidelity versus the dimensionless detuning delta U/(2|J|).

OUTPUTS
-------
The script saves the numerical sweep and the PDF/PNG figure to its result
directory.

ROLE IN THE REPRODUCTION CHAIN
------------------------------
This is a self-contained sweep-and-plot script. The full 3x3 result is the main
physical reference; the 2x2 curve is included for comparison.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import time

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


# -----------------------------------------------------------------------------
# PHYSICS
# -----------------------------------------------------------------------------
@dataclass(frozen=True)
class PhysicalParameters:
    hbar_meV_fs: float = 658.211928
    Delta12_meV: float = 5.0
    Delta23_meV: float = 5.0
    U2_meV: float = 100.0


@dataclass(frozen=True)
class SweepParameters:
    deltaU_min_meV: float = -1.0
    deltaU_max_meV: float = 1.0
    n_points: int = 21
    dt_fs: float = 0.5


@dataclass(frozen=True)
class FigureStyle:
    full: str = "blue"
    effective: str = "red"
    theory: str = "#2f2f2f"
    lw_main: float = 1.7
    lw_theory: float = 1.25
    label_fontsize: int = 19
    tick_fontsize: int = 15
    legend_fontsize: float = 14.0
    title_fontsize: float = 18.0


# -----------------------------------------------------------------------------
# MATPLOTLIB STYLE — manter padrão dos códigos de publicação
# -----------------------------------------------------------------------------
def configure_matplotlib() -> None:
    plt.rcParams.update({
        "text.usetex": True,
        "font.family": "serif",
        "font.serif": ["Computer Modern Roman"],
        "text.latex.preamble": r"\usepackage{amsmath}",
        "text.color": "black",
        "axes.labelcolor": "black",
        "xtick.color": "black",
        "ytick.color": "black",
        "axes.edgecolor": "black",
        "font.size": 18,
        "axes.labelsize": 19,
        "axes.titlesize": 18,
        "legend.fontsize": 14,
        "xtick.labelsize": 15,
        "ytick.labelsize": 15,
        "axes.linewidth": 0.75,
        "xtick.major.size": 5,
        "ytick.major.size": 5,
        "xtick.major.width": 0.75,
        "ytick.major.width": 0.75,
        "xtick.minor.visible": True,
        "ytick.minor.visible": True,
        "xtick.minor.size": 2.5,
        "ytick.minor.size": 2.5,
        "xtick.minor.width": 0.55,
        "ytick.minor.width": 0.55,
        "figure.dpi": 300,
        "savefig.dpi": 450,
    })


def polish_axes(ax) -> None:
    ax.tick_params(which="major", direction="in", top=True, right=True,
                   length=5, width=0.75)
    ax.tick_params(which="minor", direction="in", top=True, right=True,
                   length=2.5, width=0.55)
    ax.grid(True, which="major", alpha=0.22, linewidth=0.55)
    ax.grid(True, which="minor", alpha=0.10, linewidth=0.40)


# -----------------------------------------------------------------------------
# HAMILTONIANS / PROPAGATORS
# -----------------------------------------------------------------------------
def effective_coupling(phys: PhysicalParameters) -> tuple[float, float]:
    J_signed = -(phys.Delta12_meV * phys.Delta23_meV) / phys.U2_meV
    J_abs = abs(J_signed)
    return J_signed, J_abs


def hamiltonian_full_3x3(deltaU_meV: float, phys: PhysicalParameters) -> np.ndarray:
    U1 = 0.5 * deltaU_meV
    U3 = -0.5 * deltaU_meV
    return np.array([
        [U1, phys.Delta12_meV, 0.0],
        [phys.Delta12_meV, phys.U2_meV, phys.Delta23_meV],
        [0.0, phys.Delta23_meV, U3],
    ], dtype=np.complex128)


def hamiltonian_effective_2x2(deltaU_meV: float, J_signed: float) -> np.ndarray:
    return np.array([
        [0.5 * deltaU_meV, J_signed],
        [J_signed, -0.5 * deltaU_meV],
    ], dtype=np.complex128)


def unitary_from_hermitian(H: np.ndarray, t_fs: float, hbar_meV_fs: float) -> np.ndarray:
    evals, evecs = np.linalg.eigh(H)
    phase = np.exp(-1j * evals * t_fs / hbar_meV_fs)
    return (evecs * phase) @ evecs.conj().T


def fidelity_x_from_state(state: np.ndarray) -> float:
    """Population in target |3> for the 3x3 model, or target logical |3> for 2x2."""
    return float(np.abs(state[-1]) ** 2)


# -----------------------------------------------------------------------------
# MAIN CALCULATION
# -----------------------------------------------------------------------------
def run_sweep(phys: PhysicalParameters, sweep: SweepParameters):
    J_signed, J_abs = effective_coupling(phys)
    t_X_fs = np.pi * phys.hbar_meV_fs / (2.0 * J_abs)
    t_gate_num_fs = round(t_X_fs / sweep.dt_fs) * sweep.dt_fs
    omega_eff_fs = 2.0 * J_abs / phys.hbar_meV_fs

    deltaU = np.linspace(sweep.deltaU_min_meV, sweep.deltaU_max_meV, sweep.n_points)
    FX_full = np.empty_like(deltaU)
    FX_eff = np.empty_like(deltaU)
    unitary_err_full = np.empty_like(deltaU)
    unitary_err_eff = np.empty_like(deltaU)

    psi0_full = np.array([1.0, 0.0, 0.0], dtype=np.complex128)
    psi0_eff = np.array([1.0, 0.0], dtype=np.complex128)

    for i, dU in enumerate(deltaU):
        H3 = hamiltonian_full_3x3(dU, phys)
        U3 = unitary_from_hermitian(H3, t_gate_num_fs, phys.hbar_meV_fs)
        psi3 = U3 @ psi0_full
        FX_full[i] = fidelity_x_from_state(psi3)
        unitary_err_full[i] = np.max(np.abs(U3.conj().T @ U3 - np.eye(3)))

        H2 = hamiltonian_effective_2x2(dU, J_signed)
        U2 = unitary_from_hermitian(H2, t_X_fs, phys.hbar_meV_fs)
        psi2 = U2 @ psi0_eff
        FX_eff[i] = fidelity_x_from_state(psi2)
        unitary_err_eff[i] = np.max(np.abs(U2.conj().T @ U2 - np.eye(2)))

    return {
        "deltaU_meV": deltaU,
        "eta": deltaU / (2.0 * J_abs),
        "FX_full": FX_full,
        "FX_eff": FX_eff,
        "J_signed": J_signed,
        "J_abs": J_abs,
        "omega_eff_fs": omega_eff_fs,
        "t_X_fs": t_X_fs,
        "t_gate_num_fs": t_gate_num_fs,
        "dt_fs": sweep.dt_fs,
        "max_unitary_err_full": float(np.max(unitary_err_full)),
        "max_unitary_err_eff": float(np.max(unitary_err_eff)),
    }


# -----------------------------------------------------------------------------
# FIGURE
# -----------------------------------------------------------------------------
def make_figure(results: dict, outdir: Path, style: FigureStyle) -> Path:
    deltaU = results["deltaU_meV"]
    eta = results["eta"]
    full = results["FX_full"]
    eff = results["FX_eff"]

    fig, axs = plt.subplots(1, 2, figsize=(10.6, 4.35), dpi=300)
    fig.patch.set_alpha(0)

    # Physical detuning
    ax = axs[0]
    ax.plot(deltaU, full, color=style.full, lw=style.lw_main,
            linestyle="-", label=r"Full three-layer model")
    ax.plot(deltaU, eff, color=style.effective, lw=style.lw_main,
            linestyle="--", label=r"Effective two-level model")
    ax.axvline(0.0, color="black", lw=0.9, linestyle=":", alpha=0.7)
    ax.set_xlabel(r"$\delta U=U_1-U_3$ (meV)")
    ax.set_ylabel(r"$F_X(t_X)$")
    ax.set_xlim(deltaU[0], deltaU[-1])
    ax.set_ylim(-0.02, 1.02)
    ax.legend(loc="best", frameon=False, fontsize=style.legend_fontsize)
    polish_axes(ax)

    # Dimensionless detuning
    ax = axs[1]
    ax.plot(eta, full, color=style.full, lw=style.lw_main,
            linestyle="-", label=r"Full three-layer model")
    ax.plot(eta, eff, color=style.effective, lw=style.lw_main,
            linestyle="--", label=r"Effective two-level model")
    ax.axvline(0.0, color="black", lw=0.9, linestyle=":", alpha=0.7)
    ax.set_xlabel(r"$\delta U/(2|J|)$")
    ax.set_ylabel(r"$F_X(t_X)$")
    ax.set_xlim(eta[0], eta[-1])
    ax.set_ylim(-0.02, 1.02)
    ax.legend(loc="best", frameon=False, fontsize=style.legend_fontsize)
    polish_axes(ax)

    fig.subplots_adjust(left=0.085, right=0.985, bottom=0.205,
                        top=0.965, wspace=0.28)

    outfile = outdir / "x_gate_detuning_robustness.pdf"
    fig.savefig(outfile, format="pdf", bbox_inches="tight", pad_inches=0.02)
    fig.savefig(outfile.with_suffix(".png"), format="png", dpi=450,
                bbox_inches="tight", pad_inches=0.02)
    plt.close(fig)
    return outfile


# -----------------------------------------------------------------------------
# SAVE DATA / REPORT
# -----------------------------------------------------------------------------
def save_results(results: dict, outdir: Path) -> None:
    table = np.column_stack([
        results["deltaU_meV"],
        results["eta"],
        results["FX_full"],
        results["FX_eff"],
    ])
    np.savetxt(
        outdir / "x_gate_detuning_robustness.dat",
        table,
        header="deltaU_meV deltaU_over_2absJ FX_full_3x3 FX_effective_2x2",
    )


def main() -> None:
    configure_matplotlib()
    phys = PhysicalParameters()
    sweep = SweepParameters()
    style = FigureStyle()
    outdir = Path(__file__).resolve().parent / "x_gate_detuning_robustness_results"
    outdir.mkdir(parents=True, exist_ok=True)

    J_signed, J_abs = effective_coupling(phys)
    t_X_fs = np.pi * phys.hbar_meV_fs / (2.0 * J_abs)

    print("=" * 88)
    print("ROBUSTEZ DA OPERAÇÃO X AO DESBALANCEAMENTO DE ENERGIA")
    print("=" * 88)
    print(f"Delta12              : {phys.Delta12_meV:.6f} meV")
    print(f"Delta23              : {phys.Delta23_meV:.6f} meV")
    print(f"U2                   : {phys.U2_meV:.6f} meV")
    print(f"J_signed             : {J_signed:.12f} meV")
    print(f"|J|                  : {J_abs:.12f} meV")
    print(f"Omega_eff            : {2*J_abs/phys.hbar_meV_fs:.12e} fs^-1")
    t_gate_num_fs_report = round(t_X_fs / sweep.dt_fs) * sweep.dt_fs
    print(f"t_X (ideal)           : {t_X_fs:.12f} fs")
    print(f"t_X (numerical grid)  : {t_gate_num_fs_report:.12f} fs")
    print(f"dt                    : {sweep.dt_fs:.3f} fs")
    print(f"deltaU range         : [{sweep.deltaU_min_meV:.3f}, {sweep.deltaU_max_meV:.3f}] meV")
    print(f"number of points     : {sweep.n_points}")
    print("-")

    tic = time.time()
    results = run_sweep(phys, sweep)
    t_gate_num_fs = results["t_gate_num_fs"]
    elapsed = time.time() - tic

    i0 = int(np.argmin(np.abs(results["deltaU_meV"])))
    max_diff = float(np.max(np.abs(results["FX_full"] - results["FX_eff"])))

    print(f"F_X full at deltaU=0: {results['FX_full'][i0]:.10f}")
    print(f"numerical gate time    : {t_gate_num_fs:.6f} fs")
    print(f"F_X eff  at deltaU=0: {results['FX_eff'][i0]:.10f}")
    print(f"max |F_full-F_eff|   : {max_diff:.6e}")
    print(f"max unitarity err 3x3: {results['max_unitary_err_full']:.3e}")
    print(f"max unitarity err 2x2: {results['max_unitary_err_eff']:.3e}")
    print(f"runtime               : {elapsed:.3f} s")

    save_results(results, outdir)
    figpath = make_figure(results, outdir, style)

    center_ok = abs(results["FX_full"][i0] - 0.999932805866) < 2.0e-9
    unitary_ok = results["max_unitary_err_full"] < 1e-12 and results["max_unitary_err_eff"] < 1e-12
    finite_ok = np.all(np.isfinite(results["FX_full"])) and np.all(np.isfinite(results["FX_eff"]))

    print("-" * 88)
    print(f"benchmark resonante     : {'PASS' if center_ok else 'CHECK'}")
    print(f"unitariedade            : {'PASS' if unitary_ok else 'FAIL'}")
    print(f"dados finitos           : {'PASS' if finite_ok else 'FAIL'}")
    print("=" * 88)
    print("ETAPA 5 — X-GATE DETUNING ROBUSTNESS: " + ("PASS" if center_ok and unitary_ok and finite_ok else "CHECK"))
    print(f"Figura: {figpath}")


if __name__ == "__main__":
    main()
