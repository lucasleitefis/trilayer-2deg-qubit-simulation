# Figure 9 — Perturbed layer-qubit dynamics

The production code for this figure is:

`../../simulations/perturbation/perturbed_layer_qubit_dynamics.py`

It generates the perturbed populations, purity, and coherence used in Fig. 9.
