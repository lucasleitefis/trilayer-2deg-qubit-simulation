#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Renderer da tomografia + esfera de Bloch com a geometria da figura do paper.

A regra aqui e simples: a dinamica nao e recalculada. O script apenas le o
arquivo .npz ja produzido pelo solver 3x3 e faz a diagramacao final.

Layout mapeado da figura de referencia:
  - cabecalho das 5 colunas;
  - coluna esquerda para Re(rho), Im(rho), Bloch sphere;
  - grade completa envolvendo tomografia e os dois indicadores numericos;
  - esferas circulares, sem achatamento vertical;
  - tipografia externa uniformizada em Computer Modern;
  - legenda inferior na mesma linguagem tipografica do paper.

Uso:
  python3 perturbed_state_tomography_bloch_sphere_PAPER_IDENTICA.py \
      --data /caminho/full_3x3_tomography_V0_5meV.npz
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.colors import Normalize
from matplotlib.patches import FancyArrowPatch
from mpl_toolkits.mplot3d import proj3d


# -----------------------------------------------------------------------------
# TIPOGRAFIA / CORES
# -----------------------------------------------------------------------------
FONT_MAIN = 8.5
FONT_TICK = 5.2
FONT_FOOT = 8.2
FONT_FOOT_TICK = 5.0
LINE = 0.55
BLUE = "royalblue"
RED = "firebrick"
SPHERE = "#EFDDE1"
GRID = (0.58, 0.58, 0.58)
ARROW = "#dc267f"


def configure_matplotlib() -> None:
    plt.rcParams.update({
        "text.usetex": True,
        "text.latex.preamble": r"\usepackage{amsmath}",
        "font.family": "serif",
        "font.serif": ["Computer Modern Roman"],
        "font.size": FONT_MAIN,
        "text.color": "black",
        "axes.labelcolor": "black",
        "xtick.color": "black",
        "ytick.color": "black",
        "axes.edgecolor": "black",
        "axes.linewidth": LINE,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "savefig.bbox": "tight",
    })


def sanitize(v: float) -> str:
    s = f"{v:.6f}".rstrip("0").rstrip(".")
    return s.replace(".", "p").replace("-", "m")


# -----------------------------------------------------------------------------
# TOMOGRAFIA 3D
# -----------------------------------------------------------------------------
def draw_tomography(ax, M: np.ndarray, component: str) -> None:
    data = np.real(M) if component == "Re" else np.imag(M)
    data = np.asarray(data, dtype=float)

    xpos, ypos = np.meshgrid(np.arange(2), np.arange(2), indexing="ij")
    xpos = xpos.ravel()
    ypos = ypos.ravel()
    zpos = np.zeros(4)
    dx = dy = 0.55 * np.ones(4)
    dz = data.ravel()

    norm = Normalize(vmin=-1.0, vmax=1.0)
    colors = cm.coolwarm(norm(dz))
    neutral = np.abs(dz) < 1e-10
    colors[neutral, :3] = np.array([0.78, 0.78, 0.78])
    colors[neutral, 3] = 1.0

    ax.bar3d(
        xpos, ypos, zpos,
        dx, dy, dz,
        color=colors,
        edgecolor="black",
        linewidth=0.28,
        shade=True,
        zsort="average",
    )

    ax.set_xlim(-0.05, 2.0)
    ax.set_ylim(-0.05, 2.0)
    ax.set_zlim(-1.0, 1.0)
    ax.set_xticks([0.275, 1.275])
    ax.set_yticks([0.275, 1.275])
    ax.set_xticklabels([r"$|1\rangle$", r"$|3\rangle$"], fontsize=FONT_TICK)
    ax.set_yticklabels([r"$\langle1|$", r"$\langle3|$"], fontsize=FONT_TICK)
    ax.set_zticks([-1.0, 0.0, 1.0])
    ax.set_zticklabels([r"$-1$", r"$0$", r"$1$"], fontsize=FONT_FOOT_TICK)

    ax.view_init(elev=24, azim=-55)
    # O paper mostra a tomografia levemente compactada, mas nao achatada.
    ax.set_box_aspect((1.0, 1.0, 0.72))
    ax.tick_params(axis="both", which="both", pad=-1.0, labelsize=FONT_TICK)
    ax.tick_params(axis="z", which="both", pad=-0.6, labelsize=FONT_FOOT_TICK)
    ax.grid(False)
    ax.patch.set_alpha(0.0)

    for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
        try:
            axis.pane.fill = False
            axis.pane.set_edgecolor((1, 1, 1, 0))
        except Exception:
            pass


# -----------------------------------------------------------------------------
# ESFERA DE BLOCH — desenho proprio para estabilidade e fidelidade tipografica
# -----------------------------------------------------------------------------
class Arrow3D(FancyArrowPatch):
    def __init__(self, xs, ys, zs, *args, **kwargs):
        super().__init__((0, 0), (0, 0), *args, **kwargs)
        self._verts3d = xs, ys, zs

    def do_3d_projection(self):
        xs3d, ys3d, zs3d = self._verts3d
        xs, ys, zs = proj3d.proj_transform(xs3d, ys3d, zs3d, self.axes.M)
        self.set_positions((xs[0], ys[0]), (xs[1], ys[1]))
        return float(np.min(zs))


def draw_bloch(ax, vec: np.ndarray) -> None:
    vec = np.asarray(vec, dtype=float)
    norm = np.linalg.norm(vec)
    if norm > 1.0 + 1e-9:
        vec = vec / norm

    u = np.linspace(0.0, 2.0 * np.pi, 60)
    v = np.linspace(0.0, np.pi, 32)
    x = np.outer(np.cos(u), np.sin(v))
    y = np.outer(np.sin(u), np.sin(v))
    z = np.outer(np.ones_like(u), np.cos(v))

    ax.plot_surface(
        x, y, z,
        color=SPHERE,
        alpha=0.48,
        linewidth=0,
        shade=False,
        antialiased=True,
    )
    ax.plot_wireframe(
        x, y, z,
        rstride=5,
        cstride=5,
        color=GRID,
        linewidth=0.24,
        alpha=0.42,
    )

    th = np.linspace(0, 2.0 * np.pi, 240)
    ax.plot(np.cos(th), np.sin(th), 0.0 * th, color=GRID, lw=0.24, alpha=0.46)
    ax.plot(np.cos(th), 0.0 * th, np.sin(th), color=GRID, lw=0.22, alpha=0.40)
    ax.plot(0.0 * th, np.cos(th), np.sin(th), color=GRID, lw=0.22, alpha=0.40)

    arrow = Arrow3D(
        [0.0, float(vec[0])],
        [0.0, float(vec[1])],
        [0.0, float(vec[2])],
        mutation_scale=10,
        lw=1.1,
        arrowstyle="-|>",
        color=ARROW,
    )
    ax.add_artist(arrow)

    ax.set_xlim(-1.04, 1.04)
    ax.set_ylim(-1.04, 1.04)
    ax.set_zlim(-1.04, 1.04)
    ax.set_box_aspect((1.0, 1.0, 1.0), zoom=1.18)
    ax.view_init(elev=30, azim=-60)
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_zticks([])
    ax.set_axis_off()
    ax.patch.set_alpha(0.0)

    ax.text(-0.92, -0.48, -0.88, r"$x$", fontsize=FONT_FOOT_TICK, color=(0.30, 0.30, 0.30))
    ax.text(0.90, -0.48, -0.88, r"$y$", fontsize=FONT_FOOT_TICK, color=(0.30, 0.30, 0.30))
    ax.text(0.0, 0.0, 1.10, r"$z$", fontsize=FONT_FOOT_TICK, color=(0.30, 0.30, 0.30))


# -----------------------------------------------------------------------------
# DADOS
# -----------------------------------------------------------------------------
def load_observables(data_path: Path):
    d = np.load(data_path)
    rho3 = np.asarray(d["rho_layer_samples"], dtype=np.complex128)
    if rho3.shape[0:2] != (3, 3):
        raise ValueError(f"rho_layer_samples deve ser 3x3; recebido {rho3.shape}")

    n = rho3.shape[2]
    rho_outer = rho3[np.ix_([0, 2], [0, 2], np.arange(n))]
    rho13 = rho3[0, 2, :]
    purity = np.real(np.einsum("abk,bak->k", rho3, rho3))
    coherence = np.abs(rho13)
    bloch = np.vstack([
        2.0 * np.real(rho13),
        -2.0 * np.imag(rho13),
        np.real(rho3[0, 0, :] - rho3[2, 2, :]),
    ])

    times = np.asarray(d["sample_times_fs"], dtype=float)
    teff = float(d["Teff_fs"])
    targets = np.array([0.0, teff / 4.0, teff / 2.0, 3.0 * teff / 4.0, teff])
    idx = np.array([int(np.argmin(np.abs(times - t))) for t in targets])

    return d, rho_outer[:, :, idx], purity[idx], coherence[idx], bloch[:, idx], targets


# -----------------------------------------------------------------------------
# FIGURA — coordenadas mapeadas diretamente da referencia
# -----------------------------------------------------------------------------
def make_figure(data_path: Path, out: Path) -> None:
    d, rho, purity, coherence, bloch, requested_times = load_observables(data_path)

    # A referencia tem aproximadamente 1.32:1 de proporcao. O tamanho abaixo
    # mantem o desenho arejado, sem comprimir verticalmente a linha das esferas.
    fig = plt.figure(figsize=(466.478/72.0, 347.328/72.0), dpi=300)

    # Coordenadas normalizadas, mapeadas da figura de referencia.
    x_left = 0.138
    x_label_right = 0.239
    x_right = 0.874
    col_edges = np.linspace(x_label_right, x_right, 6)

    y_header_top = 0.925
    y_header_bottom = 0.892
    y_re_bottom = 0.710
    y_im_bottom = 0.526
    y_bloch_bottom = 0.296
    y_purity_bottom = 0.214
    y_coh_bottom = 0.132

    # --- cabecalho das colunas ---
    header_labels = [
        r"$t=0$",
        r"$T/4$",
        r"$T/2=t_X$",
        r"$3T/4$",
        r"$T=T_{\mathrm{eff}}$",
    ]
    for j, lab in enumerate(header_labels):
        xc = 0.5 * (col_edges[j] + col_edges[j + 1])
        fig.text(xc, 0.908, lab, ha="center", va="center", fontsize=FONT_MAIN)

    # --- eixos das 15 celulas ---
    # Os eixos sao manualmente posicionados para reproduzir a tabela, em vez
    # de depender de hspace/subplots_adjust.
    row_specs = [
        (y_re_bottom, 0.175),
        (y_im_bottom, 0.175),
        (y_bloch_bottom, 0.205),
    ]

    for j in range(5):
        x0 = col_edges[j] + 0.010
        w = (col_edges[j + 1] - col_edges[j]) - 0.020

        # Re e Im
        axr = fig.add_axes([x0, y_re_bottom + 0.018, w, row_specs[0][1]], projection="3d")
        axi = fig.add_axes([x0, y_im_bottom + 0.018, w, row_specs[1][1]], projection="3d")
        draw_tomography(axr, rho[:, :, j], "Re")
        draw_tomography(axi, rho[:, :, j], "Im")

        # Bloch: deixado ligeiramente mais baixo dentro da celula, como na referencia.
        axb = fig.add_axes([x0, y_bloch_bottom + 0.012, w, row_specs[2][1]], projection="3d")
        draw_bloch(axb, bloch[:, j])

    # --- rotulos da coluna esquerda ---
    fig.text(
        0.188, 0.801, r"$\mathrm{Re}(\rho)$",
        ha="center", va="center", fontsize=FONT_MAIN, color=BLUE,
    )
    fig.text(
        0.188, 0.618, r"$\mathrm{Im}(\rho)$",
        ha="center", va="center", fontsize=FONT_MAIN, color=RED,
    )
    fig.text(
        0.188, 0.411, "Bloch sphere",
        ha="center", va="center", fontsize=FONT_MAIN, color="black",
    )

    # --- grade completa: cabecalho + Re + Im + Bloch + metricas ---
    overlay = fig.add_axes([0.0, 0.0, 1.0, 1.0])
    overlay.set_axis_off()

    # linhas verticais do corpo: coluna de labels + cinco colunas
    body_vxs = [x_left, x_label_right, *col_edges[1:-1], x_right]
    # As divisoes das cinco colunas continuam ate o cabecalho; a divisao
    # entre a coluna de labels e os dados tambem fecha o canto superior.
    for x in body_vxs:
        y_top = y_header_top if x != x_left else y_header_bottom
        overlay.plot([x, x], [y_coh_bottom, y_top], color="black", lw=LINE, transform=overlay.transAxes, clip_on=False)

    # linhas horizontais do corpo
    for y in [y_header_bottom, y_re_bottom, y_im_bottom, y_bloch_bottom, y_purity_bottom, y_coh_bottom]:
        overlay.plot([x_left, x_right], [y, y], color="black", lw=LINE, transform=overlay.transAxes, clip_on=False)

    # topo apenas sobre as 5 colunas de dados
    overlay.plot([x_label_right, x_right], [y_header_top, y_header_top], color="black", lw=LINE, transform=overlay.transAxes, clip_on=False)

    # --- tabela numerica ---
    tx = 0.5 * (col_edges[:-1] + col_edges[1:])
    y_pur = 0.255
    y_coh = 0.173

    fig.text(
        0.188, y_pur, r"Purity $\mathrm{Tr}(\rho^2)$",
        ha="center", va="center", fontsize=FONT_MAIN,
    )
    fig.text(
        0.188, y_coh, r"Coherence $|\rho_{13}|$",
        ha="center", va="center", fontsize=FONT_MAIN,
    )
    for j in range(5):
        fig.text(tx[j], y_pur, f"{purity[j]:.3f}", ha="center", va="center", fontsize=FONT_MAIN)
        fig.text(tx[j], y_coh, f"{coherence[j]:.3f}", ha="center", va="center", fontsize=FONT_MAIN)

    # --- legenda inferior ---
    fig.text(0.138, 0.067, r"Blue: $\mathrm{Re}(\rho)$", ha="left", va="center", fontsize=FONT_FOOT)
    fig.text(0.250, 0.067, r"Red: $\mathrm{Im}(\rho)$", ha="left", va="center", fontsize=FONT_FOOT)
    fig.text(0.360, 0.067, r"Arrow: Bloch vector", ha="left", va="center", fontsize=FONT_FOOT)
    fig.text(0.585, 0.067, r"$T=T_{\mathrm{eff}}=\pi\hbar/J$", ha="left", va="center", fontsize=FONT_FOOT)

    fig.savefig(out, format="pdf", bbox_inches="tight", pad_inches=0.02)
    fig.savefig(out.with_suffix(".png"), format="png", dpi=450, bbox_inches="tight", pad_inches=0.02)
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=str, required=True, help="Arquivo .npz do solver full 3x3")
    parser.add_argument("--out", type=str, required=True, help="Arquivo PDF de saida")
    args = parser.parse_args()

    configure_matplotlib()
    data_path = Path(args.data).expanduser().resolve()
    out = Path(args.out).expanduser().resolve()
    if not data_path.exists():
        raise FileNotFoundError(data_path)
    make_figure(data_path, out)
    print("PAPER-IDENTICA RENDER: PASS")
    print(f"Data: {data_path}")
    print(f"PDF:  {out}")
    print(f"PNG:  {out.with_suffix('.png')}")


if __name__ == "__main__":
    main()
