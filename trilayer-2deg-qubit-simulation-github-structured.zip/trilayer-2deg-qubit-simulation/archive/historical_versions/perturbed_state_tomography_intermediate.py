#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Final full-3x3 tomography renderer in the same clean visual language as the paper figure.

No panel dividers are drawn. The figure uses a single Computer Modern/LaTeX
font family, paper-style row/column labels, compact tomography panels, round
Bloch spheres, and a simple metric block below the spheres.

The script reads the already computed FULL 3x3 reduced layer density matrices.
It does not perform physical time evolution.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.colors import Normalize
from matplotlib.patches import FancyArrowPatch
from mpl_toolkits.mplot3d import proj3d

SPHERE = "#EFDDE1"
ARROW = "#dc267f"
BLACK = "#000000"


def configure_matplotlib() -> None:
    plt.rcParams.update({
        "text.usetex": True,
        "text.latex.preamble": r"\usepackage{amsmath}",
        "font.family": "serif",
        "font.serif": ["Computer Modern Roman"],
        "font.size": 8.0,
        "axes.labelsize": 8.0,
        "axes.titlesize": 8.0,
        "xtick.labelsize": 5.4,
        "ytick.labelsize": 5.4,
        "axes.linewidth": 0.55,
        "savefig.bbox": "tight",
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })


def sanitize(v: float) -> str:
    s = f"{v:.6f}".rstrip("0").rstrip(".")
    return s.replace(".", "p").replace("-", "m")


def load_and_validate(path: Path):
    d = np.load(path)
    rho3 = np.asarray(d["rho_layer_samples"], dtype=np.complex128)
    if rho3.shape != (3, 3, 5):
        raise ValueError(f"Esperado rho_layer_samples=(3,3,5); recebido {rho3.shape}")
    if np.max(np.abs(rho3 - np.conjugate(np.swapaxes(rho3, 0, 1)))) > 1e-9:
        raise ValueError("rho_layer não é Hermitiana.")
    if np.max(np.abs(np.real(np.trace(rho3, axis1=0, axis2=1)) - 1.0)) > 1e-7:
        raise ValueError("rho_layer não está normalizada.")

    # These metadata checks are only applied when the keys exist, so the renderer
    # remains compatible with previously generated tomography datasets.
    for key, target in (("Delta12_meV", 5.0), ("Delta23_meV", 5.0), ("U2_meV", 100.0)):
        if key in d.files and not np.isclose(float(d[key]), target):
            raise ValueError(f"{key} incompatível com os parâmetros congelados.")
    return d, rho3


def observables(rho3):
    # Logical outer-layer block {|1>,|3>} extracted from the full 3x3 state.
    rho_outer = rho3[np.ix_([0, 2], [0, 2], np.arange(5))]
    rho13 = rho3[0, 2, :]
    purity = np.real(np.einsum("abk,bak->k", rho3, rho3))
    coherence = np.abs(rho13)
    bloch = np.vstack([
        2.0 * np.real(rho13),
        -2.0 * np.imag(rho13),
        np.real(rho3[0, 0, :] - rho3[2, 2, :]),
    ])
    return rho_outer, purity, coherence, bloch


def plot_density_bars(ax, matrix, component):
    """Paper-style 2x2 tomography panel, with cell-sized square footprints matching the internal perspective planes."""
    data = np.real(matrix) if component == "Re" else np.imag(matrix)

    size = 0.650
    shift = (1.00 - size) / 2.0

    xpos, ypos = np.meshgrid(np.arange(2), np.arange(2), indexing="ij")
    xpos = (xpos + shift).ravel()
    ypos = (ypos + shift).ravel()
    dz = np.asarray(data, float).ravel()

    colors = cm.coolwarm(Normalize(-1.0, 1.0)(dz))
    zero = np.abs(dz) < 1e-10
    colors[zero, :3] = np.array([0.78, 0.78, 0.78])
    colors[zero, 3] = 1.0

    ax.bar3d(
        xpos, ypos, np.zeros(4),
        np.full(4, size), np.full(4, size), dz,
        color=colors,
        edgecolor="black",
        linewidth=0.28,
        shade=True,
        zsort="average",
    )

    ax.set_xlim(-0.02, 2.02)
    ax.set_ylim(-0.02, 2.02)
    ax.set_zlim(-1.0, 1.0)
    ax.set_xticks([0.5, 1.5])
    ax.set_yticks([0.5, 1.5])
    ax.set_xticklabels([r"$|1\rangle$", r"$|3\rangle$"], fontsize=5.2)
    ax.set_yticklabels([r"$\langle1|$", r"$\langle3|$"], fontsize=5.2)
    ax.set_zticks([-1, 0, 1])
    ax.set_zticklabels([r"$-1$", r"$0$", r"$1$"], fontsize=5.0)
    ax.view_init(elev=24, azim=-55)
    # Keep the tomography's deliberate paper-like perspective.
    ax.set_box_aspect((1.0, 1.0, 0.68))
    ax.tick_params(axis="both", which="both", pad=-1.5, labelsize=5.2)
    ax.tick_params(axis="z", which="both", pad=-1.0, labelsize=5.0)
    ax.grid(False)
    ax.patch.set_alpha(0.0)
    # Paper-like slightly gray perspective box: the interior planes are
    # intentionally visible, rather than pure white, as in the reference figure.
    pane_gray = (0.93, 0.93, 0.93, 1.0)
    pane_edge = (0.72, 0.72, 0.72, 0.55)
    for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
        try:
            axis.pane.fill = True
            axis.pane.set_facecolor(pane_gray)
            axis.pane.set_edgecolor(pane_edge)
        except Exception:
            pass


class Arrow3D(FancyArrowPatch):
    def __init__(self, xs, ys, zs, *args, **kwargs):
        super().__init__((0, 0), (0, 0), *args, **kwargs)
        self._verts3d = xs, ys, zs

    def do_3d_projection(self):
        xs3d, ys3d, zs3d = self._verts3d
        xs, ys, zs = proj3d.proj_transform(xs3d, ys3d, zs3d, self.axes.M)
        self.set_positions((xs[0], ys[0]), (xs[1], ys[1]))
        return np.min(zs)


def draw_bloch(ax, vec):
    """Round, minimal Bloch sphere matching the paper style."""
    vec = np.asarray(vec, float)
    nrm = np.linalg.norm(vec)
    if nrm > 1.0 + 1e-9:
        vec = vec / nrm

    u = np.linspace(0, 2 * np.pi, 56)
    v = np.linspace(0, np.pi, 30)
    x = np.outer(np.cos(u), np.sin(v))
    y = np.outer(np.sin(u), np.sin(v))
    z = np.outer(np.ones_like(u), np.cos(v))

    ax.plot_surface(
        x, y, z,
        color=SPHERE,
        alpha=0.48,
        linewidth=0,
        shade=False,
        antialiased=True,
    )
    ax.plot_wireframe(
        x, y, z,
        rstride=5,
        cstride=5,
        color=(0.58, 0.58, 0.58),
        linewidth=0.24,
        alpha=0.42,
    )

    th = np.linspace(0, 2 * np.pi, 220)
    for xx, yy, zz, lw, alpha in [
        (np.cos(th), np.sin(th), 0 * th, 0.24, 0.46),
        (np.cos(th), 0 * th, np.sin(th), 0.22, 0.40),
        (0 * th, np.cos(th), np.sin(th), 0.22, 0.40),
    ]:
        ax.plot(xx, yy, zz, color=(0.60, 0.60, 0.60), lw=lw, alpha=alpha)

    arrow = Arrow3D(
        [0, float(vec[0])],
        [0, float(vec[1])],
        [0, float(vec[2])],
        mutation_scale=10,
        lw=1.1,
        arrowstyle="-|>",
        color=ARROW,
    )
    ax.add_artist(arrow)

    # Slightly tighter limits make the sphere visibly larger while preserving a 1:1:1 aspect.
    ax.set_xlim(-1.02, 1.02)
    ax.set_ylim(-1.02, 1.02)
    ax.set_zlim(-1.02, 1.02)
    ax.set_box_aspect((1, 1, 1))

    # Minimal Cartesian guides. The view is chosen so the positive x and y axes
    # project down-left and down-right, forming a shallow V for the reader; z
    # remains vertical, with |0> and |1> at its opposite ends.
    guide_color = (0.38, 0.38, 0.38)
    ax.plot([-1.0, 1.0], [0, 0], [0, 0], color=guide_color, lw=0.42, alpha=0.55)
    ax.plot([0, 0], [-1.0, 1.0], [0, 0], color=guide_color, lw=0.42, alpha=0.55)
    ax.plot([0, 0], [0, 0], [-1.0, 1.0], color=guide_color, lw=0.34, alpha=0.42)
    ax.view_init(elev=30, azim=45)
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_zticks([])
    ax.set_axis_off()
    ax.patch.set_alpha(0.0)

    # Labels: x/y orient the viewer; |0> and |1> identify the opposite z poles.
    label_color = (0.30, 0.30, 0.30)
    ax.text(1.02, 0.02, 0.02, r"$x$", fontsize=5.0, color=label_color)
    ax.text(0.02, 1.02, 0.02, r"$y$", fontsize=5.0, color=label_color)
    ax.text(0.00, 0.00, 1.06, r"$|0\rangle$", fontsize=5.0, color=label_color, ha="center", va="bottom")
    ax.text(0.00, 0.00, -1.06, r"$|1\rangle$", fontsize=5.0, color=label_color, ha="center", va="top")


def make_figure(data_path: Path, outdir: Path | None = None):
    configure_matplotlib()
    d, rho3 = load_and_validate(data_path)
    rho_outer, purity, coherence, bloch = observables(rho3)
    V0 = float(d["V0_meV"]) if "V0_meV" in d.files else 5.0

    panel_labels = ["(a)", "(b)", "(c)", "(d)", "(e)"]
    time_labels = [
        r"$t=0$",
        r"$T_{\mathrm{eff}}/4$",
        r"$t_X=T_{\mathrm{eff}}/2$",
        r"$3T_{\mathrm{eff}}/4$",
        r"$T=T_{\mathrm{eff}}$",
    ]

    # Geometry deliberately follows the paper: no boxes/dividers, large white
    # space around compact 3D panels, and one clean metric line below Bloch row.
    fig = plt.figure(figsize=(10.6, 5.15), dpi=300)
    gs = fig.add_gridspec(
        3, 5,
        left=0.150,
        right=0.935,
        bottom=0.245,
        top=0.890,
        wspace=-0.075,
        hspace=0.015,
        height_ratios=[1.0, 1.0, 1.48],
    )

    for j in range(5):
        ax = fig.add_subplot(gs[0, j], projection="3d")
        plot_density_bars(ax, rho_outer[:, :, j], "Re")

        ax = fig.add_subplot(gs[1, j], projection="3d")
        plot_density_bars(ax, rho_outer[:, :, j], "Im")

        ax = fig.add_subplot(gs[2, j], projection="3d")
        draw_bloch(ax, bloch[:, j])

    xcols = np.linspace(0.215, 0.860, 5)
    for x, panel, tim in zip(xcols, panel_labels, time_labels):
        fig.text(x - 0.030, 0.915, panel, ha="right", va="bottom", fontsize=8.6, color=BLACK)
        fig.text(x + 0.002, 0.915, tim, ha="left", va="bottom", fontsize=8.6, color=BLACK)

    fig.text(0.150, 0.735, r"$\mathrm{Re}(\rho)$", ha="center", va="center", fontsize=8.5, color=BLACK)
    fig.text(0.150, 0.505, r"$\mathrm{Im}(\rho)$", ha="center", va="center", fontsize=8.5, color=BLACK)
    fig.text(0.150, 0.315, "Bloch", ha="center", va="center", fontsize=8.5, color=BLACK)
    fig.text(0.150, 0.285, "sphere", ha="center", va="center", fontsize=8.5, color=BLACK)

    # Metrics: a single horizontal rule, exactly as in the clean paper layout.
    fig.lines.append(
        plt.Line2D(
            [0.150, 0.935], [0.255, 0.255],
            transform=fig.transFigure,
            color="black",
            lw=0.55,
        )
    )
    fig.text(0.150, 0.224, r"$\mathrm{Tr}(\rho_{\mathrm{layer}}^2)$", ha="left", va="center", fontsize=8.2)
    fig.text(0.150, 0.194, r"$|\rho_{13}|$", ha="left", va="center", fontsize=8.2)

    tx = np.linspace(0.215, 0.860, 5)
    for j in range(5):
        fig.text(tx[j], 0.224, f"{purity[j]:.3f}", ha="center", va="center", fontsize=7.8)
        fig.text(tx[j], 0.194, f"{coherence[j]:.3f}", ha="center", va="center", fontsize=7.8)

    outdir = data_path.parent if outdir is None else outdir
    outdir.mkdir(parents=True, exist_ok=True)
    stem = f"Fig6_perturbada_PRB_PAPER_STYLE_V0_{sanitize(V0)}meV"
    pdf = outdir / f"{stem}.pdf"
    png = outdir / f"{stem}.png"
    audit = outdir / f"{stem}_AUDIT.txt"

    fig.savefig(pdf, format="pdf", bbox_inches="tight", pad_inches=0.02)
    fig.savefig(png, format="png", dpi=450, bbox_inches="tight", pad_inches=0.02)
    plt.close(fig)

    audit.write_text(
        "PAPER-STYLE FIGURE AUDIT\n"
        f"source={data_path}\n"
        "dynamics=FULL 3x3\n"
        "tomography=outer logical block {|1>,|3>}\n"
        "purity=Tr(rho_layer^2) of full 3x3 reduced layer state\n"
        "panel_dividers=none\n"
        "font_family=Computer Modern Roman + LaTeX\n"
        "tomography_geometry=paper-style compact 3D bars\n"
        "bloch_geometry=round sphere + magenta vector\n",
        encoding="utf-8",
    )

    print("PAPER STYLE: PASS")
    print(f"PDF = {pdf}")
    print(f"PNG = {png}")
    return pdf, png


def locate_data(v0: float, explicit: str | None) -> Path:
    filename = f"full_3x3_tomography_V0_{sanitize(v0)}meV.npz"
    if explicit is not None:
        return Path(explicit).expanduser().resolve()

    roots = [Path.cwd(), Path(__file__).resolve().parent, Path.home() / ".cache"]
    matches: list[Path] = []
    for root in roots:
        try:
            matches.extend(root.rglob(filename))
        except OSError:
            pass
    for match in matches:
        if match.exists():
            return match.resolve()

    # Also check the common case: script in ~/Downloads and .npz in cwd.
    return (Path.cwd() / filename).resolve()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--V0", type=float, default=5.0)
    parser.add_argument("--data", type=str, default=None, help="Caminho para o .npz.")
    parser.add_argument("--outdir", type=str, default=None, help="Diretório para PDF/PNG.")
    args = parser.parse_args()

    data = locate_data(args.V0, args.data)
    if not data.exists():
        raise FileNotFoundError(
            "Arquivo .npz não encontrado.\n"
            f"Esperado: {data}\n"
            "Execute primeiro o solver full_3x3_tomography_data_FINAL.py ou informe --data."
        )

    outdir = Path(args.outdir).expanduser().resolve() if args.outdir else None
    make_figure(data, outdir=outdir)


if __name__ == "__main__":
    main()
