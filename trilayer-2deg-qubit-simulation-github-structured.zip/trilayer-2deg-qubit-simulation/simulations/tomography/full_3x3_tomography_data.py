#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FINAL 3x3 DATA GENERATOR — TRILAYER TOMOGRAPHY / BLOCH SPHERE

This is the canonical physical solver for the tomography figures.
It propagates the COMPLETE 3x3 trilayer Hamiltonian with the spatial
split-operator method. It can generate either the coherent case (V0=0 meV)
or the spatially perturbed case (V0=5 meV).

Important convention frozen for the paper:
  * Dynamics: always full 3x3.
  * Reduced layer state: rho_layer is the FULL 3x3 layer density matrix
    obtained after tracing out real space.
  * Logical qubit observables (coherence/Bloch): extracted from the outer
    {|1>, |3>} block of rho_layer.
  * PURITY: always Tr[rho_layer^2] using the FULL 3x3 state, not the
    unnormalized 2x2 outer block.
  * Spatial perturbation acts ONLY on H_11 through U1 + V(r).
  * No effective 2x2 dynamics is used in this script.

The saved .npz contains the full 3x3 density matrices at the five
representative times required by the tomography figure.
"""
from __future__ import annotations

import argparse
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np


@dataclass(frozen=True)
class PhysicalParameters:
    hbar_meV_fs: float = 658.211928
    e_charge_C: float = 1.602176634e-19
    m_e_kg: float = 9.1093837015e-31
    m_eff_factor: float = 0.067

    Delta12_meV: float = 5.0
    Delta23_meV: float = 5.0
    Delta13_meV: float = 0.0

    U1_meV: float = 0.0
    U2_meV: float = 100.0
    U3_meV: float = 0.0

    x0_nm: float = 40.0
    width_nm: float = 10.0
    sigma_nm: float = 15.0
    k0_nm_inv: float = 0.0


@dataclass(frozen=True)
class NumericalParameters:
    nx: int = 384
    ny: int = 384
    WX_nm: float = 1200.0
    WY_nm: float = 1200.0
    dt_fs: float = 0.5
    tmax_ps: float = 20.0
    save_step: int = 40


def effective_J_signed(phys: PhysicalParameters) -> float:
    return -(phys.Delta12_meV * phys.Delta23_meV) / phys.U2_meV


def effective_J_abs(phys: PhysicalParameters) -> float:
    return abs(effective_J_signed(phys))


def Teff_fs(phys: PhysicalParameters) -> float:
    return np.pi * phys.hbar_meV_fs / effective_J_abs(phys)


def tx_fs(phys: PhysicalParameters) -> float:
    return Teff_fs(phys) / 2.0


def sanitize(v: float) -> str:
    s = f"{v:.6f}".rstrip("0").rstrip(".")
    return s.replace("-", "m").replace(".", "p")


def kinetic_coefficient_meV_nm2(phys: PhysicalParameters) -> float:
    hbar_J_s = phys.hbar_meV_fs * 1e-3 * 1e-15 * phys.e_charge_C
    m_eff = phys.m_eff_factor * phys.m_e_kg
    coeff_eV_nm2 = hbar_J_s**2 * 1e18 / (2.0 * m_eff * phys.e_charge_C)
    return 1000.0 * coeff_eV_nm2


def gaussian_packet(X, Y, phys: PhysicalParameters, dx_nm: float, dy_nm: float):
    psi = np.exp(
        -(X**2 + Y**2) / (2.0 * phys.sigma_nm**2)
        + 1j * phys.k0_nm_inv * X
    ).astype(np.complex128)
    norm = np.sqrt(np.sum(np.abs(psi) ** 2) * dx_nm * dy_nm)
    return psi / norm


def potential(X, V0_meV: float, phys: PhysicalParameters):
    return V0_meV * np.exp(-((X - phys.x0_nm) ** 2) / (2.0 * phys.width_nm**2))


def local_hamiltonian(V_meV: np.ndarray, phys: PhysicalParameters) -> np.ndarray:
    H = np.zeros(V_meV.shape + (3, 3), dtype=np.complex128)
    H[..., 0, 0] = phys.U1_meV + V_meV
    H[..., 1, 1] = phys.U2_meV
    H[..., 2, 2] = phys.U3_meV
    H[..., 0, 1] = H[..., 1, 0] = phys.Delta12_meV
    H[..., 1, 2] = H[..., 2, 1] = phys.Delta23_meV
    H[..., 0, 2] = H[..., 2, 0] = phys.Delta13_meV
    return H


def build_local_propagator(V_meV: np.ndarray, phys: PhysicalParameters, dt_fs: float):
    H = local_hamiltonian(V_meV, phys)
    eigvals, eigvecs = np.linalg.eigh(H)
    phases = np.exp(-1j * eigvals * dt_fs / phys.hbar_meV_fs)
    U = np.einsum(
        "...ik,...k,...jk->...ij",
        eigvecs,
        phases,
        np.conjugate(eigvecs),
        optimize=True,
    )
    herm_err = float(np.max(np.abs(H - np.conjugate(np.swapaxes(H, -1, -2)))))
    ident = np.eye(3, dtype=np.complex128)
    UdagU = np.einsum("...ji,...jk->...ik", np.conjugate(U), U)
    unit_err = float(np.max(np.linalg.norm(UdagU - ident, axis=(-2, -1))))
    return U, herm_err, unit_err


def reduced_layer_density(Psi: np.ndarray, dx_nm: float, dy_nm: float) -> np.ndarray:
    # rho_layer[i,j] = integral psi_i(r) psi_j*(r) d^2r
    return np.einsum("ixy,jxy->ij", Psi, np.conjugate(Psi), optimize=True) * dx_nm * dy_nm


def observables(rho3: np.ndarray) -> dict[str, float]:
    rho3 = np.asarray(rho3, dtype=np.complex128)
    rho3 = 0.5 * (rho3 + rho3.conjugate().T)  # numerical symmetrization only

    P1 = float(np.real(rho3[0, 0]))
    P2 = float(np.real(rho3[1, 1]))
    P3 = float(np.real(rho3[2, 2]))
    rho13 = complex(rho3[0, 2])

    # Logical outer-layer observables.
    rx = 2.0 * float(np.real(rho13))
    ry = -2.0 * float(np.imag(rho13))
    rz = float(np.real(rho3[0, 0] - rho3[2, 2]))
    bloch_norm = float(np.sqrt(rx * rx + ry * ry + rz * rz))

    # CRITICAL: purity of the FULL reduced layer state.
    purity = float(np.real(np.trace(rho3 @ rho3)))
    norm = float(np.real(np.trace(rho3)))

    return {
        "P1": P1,
        "P2": P2,
        "P3": P3,
        "coherence": abs(rho13),
        "purity": purity,
        "rx": rx,
        "ry": ry,
        "rz": rz,
        "bloch_norm": bloch_norm,
        "norm": norm,
        "rho13_re": float(np.real(rho13)),
        "rho13_im": float(np.imag(rho13)),
    }


def run(V0_meV: float, quick: bool = False) -> Path:
    if V0_meV < 0:
        raise ValueError("V0 deve ser >= 0 meV.")

    phys = PhysicalParameters()
    if quick:
        num = NumericalParameters(
            nx=96, ny=96, WX_nm=300.0, WY_nm=300.0,
            dt_fs=0.5, tmax_ps=9.0, save_step=10,
        )
    else:
        num = NumericalParameters()

    outdir = Path(__file__).resolve().parent / "tomography_3x3_results"
    outdir.mkdir(exist_ok=True)

    stem = f"full_3x3_tomography_V0_{sanitize(V0_meV)}meV"
    data_path = outdir / f"{stem}.npz"
    report_path = outdir / f"{stem}_report.txt"

    dx = num.WX_nm / num.nx
    dy = num.WY_nm / num.ny
    x = -num.WX_nm / 2.0 + np.arange(num.nx) * dx
    y = -num.WY_nm / 2.0 + np.arange(num.ny) * dy
    X, Y = np.meshgrid(x, y, indexing="ij")

    kx = 2.0 * np.pi * np.fft.fftfreq(num.nx, d=dx)
    ky = 2.0 * np.pi * np.fft.fftfreq(num.ny, d=dy)
    KX, KY = np.meshgrid(kx, ky, indexing="ij")
    K2 = KX**2 + KY**2
    kin_coeff = kinetic_coefficient_meV_nm2(phys)
    T_half = np.exp(
        -1j * kin_coeff * K2 * num.dt_fs / (2.0 * phys.hbar_meV_fs)
    )

    V = potential(X, V0_meV, phys)
    U_local, herm_err, unit_err = build_local_propagator(V, phys, num.dt_fs)

    Psi = np.zeros((3, num.nx, num.ny), dtype=np.complex128)
    Psi[0] = gaussian_packet(X, Y, phys, dx, dy)

    nsteps = int(round(num.tmax_ps * 1000.0 / num.dt_fs))
    Teff = Teff_fs(phys)
    tx = tx_fs(phys)
    sample_targets = np.array([0.0, Teff / 4.0, tx, 3.0 * Teff / 4.0, Teff])
    sample_steps = np.array([int(round(t / num.dt_fs)) for t in sample_targets], dtype=int)
    if np.max(sample_steps) > nsteps:
        raise ValueError(
            f"A janela de simulação ({num.tmax_ps:.3f} ps) não cobre T_eff="
            f"{Teff/1000.0:.3f} ps."
        )
    sample_map = set(sample_steps.tolist())

    times = []
    history = {key: [] for key in (
        "P1", "P2", "P3", "coherence", "purity",
        "rx", "ry", "rz", "bloch_norm", "norm",
        "rho13_re", "rho13_im",
    )}
    sampled_steps: list[int] = []
    sampled_rho3: list[np.ndarray] = []

    def save_state(step: int):
        rho3 = reduced_layer_density(Psi, dx, dy)
        obs = observables(rho3)
        times.append(step * num.dt_fs)
        for key in history:
            history[key].append(obs[key])
        if step in sample_map:
            sampled_steps.append(step)
            sampled_rho3.append(rho3.copy())

    save_state(0)
    t0 = time.perf_counter()

    for step in range(1, nsteps + 1):
        fk = np.fft.fft2(Psi, axes=(1, 2))
        fk *= T_half[None, :, :]
        Psi = np.fft.ifft2(fk, axes=(1, 2))

        Psi_last = np.moveaxis(Psi, 0, -1)
        Psi_last = np.einsum(
            "...ij,...j->...i", U_local, Psi_last, optimize=True
        )
        Psi = np.moveaxis(Psi_last, -1, 0)

        fk = np.fft.fft2(Psi, axes=(1, 2))
        fk *= T_half[None, :, :]
        Psi = np.fft.ifft2(fk, axes=(1, 2))

        if step % num.save_step == 0 or step == nsteps or step in sample_map:
            save_state(step)

        if step % max(1, nsteps // 10) == 0:
            elapsed = time.perf_counter() - t0
            frac = step / nsteps
            eta = elapsed * (1.0 - frac) / frac
            print(
                f"[{100*frac:6.2f}%] t={step*num.dt_fs/1000.0:7.3f} ps "
                f"| elapsed={elapsed:7.1f} s | ETA={eta:7.1f} s"
            )

    elapsed = time.perf_counter() - t0
    times = np.asarray(times, dtype=float)
    for key in history:
        history[key] = np.asarray(history[key], dtype=float)

    # Deduplicate time samples while preserving the first occurrence.
    times_unique, unique_idx = np.unique(times, return_index=True)
    times = times_unique
    for key in history:
        history[key] = history[key][unique_idx]

    # Ensure all requested tomography states are present in the intended order.
    sampled_by_step = {s: r for s, r in zip(sampled_steps, sampled_rho3)}
    if set(sample_steps.tolist()) != set(sampled_by_step):
        raise RuntimeError("Nem todos os cinco estados de tomografia foram capturados.")
    rho_layer_samples = np.stack([sampled_by_step[s] for s in sample_steps], axis=-1)

    rho_outer_samples = rho_layer_samples[np.ix_([0, 2], [0, 2], np.arange(5))]
    sample_coherence = np.abs(rho_layer_samples[0, 2, :])
    sample_bloch = np.vstack([
        2.0 * np.real(rho_layer_samples[0, 2, :]),
        -2.0 * np.imag(rho_layer_samples[0, 2, :]),
        np.real(rho_layer_samples[0, 0, :] - rho_layer_samples[2, 2, :]),
    ])
    sample_purity_full3x3 = np.real(np.trace(
        np.einsum("ijk,jlk->ilk", rho_layer_samples, rho_layer_samples)
    ))

    max_norm_dev = float(np.max(np.abs(history["norm"] - 1.0)))
    hermiticity_samples = np.max(
        np.abs(rho_layer_samples - np.conjugate(np.swapaxes(rho_layer_samples, 0, 1)))
    )

    np.savez_compressed(
        data_path,
        # Time series
        times_fs=times,
        P1=history["P1"], P2=history["P2"], P3=history["P3"],
        coherence=history["coherence"], purity=history["purity"],
        rx=history["rx"], ry=history["ry"], rz=history["rz"],
        bloch_norm=history["bloch_norm"], norm=history["norm"],
        rho13_re=history["rho13_re"], rho13_im=history["rho13_im"],
        # TOMOGRAPHY: full 3x3 layer states are stored explicitly.
        rho_layer_samples=rho_layer_samples,
        rho_outer_samples=rho_outer_samples,
        sample_times_fs_requested=sample_targets,
        sample_times_fs=sample_steps * num.dt_fs,
        bloch_samples=sample_bloch,
        purity_samples_full3x3=sample_purity_full3x3,
        coherence_samples=sample_coherence,
        # Frozen physical/numerical parameters
        V0_meV=np.array(V0_meV),
        x0_nm=np.array(phys.x0_nm), width_nm=np.array(phys.width_nm),
        sigma_nm=np.array(phys.sigma_nm), k0_nm_inv=np.array(phys.k0_nm_inv),
        dt_fs=np.array(num.dt_fs), nx=np.array(num.nx), ny=np.array(num.ny),
        WX_nm=np.array(num.WX_nm), WY_nm=np.array(num.WY_nm),
        hbar_meV_fs=np.array(phys.hbar_meV_fs),
        Delta12_meV=np.array(phys.Delta12_meV), Delta23_meV=np.array(phys.Delta23_meV),
        Delta13_meV=np.array(phys.Delta13_meV),
        U1_meV=np.array(phys.U1_meV), U2_meV=np.array(phys.U2_meV), U3_meV=np.array(phys.U3_meV),
        J_signed_meV=np.array(effective_J_signed(phys)),
        J_abs_meV=np.array(effective_J_abs(phys)),
        Teff_fs=np.array(Teff), tx_fs=np.array(tx),
        hermiticity_error=np.array(herm_err), local_unitarity_error=np.array(unit_err),
        rho_layer_hermiticity_sample_error=np.array(float(hermiticity_samples)),
        norm_deviation_max=np.array(max_norm_dev), runtime_s=np.array(elapsed),
    )

    # Audit report
    with open(report_path, "w", encoding="utf-8") as f:
        f.write("FINAL 3x3 TOMOGRAPHY DATA GENERATOR\n")
        f.write("=" * 88 + "\n")
        f.write("ALL DYNAMICS: FULL 3x3 SPLIT-OPERATOR\n")
        f.write("Purity definition: Tr[rho_layer^2] using the FULL 3x3 reduced layer state.\n")
        f.write("Logical Bloch/coherence: outer-layer block {|1>,|3>}.\n\n")
        f.write(f"V0 = {V0_meV:.9f} meV\n")
        f.write(f"Delta12 = {phys.Delta12_meV:.9f} meV\n")
        f.write(f"Delta23 = {phys.Delta23_meV:.9f} meV\n")
        f.write(f"U2 = {phys.U2_meV:.9f} meV\n")
        f.write(f"J_signed = {effective_J_signed(phys):.12f} meV\n")
        f.write(f"|J| = {effective_J_abs(phys):.12f} meV\n")
        f.write(f"Teff = {Teff:.12f} fs\n")
        f.write(f"tX = {tx:.12f} fs\n")
        f.write(f"grid = {num.nx} x {num.ny}\n")
        f.write(f"box = {num.WX_nm} x {num.WY_nm} nm^2\n")
        f.write(f"dt = {num.dt_fs} fs\n")
        f.write(f"tmax = {num.tmax_ps} ps\n")
        f.write(f"Hermiticity error = {herm_err:.6e}\n")
        f.write(f"Local unitarity error = {unit_err:.6e}\n")
        f.write(f"Norm deviation max = {max_norm_dev:.6e}\n")
        f.write(f"rho_layer sample Hermiticity error = {hermiticity_samples:.6e}\n")
        f.write(f"P2_max = {np.max(history['P2']):.12e}\n")
        f.write(f"purity_full3x3_min = {np.min(history['purity']):.12e}\n")
        f.write(f"bloch_norm_min = {np.min(history['bloch_norm']):.12e}\n")
        f.write(f"P3(tX grid) = {history['P3'][np.argmin(np.abs(times - round(tx/num.dt_fs)*num.dt_fs))]:.12f}\n")
        f.write(f"runtime_s = {elapsed:.6f}\n")
        f.write("\nTOMOGRAPHY SAMPLE TIMES (fs):\n")
        for target, step in zip(sample_targets, sample_steps):
            f.write(f"target={target:.6f} | grid={step*num.dt_fs:.6f}\n")
        f.write("\nSAMPLE PURITY FULL 3x3:\n")
        for t, p in zip(sample_steps * num.dt_fs, sample_purity_full3x3):
            f.write(f"t={t:.6f} fs : {p:.12f}\n")

    print("\n" + "=" * 88)
    print("FINAL 3x3 TOMOGRAPHY DATA — PASS")
    print("=" * 88)
    print(f"V0                 = {V0_meV:.6f} meV")
    print(f"J                  = {effective_J_abs(phys):.6f} meV")
    print(f"Teff               = {Teff:.6f} fs")
    print(f"tX                 = {tx:.6f} fs")
    print(f"grid               = {num.nx} x {num.ny}")
    print(f"P2_max             = {np.max(history['P2']):.10f}")
    print(f"purity_full3x3_min = {np.min(history['purity']):.10f}")
    print(f"norm_dev_max       = {max_norm_dev:.3e}")
    print(f"data               = {data_path}")
    print(f"report             = {report_path}")
    print("=" * 88)

    return data_path


def main() -> None:
    parser = argparse.ArgumentParser(description="Canonical full-3x3 data for tomography/Bloch figures.")
    parser.add_argument("--V0", type=float, default=5.0,
                        help="Spatial perturbation amplitude in meV. Use 0 for coherent, 5 for perturbed.")
    parser.add_argument("--quick", action="store_true",
                        help="96x96, 9 ps validation run; still uses full 3x3 physics.")
    args = parser.parse_args()
    run(args.V0, quick=args.quick)


if __name__ == "__main__":
    main()
