#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Coherent homogeneous layer-qubit dynamics and shared dataset generator.

PURPOSE
-------
This script computes the homogeneous coherent dynamics at the reference point
and prepares the shared data used by the downstream Bloch-vector and tomography
plotting scripts.

PHYSICAL MODEL
--------------
For V(r)=0, the spatial wave packet factorizes and the internal layer dynamics
is exactly described by the 3x3 Hamiltonian. The script also evaluates the
effective 2x2 description as a controlled comparison.

QUANTITIES GENERATED
--------------------
The calculation produces populations, reduced outer-layer density matrices,
Bloch-vector components, coherence, purity, and the five standard sampling times

    0, T_eff/4, t_X, 3T_eff/4, T_eff.

FIGURES
-------
The script directly generates the coherent population-dynamics figure.
Downstream scripts use its saved dataset to generate:
  - Bloch-vector dynamics;
  - coherent state tomography and Bloch-sphere panels.

OUTPUTS
-------
A compressed NumPy dataset is saved together with the directly generated figure.

ROLE IN THE REPRODUCTION CHAIN
------------------------------
This is both a physical calculation and a data-preparation script. It is the
upstream source for the homogeneous plotting scripts.

NOTE
----
The exact 3x3 evolution is retained for validation even where the published
coherent reference curve is expressed through the effective logical model.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

# -----------------------------------------------------------------------------
# PUBLICATION STYLE — copied from the original publication graphics
# -----------------------------------------------------------------------------
class FigureStyle:
    pop_1 = "blue"
    pop_3 = "red"
    theory = "#2f2f2f"
    coherence = "forestgreen"
    purity = "black"
    purity_theory = "gray"
    bloch_x = "blue"
    bloch_y = "red"
    bloch_z = "#4d4d4d"

    lw_main = 1.7
    lw_theory = 1.25
    panel_fontsize = 18
    label_fontsize = 19
    tick_fontsize = 15
    legend_fontsize = 14.0
    title_fontsize = 18.0
    tomo_tick_fontsize = 7.0
    tomo_row_fontsize = 18.0


style = FigureStyle()


def configure_matplotlib() -> None:
    plt.rcParams.update({
        "text.usetex": True,
        "font.family": "serif",
        "font.serif": ["Computer Modern Roman"],
        "text.latex.preamble": r"\usepackage{amsmath}",
        "text.color": "black",
        "axes.labelcolor": "black",
        "xtick.color": "black",
        "ytick.color": "black",
        "axes.edgecolor": "black",
        "font.size": 18,
        "axes.labelsize": 19,
        "axes.titlesize": 18,
        "legend.fontsize": 14,
        "xtick.labelsize": 15,
        "ytick.labelsize": 15,
        "axes.linewidth": 0.75,
        "xtick.major.size": 5,
        "ytick.major.size": 5,
        "xtick.major.width": 0.75,
        "ytick.major.width": 0.75,
        "xtick.minor.visible": True,
        "ytick.minor.visible": True,
        "xtick.minor.size": 2.5,
        "ytick.minor.size": 2.5,
        "xtick.minor.width": 0.55,
        "ytick.minor.width": 0.55,
        "legend.frameon": False,
        "savefig.bbox": "tight",
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })


def polish_axes(ax, grid=True):
    ax.tick_params(which="major", direction="in", top=True, right=True,
                   length=5, width=0.75)
    ax.tick_params(which="minor", direction="in", top=True, right=True,
                   length=2.5, width=0.55)
    if grid:
        ax.grid(True, which="major", alpha=0.18, linewidth=0.5)
    else:
        ax.grid(False)


def prepare_axes_for_export(ax):
    for spine in ax.spines.values():
        spine.set_linewidth(0.75)


@dataclass(frozen=True)
class Parameters:
    hbar_meV_fs: float = 658.211928  # meV fs
    Delta12_meV: float = 5.0
    Delta23_meV: float = 5.0
    U1_meV: float = 0.0
    U2_meV: float = 100.0
    U3_meV: float = 0.0
    dt_fs: float = 0.5
    tmax_ps: float = 20.0

    @property
    def J_signed_meV(self) -> float:
        return -self.Delta12_meV * self.Delta23_meV / self.U2_meV

    @property
    def J_abs_meV(self) -> float:
        return abs(self.J_signed_meV)

    @property
    def Omega_eff_fs_inv(self) -> float:
        return 2.0 * self.J_abs_meV / self.hbar_meV_fs

    @property
    def Teff_fs(self) -> float:
        return np.pi * self.hbar_meV_fs / self.J_abs_meV

    @property
    def tx_fs(self) -> float:
        return self.Teff_fs / 2.0

    @property
    def H3(self) -> np.ndarray:
        return np.array([
            [self.U1_meV, self.Delta12_meV, 0.0],
            [self.Delta12_meV, self.U2_meV, self.Delta23_meV],
            [0.0, self.Delta23_meV, self.U3_meV],
        ], dtype=np.complex128)

    @property
    def H2(self) -> np.ndarray:
        # Effective logical basis {|1>, |3>}.
        return np.array([
            [0.0, self.J_signed_meV],
            [self.J_signed_meV, 0.0],
        ], dtype=np.complex128)


def eig_propagator(H: np.ndarray, times_fs: np.ndarray, hbar_meV_fs: float) -> np.ndarray:
    """Return U(t) for all times using the exact Hermitian eigendecomposition."""
    evals, evecs = np.linalg.eigh(H)
    phases = np.exp(-1j * np.outer(evals, times_fs) / hbar_meV_fs)
    # U_t[a,b,t] = sum_k V[a,k] exp(...) V*[b,k]
    return np.einsum("ak,kt,bk->abt", evecs, phases, np.conjugate(evecs))


def reduced_outer_density(psi3: np.ndarray) -> np.ndarray:
    """Pure internal 3-level state -> unnormalized 2x2 logical outer-layer block."""
    psi_outer = psi3[[0, 2], :]
    return np.einsum("it,jt->ijt", psi_outer, np.conjugate(psi_outer))


def bloch_from_rho2(rho2: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    r_x = 2.0 * np.real(rho2[0, 1])
    r_y = -2.0 * np.imag(rho2[0, 1])
    r_z = np.real(rho2[0, 0] - rho2[1, 1])
    purity = np.real(rho2[0, 0] ** 2 + rho2[1, 1] ** 2 + 2.0 * np.abs(rho2[0, 1]) ** 2)
    return r_x, r_y, r_z, purity


def main() -> None:
    configure_matplotlib()
    p = Parameters()
    outdir = Path(__file__).resolve().parent
    data_path = outdir / "coherent_layer_qubit_dynamics_data.npz"
    fig_path = outdir / "coherent_layer_qubit_dynamics.pdf"

    times_fs = np.arange(0.0, p.tmax_ps * 1000.0 + 0.5 * p.dt_fs, p.dt_fs)
    psi0_3 = np.array([1.0, 0.0, 0.0], dtype=np.complex128)
    psi0_2 = np.array([1.0, 0.0], dtype=np.complex128)

    U3 = eig_propagator(p.H3, times_fs, p.hbar_meV_fs)
    U2 = eig_propagator(p.H2, times_fs, p.hbar_meV_fs)
    psi3 = np.einsum("abt,b->at", U3, psi0_3)
    psi2 = np.einsum("abt,b->at", U2, psi0_2)

    P3 = np.abs(psi3) ** 2
    P2_eff = np.abs(psi2) ** 2

    rho_outer_3 = reduced_outer_density(psi3)
    rho_outer_2 = np.einsum("it,jt->ijt", psi2, np.conjugate(psi2))

    bx3, by3, bz3, purity3 = bloch_from_rho2(rho_outer_3)
    bx2, by2, bz2, purity2 = bloch_from_rho2(rho_outer_2)
    coherence3 = np.abs(rho_outer_3[0, 1])
    coherence2 = np.abs(rho_outer_2[0, 1])

    # Validation relevant to the canonical model.
    herm_err = np.max(np.abs(p.H3 - p.H3.conj().T))
    unitarity_err = np.max(np.abs(np.einsum("abt,act->bct", np.conjugate(U3), U3) - np.eye(3)[:, :, None]))
    norm_err = np.max(np.abs(np.sum(np.abs(psi3) ** 2, axis=0) - 1.0))
    # SW sign convention.
    J_consistency = abs(p.J_signed_meV + p.Delta12_meV * p.Delta23_meV / p.U2_meV)

    # Save every quantity needed downstream.
    sample_times_fs = np.array([0.0, p.Teff_fs / 4.0, p.tx_fs, 3.0 * p.Teff_fs / 4.0, p.Teff_fs])
    sample_indices = np.array([np.argmin(np.abs(times_fs - t)) for t in sample_times_fs], dtype=int)

    np.savez_compressed(
        data_path,
        times_fs=times_fs,
        psi3=psi3,
        psi2=psi2,
        P3=P3,
        P2_eff=P2_eff,
        rho_outer_3=rho_outer_3,
        rho_outer_2=rho_outer_2,
        bloch_3=np.vstack([bx3, by3, bz3]),
        bloch_2=np.vstack([bx2, by2, bz2]),
        purity_3=purity3,
        purity_2=purity2,
        coherence_3=coherence3,
        coherence_2=coherence2,
        sample_times_fs=sample_times_fs,
        sample_indices=sample_indices,
        hbar_meV_fs=p.hbar_meV_fs,
        J_signed_meV=p.J_signed_meV,
        J_abs_meV=p.J_abs_meV,
        Omega_eff_fs_inv=p.Omega_eff_fs_inv,
        Teff_fs=p.Teff_fs,
        tx_fs=p.tx_fs,
        U2_meV=p.U2_meV,
        Delta12_meV=p.Delta12_meV,
        Delta23_meV=p.Delta23_meV,
    )

    # Plot corresponding to the coherent population dynamics.
    t_ps = times_fs / 1000.0
    fig, ax = plt.subplots(figsize=(10, 5), dpi=300)
    fig.patch.set_alpha(0)
    ax.set_box_aspect(0.55)
    ax.plot(t_ps, P3[0], color=style.pop_1, lw=style.lw_main, linestyle="solid", label=r"$\rho_{11}$")
    ax.plot(t_ps, P3[2], color=style.pop_3, lw=style.lw_main, linestyle="dashed", label=r"$\rho_{33}$")
    ax.set_xlabel(r"Time (ps)", labelpad=12)
    ax.set_ylabel(r"Population")
    ax.set_xlim(t_ps[0], t_ps[-1])
    ax.set_ylim(-0.05, 1.0)
    polish_axes(ax, grid=True)
    ax.legend(loc="upper right", frameon=False, fontsize=style.legend_fontsize)
    prepare_axes_for_export(ax)
    fig.subplots_adjust(left=0.095, right=0.995, bottom=0.24, top=0.965)
    fig.savefig(fig_path, format="pdf", bbox_inches="tight", pad_inches=0.02)
    fig.savefig(fig_path.with_suffix('.png'), format="png", dpi=450, bbox_inches="tight", pad_inches=0.02)
    plt.close(fig)

    print("=" * 88)
    print("COHERENT LAYER-QUBIT DYNAMICS — CANONICAL RECONSTRUCTION")
    print("=" * 88)
    print("V(r) = 0: homogeneous coherent regime; internal 3x3 dynamics exact.")
    print(f"Delta12              : {p.Delta12_meV:.6f} meV")
    print(f"Delta23              : {p.Delta23_meV:.6f} meV")
    print(f"U2                   : {p.U2_meV:.6f} meV")
    print(f"J_signed             : {p.J_signed_meV:.12f} meV")
    print(f"|J|                  : {p.J_abs_meV:.12f} meV")
    print(f"Teff                 : {p.Teff_fs:.6f} fs")
    print(f"t_X                  : {p.tx_fs:.6f} fs")
    print(f"Hermiticity error    : {herm_err:.3e}")
    print(f"Unitarity error      : {unitarity_err:.3e}")
    print(f"Norm deviation       : {norm_err:.3e}")
    print(f"J consistency error  : {J_consistency:.3e}")
    print(f"P2_max (exact 3x3)   : {np.max(P3[1]):.9e}")
    idx_x = np.argmin(np.abs(times_fs - p.tx_fs))
    print(f"P3(t_X)             : {P3[2, idx_x]:.12f}")
    print(f"Data saved           : {data_path}")
    print(f"Figure saved         : {fig_path}")
    print("COHERENT DYNAMICS: PASS")
    print("=" * 88)


if __name__ == "__main__":
    main()
