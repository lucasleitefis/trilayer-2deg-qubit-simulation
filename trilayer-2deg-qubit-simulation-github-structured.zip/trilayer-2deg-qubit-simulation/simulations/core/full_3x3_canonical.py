#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Canonical full 3x3 trilayer solver used as the numerical reference for the manuscript.

PURPOSE
-------
This script implements the physical model in the layer basis {|1>, |2>, |3>} and
performs the split-operator Fourier propagation of the complete 3x3 Hamiltonian.
It is the reference numerical engine; it is not a plotting script.

PHYSICAL MODEL
--------------
    H(r) = T I_3 + H_layer(r)

    H_layer(r) =
        [[U1 + V(r), Delta12, 0],
         [Delta12,    U2,      Delta23],
         [0,          Delta23, U3]]

The spatial perturbation V(r) acts only on H_11. The effective coupling used for
reference scales is

    J = -Delta12 Delta23 / U2.

The reduced layer density matrix and all layer observables are obtained only after
the full 3x3 spatial evolution.

FIGURES
-------
No publication figure is generated directly by this script.

OUTPUTS
-------
The script writes numerical data and a reproducibility report to the output
directory, including the propagation history, physical parameters, numerical
parameters, and internal consistency checks (Hermiticity, local unitarity,
and norm conservation).

ROLE IN THE REPRODUCTION CHAIN
------------------------------
This is the upstream solver for later analysis and plotting scripts. Its output
should be treated as the canonical numerical dataset for the full 3x3 model.

NOTE
----
The numerical implementation is intentionally kept separate from figure styling
so that the physics can be reproduced independently of the final graphic layout.
"""

from __future__ import annotations

import argparse
import os
import time
from dataclasses import dataclass
from typing import Dict

import numpy as np


# =============================================================================
# PARÂMETROS FÍSICOS — CONJUNTO CONGELADO
# =============================================================================

@dataclass(frozen=True)
class PhysicalParameters:
    hbar_ev_s: float = 6.58211928e-16
    e_charge_C: float = 1.602176634e-19
    m_e_kg: float = 9.1093837015e-31

    m_eff_factor: float = 0.067

    Delta12_meV: float = 5.0
    Delta23_meV: float = 5.0
    Delta13_meV: float = 0.0

    U1_meV: float = 0.0
    U2_meV: float = 100.0
    U3_meV: float = 0.0

    V0_meV: float = 5.0
    x0_nm: float = 40.0
    width_nm: float = 10.0

    sigma_nm: float = 15.0
    k0_nm_inv: float = 0.0


@dataclass(frozen=True)
class NumericalParameters:
    nx: int = 384
    ny: int = 384
    WX_nm: float = 1200.0
    WY_nm: float = 1200.0
    dt_fs: float = 0.5
    tmax_ps: float = 20.0
    save_step: int = 40


# =============================================================================
# CONSTANTES / UTILIDADES
# =============================================================================

def hbar_mev_fs(phys: PhysicalParameters) -> float:
    return phys.hbar_ev_s * 1.0e3 * 1.0e15


def kinetic_coefficient_ev_nm2(phys: PhysicalParameters) -> float:
    """hbar^2/(2m*) em eV nm^2, com conversão SI explícita."""
    m_eff = phys.m_eff_factor * phys.m_e_kg
    hbar_J_s = phys.hbar_ev_s * phys.e_charge_C
    return hbar_J_s**2 * 1.0e18 / (2.0 * m_eff * phys.e_charge_C)


def gaussian_packet(X, Y, sigma_nm, k0_nm_inv, dx_nm, dy_nm):
    psi = np.exp(
        -(X**2 + Y**2) / (2.0 * sigma_nm**2)
        + 1j * k0_nm_inv * X
    ).astype(np.complex128)
    norm = np.sqrt(np.sum(np.abs(psi)**2) * dx_nm * dy_nm)
    return psi / norm


def potential_gaussian(X, phys):
    return phys.V0_meV * np.exp(
        -((X - phys.x0_nm) ** 2) / (2.0 * phys.width_nm**2)
    )


# =============================================================================
# HAMILTONIANO LOCAL 3x3 — DEFINIÇÃO ÚNICA DO MODELO
# =============================================================================

def local_hamiltonian(V_meV: np.ndarray, phys: PhysicalParameters) -> np.ndarray:
    """
    Retorna H_layer(r) para todos os pontos da grade.

    DEFINIÇÃO FÍSICA:
        H11 = U1 + V(r)
        H22 = U2
        H33 = U3

    A perturbação NÃO é distribuída entre as camadas externas.
    """
    shape = V_meV.shape
    H = np.zeros(shape + (3, 3), dtype=np.complex128)

    H[..., 0, 0] = phys.U1_meV + V_meV
    H[..., 1, 1] = phys.U2_meV
    H[..., 2, 2] = phys.U3_meV

    H[..., 0, 1] = phys.Delta12_meV
    H[..., 1, 0] = phys.Delta12_meV

    H[..., 1, 2] = phys.Delta23_meV
    H[..., 2, 1] = phys.Delta23_meV

    H[..., 0, 2] = phys.Delta13_meV
    H[..., 2, 0] = phys.Delta13_meV

    return H


def build_local_propagator(V_meV: np.ndarray, phys: PhysicalParameters, dt_fs: float):
    """Constrói U_loc(r)=exp[-i H_layer(r) dt/hbar]."""
    H = local_hamiltonian(V_meV, phys)
    eigvals, eigvecs = np.linalg.eigh(H)
    phases = np.exp(-1j * eigvals * dt_fs / hbar_mev_fs(phys))
    U = np.einsum(
        "...ik,...k,...jk->...ij",
        eigvecs,
        phases,
        np.conjugate(eigvecs),
        optimize=True,
    )
    return U


def validate_local_operator(U_local: np.ndarray) -> float:
    """Maior erro ||U^dagger U-I||_F entre os pontos da grade."""
    ident = np.eye(3, dtype=np.complex128)
    UU = np.einsum("...ji,...jk->...ik", np.conjugate(U_local), U_local)
    err = np.max(np.linalg.norm(UU - ident, axis=(-2, -1)))
    return float(err)


def validate_hermiticity(H_local: np.ndarray) -> float:
    err = np.max(np.abs(H_local - np.conjugate(np.swapaxes(H_local, -1, -2))))
    return float(err)


# =============================================================================
# ESTADO REDUZIDO / OBSERVÁVEIS
# =============================================================================

def reduced_layer_density_matrix(Psi, dx_nm, dy_nm):
    """rho_ij = integral psi_i(r) psi_j*(r) d^2r."""
    return np.einsum(
        "ixy,jxy->ij", Psi, np.conjugate(Psi), optimize=True
    ) * dx_nm * dy_nm


def logical_observables(rho3) -> Dict[str, float]:
    rho11 = float(np.real(rho3[0, 0]))
    rho22 = float(np.real(rho3[1, 1]))
    rho33 = float(np.real(rho3[2, 2]))
    rho13 = complex(rho3[0, 2])

    rx = 2.0 * np.real(rho13)
    ry = -2.0 * np.imag(rho13)
    rz = rho11 - rho33

    rho_q = np.array(
        [[rho11, rho13], [np.conjugate(rho13), rho33]],
        dtype=np.complex128,
    )
    purity = float(np.real(np.trace(rho_q @ rho_q)))

    return {
        "P1": rho11,
        "P2": rho22,
        "P3": rho33,
        "coherence": abs(rho13),
        "purity": purity,
        "rx": float(rx),
        "ry": float(ry),
        "rz": float(rz),
        "bloch_norm": float(np.sqrt(rx**2 + ry**2 + rz**2)),
        "rho13_re": float(np.real(rho13)),
        "rho13_im": float(np.imag(rho13)),
        "norm": float(np.real(np.trace(rho3))),
    }


# =============================================================================
# SIMULAÇÃO
# =============================================================================

def run_simulation(phys: PhysicalParameters, num: NumericalParameters, outdir: str):
    os.makedirs(outdir, exist_ok=True)

    dx = num.WX_nm / num.nx
    dy = num.WY_nm / num.ny

    # Grade periódica FFT: endpoint=False é obrigatório.
    x = -num.WX_nm / 2.0 + np.arange(num.nx) * dx
    y = -num.WY_nm / 2.0 + np.arange(num.ny) * dy
    X, Y = np.meshgrid(x, y, indexing="ij")

    kx = 2.0 * np.pi * np.fft.fftfreq(num.nx, d=dx)
    ky = 2.0 * np.pi * np.fft.fftfreq(num.ny, d=dy)
    KX, KY = np.meshgrid(kx, ky, indexing="ij")
    K2 = KX**2 + KY**2

    kin_coeff = kinetic_coefficient_ev_nm2(phys)
    T_half = np.exp(
        -1j * kin_coeff * K2 * num.dt_fs
        / (2.0 * phys.hbar_ev_s * 1.0e15)
    )

    V = potential_gaussian(X, phys)
    H_local = local_hamiltonian(V, phys)
    herm_err = validate_hermiticity(H_local)

    print("=" * 88)
    print("DINÂMICA COMPLETA 3x3 — MODELO CANÔNICO")
    print("=" * 88)
    print("Hamiltoniano espacial:")
    print("  H11 = U1 + V(r)")
    print("  H22 = U2")
    print("  H33 = U3")
    print("  H12 = Delta12, H23 = Delta23, H13 = Delta13")
    print("-")
    print(f"Delta12              : {phys.Delta12_meV:.6f} meV")
    print(f"Delta23              : {phys.Delta23_meV:.6f} meV")
    print(f"U1                   : {phys.U1_meV:.6f} meV")
    print(f"U2                   : {phys.U2_meV:.6f} meV")
    print(f"U3                   : {phys.U3_meV:.6f} meV")
    J_signed = -phys.Delta12_meV * phys.Delta23_meV / phys.U2_meV
    print(f"J (signed)           : {J_signed:.6f} meV")
    print(f"|J|                  : {abs(J_signed):.6f} meV")
    print(f"V0                   : {phys.V0_meV:.6f} meV")
    print(f"x0                   : {phys.x0_nm:.6f} nm")
    print(f"w                    : {phys.width_nm:.6f} nm")
    print(f"sigma                : {phys.sigma_nm:.6f} nm")
    print(f"k0                   : {phys.k0_nm_inv:.6f} nm^-1")
    print(f"m*/me                : {phys.m_eff_factor:.6f}")
    print(f"hbar^2/(2m*)         : {kin_coeff:.9f} eV nm^2")
    print(f"Grid                 : {num.nx} x {num.ny}")
    print(f"Box                  : {num.WX_nm:.1f} x {num.WY_nm:.1f} nm^2")
    print(f"dx = dy              : {dx:.6f} nm")
    print(f"dt                   : {num.dt_fs:.6f} fs")
    print(f"Total time           : {num.tmax_ps:.6f} ps")
    print(f"save_step            : {num.save_step}")
    print(f"Hermiticity error    : {herm_err:.3e}")
    print("=" * 88)

    print("Construindo propagador local 3x3...")
    t0 = time.time()
    U_local = build_local_propagator(V, phys, num.dt_fs)
    local_unitarity_err = validate_local_operator(U_local)
    print(f"Propagador pronto em {time.time() - t0:.2f} s")
    print(f"Erro máximo U^dagger U-I: {local_unitarity_err:.3e}")

    Psi = np.zeros((3, num.nx, num.ny), dtype=np.complex128)
    Psi[0] = gaussian_packet(
        X, Y, phys.sigma_nm, phys.k0_nm_inv, dx, dy
    )

    nsteps = int(round(num.tmax_ps * 1000.0 / num.dt_fs))

    times = []
    history = {key: [] for key in (
        "P1", "P2", "P3", "coherence", "purity",
        "rx", "ry", "rz", "bloch_norm",
        "rho13_re", "rho13_im", "norm"
    )}

    def save_state(step):
        rho3 = reduced_layer_density_matrix(Psi, dx, dy)
        obs = logical_observables(rho3)
        times.append(step * num.dt_fs)
        for key in history:
            history[key].append(obs[key])

    def kinetic_half_step(field3):
        fk = np.fft.fft2(field3, axes=(1, 2))
        fk *= T_half[None, :, :]
        return np.fft.ifft2(fk, axes=(1, 2))

    print("Iniciando propagação 3x3...")
    t_start = time.time()
    save_state(0)

    for step in range(1, nsteps + 1):
        Psi = kinetic_half_step(Psi)

        Psi_last = np.moveaxis(Psi, 0, -1)
        Psi_last = np.einsum(
            "...ij,...j->...i", U_local, Psi_last, optimize=True
        )
        Psi = np.moveaxis(Psi_last, -1, 0)

        Psi = kinetic_half_step(Psi)

        if step % num.save_step == 0 or step == nsteps:
            save_state(step)

        if step % max(1, nsteps // 20) == 0:
            elapsed = time.time() - t_start
            frac = step / nsteps
            eta = elapsed * (1.0 - frac) / frac
            print(
                f"[{100.0*frac:6.2f}%] "
                f"t={step*num.dt_fs/1000.0:7.3f} ps | "
                f"elapsed={elapsed:8.1f} s | ETA={eta:8.1f} s"
            )

    elapsed = time.time() - t_start
    times = np.asarray(times, dtype=float)
    for key in history:
        history[key] = np.asarray(history[key], dtype=float)

    max_norm_dev = float(np.max(np.abs(history["norm"] - 1.0)))

    print("\n" + "=" * 88)
    print("RESULTADOS — MODELO CANÔNICO")
    print("=" * 88)
    print(f"Tempo de simulação       : {elapsed:.2f} s")
    print(f"Máximo P2               : {np.max(history['P2']):.10f}")
    print(f"P3 máximo               : {np.max(history['P3']):.10f}")
    print(f"Coerência máxima        : {np.max(history['coherence']):.10f}")
    print(f"Pureza mínima           : {np.min(history['purity']):.10f}")
    print(f"Máximo desvio da norma  : {max_norm_dev:.3e}")
    print(f"Bloch norm mínimo       : {np.min(history['bloch_norm']):.10f}")
    print("=" * 88)

    data = np.column_stack([
        times,
        history["P1"], history["P2"], history["P3"],
        history["coherence"], history["purity"],
        history["rx"], history["ry"], history["rz"],
        history["bloch_norm"], history["rho13_re"], history["rho13_im"],
        history["norm"],
    ])

    data_path = os.path.join(outdir, "full_3x3_CANONICO_dados.dat")
    np.savetxt(
        data_path,
        data,
        header=(
            "t_fs P1 P2 P3 coherence purity rx ry rz bloch_norm "
            "rho13_re rho13_im norm"
        ),
    )

    report_path = os.path.join(outdir, "full_3x3_CANONICO_relatorio.txt")
    with open(report_path, "w", encoding="utf-8") as f:
        f.write("TRICAMADA — MODELO CANÔNICO 3x3\n")
        f.write("=" * 88 + "\n")
        f.write("H11 = U1 + V(r); H22 = U2; H33 = U3\n")
        f.write("V(r) atua somente em A11.\n\n")
        f.write(f"Delta12 = {phys.Delta12_meV:.9f} meV\n")
        f.write(f"Delta23 = {phys.Delta23_meV:.9f} meV\n")
        f.write(f"J_signed = {J_signed:.12f} meV\n")
        f.write(f"abs(J) = {abs(J_signed):.12f} meV\n")
        f.write(f"V0 = {phys.V0_meV:.9f} meV\n")
        f.write(f"x0 = {phys.x0_nm:.9f} nm\n")
        f.write(f"w = {phys.width_nm:.9f} nm\n")
        f.write(f"sigma = {phys.sigma_nm:.9f} nm\n")
        f.write(f"k0 = {phys.k0_nm_inv:.9f} nm^-1\n")
        f.write(f"nx, ny = {num.nx}, {num.ny}\n")
        f.write(f"WX, WY = {num.WX_nm}, {num.WY_nm} nm\n")
        f.write(f"dx, dy = {dx:.12f}, {dy:.12f} nm\n")
        f.write(f"dt = {num.dt_fs:.9f} fs\n")
        f.write(f"tmax = {num.tmax_ps:.9f} ps\n")
        f.write(f"Hermiticity error = {herm_err:.6e}\n")
        f.write(f"Local unitarity error = {local_unitarity_err:.6e}\n")
        f.write(f"Norm deviation max = {max_norm_dev:.6e}\n")
        f.write(f"P2_max = {np.max(history['P2']):.12e}\n")
        f.write(f"P3_max = {np.max(history['P3']):.12e}\n")
        f.write(f"coherence_max = {np.max(history['coherence']):.12e}\n")
        f.write(f"purity_min = {np.min(history['purity']):.12e}\n")
        f.write(f"bloch_norm_min = {np.min(history['bloch_norm']):.12e}\n")
        f.write(f"runtime_s = {elapsed:.6f}\n")

    return {
        "data_path": data_path,
        "report_path": report_path,
        "history": history,
        "times_fs": times,
        "hermiticity_error": herm_err,
        "local_unitarity_error": local_unitarity_err,
        "norm_deviation_max": max_norm_dev,
    }


# =============================================================================
# TESTE CURTO / EXECUÇÃO PRINCIPAL
# =============================================================================

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--quick",
        action="store_true",
        help="teste curto: 64x64, caixa 200 nm, 100 fs",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    phys = PhysicalParameters()
    num = NumericalParameters()

    if args.quick:
        num = NumericalParameters(
            nx=64,
            ny=64,
            WX_nm=200.0,
            WY_nm=200.0,
            dt_fs=0.5,
            tmax_ps=0.1,
            save_step=20,
        )
        outdir = "resultado_CANONICO_quick"
    else:
        outdir = "resultado_CANONICO_3x3"

    result = run_simulation(phys, num, outdir)

    if result["hermiticity_error"] > 1e-13:
        raise RuntimeError("Falha na hermiticidade do Hamiltoniano local.")
    if result["local_unitarity_error"] > 1e-11:
        raise RuntimeError("Falha na unitariedade do propagador local.")
    if result["norm_deviation_max"] > 1e-9:
        raise RuntimeError("Falha na conservação da norma.")

    print(f"Dados salvos em: {result['data_path']}")
    print(f"Relatório salvo em: {result['report_path']}")
    print("VALIDAÇÃO CANÔNICA: PASS")


if __name__ == "__main__":
    main()
