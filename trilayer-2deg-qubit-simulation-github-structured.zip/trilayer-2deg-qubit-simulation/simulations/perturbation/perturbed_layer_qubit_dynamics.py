#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PERTURBED LAYER-QUBIT DYNAMICS — FULL 3x3

Reconstruction of the perturbed dynamics used for the manuscript's Figs. 12–14.

Physical Hamiltonian:
    H(r) = T I_3 + H_layer(r)

    H_layer(r) = [[U1 + V(r), Delta12, 0],
                  [Delta12,    U2,       Delta23],
                  [0,          Delta23,  U3]]

The spatial perturbation acts ONLY on A_11.  It is never split as +V/2 and -V/2
between the outer layers.

Default perturbation:
    V(r) = V0 exp[-(x-x0)^2/(2 w^2)]
    V0 = 5 meV, x0 = 40 nm, w = 10 nm.

Use:
    python3 perturbed_layer_qubit_dynamics.py --V0 5.0
    python3 perturbed_layer_qubit_dynamics.py --V0 0.0

Quick test:
    python3 perturbed_layer_qubit_dynamics.py --V0 5.0 --quick

The script performs the complete 3x3 spatial split-operator propagation and
saves one shared data file used by the Bloch and tomography plotting scripts.
"""
from __future__ import annotations

import argparse
import re
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np



# =============================================================================
# PUBLICATION FIGURE STYLE
# =============================================================================

def configure_matplotlib():
    import matplotlib.pyplot as plt
    plt.rcParams.update({
        "text.usetex": True,
        "font.family": "serif",
        "font.serif": ["Computer Modern Roman"],
        "text.latex.preamble": r"\usepackage{amsmath}",
        "text.color": "black",
        "axes.labelcolor": "black",
        "xtick.color": "black",
        "ytick.color": "black",
        "axes.edgecolor": "black",
        "font.size": 18,
        "axes.labelsize": 19,
        "axes.titlesize": 18,
        "legend.fontsize": 14,
        "xtick.labelsize": 15,
        "ytick.labelsize": 15,
        "axes.linewidth": 0.75,
        "xtick.major.size": 5,
        "ytick.major.size": 5,
        "xtick.major.width": 0.75,
        "ytick.major.width": 0.75,
        "xtick.minor.visible": True,
        "ytick.minor.visible": True,
        "xtick.minor.size": 2.5,
        "ytick.minor.size": 2.5,
        "xtick.minor.width": 0.55,
        "ytick.minor.width": 0.55,
        "legend.frameon": False,
        "savefig.bbox": "tight",
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })

def polish_axes(ax):
    ax.tick_params(which="major", direction="in", top=True, right=True, length=5, width=0.75)
    ax.tick_params(which="minor", direction="in", top=True, right=True, length=2.5, width=0.55)
    ax.grid(True, which="major", alpha=0.18, linewidth=0.5)
    for spine in ax.spines.values():
        spine.set_linewidth(0.75)

# =============================================================================
# PARAMETERS
# =============================================================================

@dataclass(frozen=True)
class PhysicalParameters:
    hbar_meV_fs: float = 658.211928
    e_charge_C: float = 1.602176634e-19
    m_e_kg: float = 9.1093837015e-31
    m_eff_factor: float = 0.067

    Delta12_meV: float = 5.0
    Delta23_meV: float = 5.0
    Delta13_meV: float = 0.0

    U1_meV: float = 0.0
    U2_meV: float = 100.0
    U3_meV: float = 0.0

    x0_nm: float = 40.0
    width_nm: float = 10.0
    sigma_nm: float = 15.0
    k0_nm_inv: float = 0.0


@dataclass(frozen=True)
class NumericalParameters:
    nx: int = 384
    ny: int = 384
    WX_nm: float = 1200.0
    WY_nm: float = 1200.0
    dt_fs: float = 0.5
    tmax_ps: float = 20.0
    save_step: int = 40


def effective_J_signed(phys: PhysicalParameters) -> float:
    return -phys.Delta12_meV * phys.Delta23_meV / phys.U2_meV


def effective_J_abs(phys: PhysicalParameters) -> float:
    return abs(effective_J_signed(phys))


def Teff_fs(phys: PhysicalParameters) -> float:
    return np.pi * phys.hbar_meV_fs / effective_J_abs(phys)


def tx_fs(phys: PhysicalParameters) -> float:
    return Teff_fs(phys) / 2.0


def sanitize_v0(v0_meV: float) -> str:
    s = f"{v0_meV:.6f}".rstrip("0").rstrip(".")
    return s.replace("-", "m").replace(".", "p")


def data_filename(v0_meV: float) -> str:
    return f"perturbed_layer_qubit_dynamics_V0_{sanitize_v0(v0_meV)}meV.npz"


def report_filename(v0_meV: float) -> str:
    return f"perturbed_layer_qubit_dynamics_V0_{sanitize_v0(v0_meV)}meV_report.txt"


def kinetic_coefficient_meV_nm2(phys: PhysicalParameters) -> float:
    """hbar^2/(2m*) in meV nm^2."""
    hbar_J_s = phys.hbar_meV_fs * 1e-3 * 1e-15 * phys.e_charge_C
    m_eff = phys.m_eff_factor * phys.m_e_kg
    coeff_eV_nm2 = hbar_J_s**2 * 1e18 / (2.0 * m_eff * phys.e_charge_C)
    return 1000.0 * coeff_eV_nm2


def gaussian_packet(X, Y, phys: PhysicalParameters, dx_nm: float, dy_nm: float):
    psi = np.exp(
        -(X**2 + Y**2) / (2.0 * phys.sigma_nm**2)
        + 1j * phys.k0_nm_inv * X
    ).astype(np.complex128)
    norm = np.sqrt(np.sum(np.abs(psi)**2) * dx_nm * dy_nm)
    return psi / norm


def potential(X, v0_meV: float, phys: PhysicalParameters):
    return v0_meV * np.exp(
        -((X - phys.x0_nm) ** 2) / (2.0 * phys.width_nm**2)
    )


def local_hamiltonian(V_meV: np.ndarray, phys: PhysicalParameters) -> np.ndarray:
    H = np.zeros(V_meV.shape + (3, 3), dtype=np.complex128)
    H[..., 0, 0] = phys.U1_meV + V_meV
    H[..., 1, 1] = phys.U2_meV
    H[..., 2, 2] = phys.U3_meV
    H[..., 0, 1] = H[..., 1, 0] = phys.Delta12_meV
    H[..., 1, 2] = H[..., 2, 1] = phys.Delta23_meV
    H[..., 0, 2] = H[..., 2, 0] = phys.Delta13_meV
    return H


def build_local_propagator(V_meV: np.ndarray, phys: PhysicalParameters, dt_fs: float):
    H = local_hamiltonian(V_meV, phys)
    eigvals, eigvecs = np.linalg.eigh(H)
    phases = np.exp(-1j * eigvals * dt_fs / phys.hbar_meV_fs)
    U = np.einsum(
        "...ik,...k,...jk->...ij",
        eigvecs,
        phases,
        np.conjugate(eigvecs),
        optimize=True,
    )
    herm_err = float(np.max(np.abs(H - np.conjugate(np.swapaxes(H, -1, -2)))))
    ident = np.eye(3, dtype=np.complex128)
    UU = np.einsum("...ji,...jk->...ik", np.conjugate(U), U)
    unit_err = float(np.max(np.linalg.norm(UU - ident, axis=(-2, -1))))
    return U, herm_err, unit_err


def reduced_density(Psi: np.ndarray, dx_nm: float, dy_nm: float) -> np.ndarray:
    return np.einsum(
        "ixy,jxy->ij", Psi, np.conjugate(Psi), optimize=True
    ) * dx_nm * dy_nm


def observables(Psi, dx_nm: float, dy_nm: float):
    rho3 = reduced_density(Psi, dx_nm, dy_nm)
    rho11 = float(np.real(rho3[0, 0]))
    rho22 = float(np.real(rho3[1, 1]))
    rho33 = float(np.real(rho3[2, 2]))
    rho13 = complex(rho3[0, 2])
    rho2 = np.array(
        [[rho11, rho13], [np.conjugate(rho13), rho33]], dtype=np.complex128
    )
    purity = float(np.real(np.trace(rho2 @ rho2)))
    rx = float(2.0 * np.real(rho13))
    ry = float(-2.0 * np.imag(rho13))
    rz = float(rho11 - rho33)
    bloch_norm = float(np.sqrt(rx**2 + ry**2 + rz**2))
    norm = float(np.real(np.trace(rho3)))
    return rho3, {
        "P1": rho11,
        "P2": rho22,
        "P3": rho33,
        "coherence": abs(rho13),
        "purity": purity,
        "rx": rx,
        "ry": ry,
        "rz": rz,
        "bloch_norm": bloch_norm,
        "norm": norm,
        "rho13_re": float(np.real(rho13)),
        "rho13_im": float(np.imag(rho13)),
    }


def run(v0_meV: float, quick: bool = False):
    if v0_meV < 0:
        raise ValueError("V0 deve ser >= 0 meV.")

    phys = PhysicalParameters()
    if quick:
        num = NumericalParameters(nx=96, ny=96, WX_nm=300.0, WY_nm=300.0,
                                  dt_fs=0.5, tmax_ps=9.0, save_step=10)
    else:
        num = NumericalParameters()

    base = Path(__file__).resolve().parent
    outdir = base / "perturbed_layer_qubit_dynamics_results"
    outdir.mkdir(exist_ok=True)
    data_path = outdir / data_filename(v0_meV)
    report_path = outdir / report_filename(v0_meV)

    dx = num.WX_nm / num.nx
    dy = num.WY_nm / num.ny
    x = -num.WX_nm / 2.0 + np.arange(num.nx) * dx
    y = -num.WY_nm / 2.0 + np.arange(num.ny) * dy
    X, Y = np.meshgrid(x, y, indexing="ij")

    kx = 2.0 * np.pi * np.fft.fftfreq(num.nx, d=dx)
    ky = 2.0 * np.pi * np.fft.fftfreq(num.ny, d=dy)
    KX, KY = np.meshgrid(kx, ky, indexing="ij")
    K2 = KX**2 + KY**2
    kin_coeff = kinetic_coefficient_meV_nm2(phys)
    T_half = np.exp(-1j * kin_coeff * K2 * num.dt_fs / (2.0 * phys.hbar_meV_fs))

    V = potential(X, v0_meV, phys)
    U_local, herm_err, unit_err = build_local_propagator(V, phys, num.dt_fs)

    Psi = np.zeros((3, num.nx, num.ny), dtype=np.complex128)
    Psi[0] = gaussian_packet(X, Y, phys, dx, dy)

    nsteps = int(round(num.tmax_ps * 1000.0 / num.dt_fs))
    times = []
    hist = {k: [] for k in (
        "P1", "P2", "P3", "coherence", "purity",
        "rx", "ry", "rz", "bloch_norm", "norm",
        "rho13_re", "rho13_im"
    )}
    rho_samples = []

    # Representative times used in the manuscript's perturbed tomography figure.
    Teff = Teff_fs(phys)
    tx = tx_fs(phys)
    sample_targets = np.array([0.0, Teff/4.0, tx, 3.0*Teff/4.0, Teff])
    sample_steps = np.array([int(round(t / num.dt_fs)) for t in sample_targets], dtype=int)
    sample_steps = np.clip(sample_steps, 0, nsteps)
    sample_map = set(sample_steps.tolist())

    def save_state(step):
        rho3, obs = observables(Psi, dx, dy)
        times.append(step * num.dt_fs)
        for key in hist:
            hist[key].append(obs[key])
        if step in sample_map:
            rho_samples.append((step, rho3.copy()))

    save_state(0)
    t0 = time.perf_counter()

    for step in range(1, nsteps + 1):
        fk = np.fft.fft2(Psi, axes=(1, 2))
        fk *= T_half[None, :, :]
        Psi = np.fft.ifft2(fk, axes=(1, 2))

        Psi_last = np.moveaxis(Psi, 0, -1)
        Psi_last = np.einsum("...ij,...j->...i", U_local, Psi_last, optimize=True)
        Psi = np.moveaxis(Psi_last, -1, 0)

        fk = np.fft.fft2(Psi, axes=(1, 2))
        fk *= T_half[None, :, :]
        Psi = np.fft.ifft2(fk, axes=(1, 2))

        if step % num.save_step == 0 or step == nsteps or step in sample_map:
            save_state(step)

        if step % max(1, nsteps // 10) == 0:
            elapsed = time.perf_counter() - t0
            frac = step / nsteps
            eta = elapsed * (1.0 - frac) / frac
            print(f"[{100*frac:6.2f}%] t={step*num.dt_fs/1000.0:7.3f} ps | elapsed={elapsed:7.1f} s | ETA={eta:7.1f} s")

    elapsed = time.perf_counter() - t0
    times = np.asarray(times, dtype=float)
    for key in hist:
        hist[key] = np.asarray(hist[key], dtype=float)

    # Sort/deduplicate if a sample step coincided with save_step.
    uniq, idx = np.unique(times, return_index=True)
    times = uniq
    for key in hist:
        hist[key] = hist[key][idx]

    # Build sample matrices from saved propagation states, independent of history save grid.
    rho_by_step = {step: rho for step, rho in rho_samples}
    rho_sample_arr = []
    actual_sample_times = []
    sample_purity = []
    sample_coh = []
    sample_bloch = []
    for step in sample_steps:
        if step not in rho_by_step:
            # This can only happen if a duplicate-saving corner case occurred.
            raise RuntimeError(f"Tomography state at step {step} was not captured.")
        rho3 = rho_by_step[step]
        rho_outer = rho3[np.ix_([0, 2], [0, 2])]
        rho_sample_arr.append(rho_outer)
        actual_sample_times.append(step * num.dt_fs)
        coh = abs(rho_outer[0, 1])
        pur = float(np.real(np.trace(rho_outer @ rho_outer)))
        bloch = np.array([
            2.0*np.real(rho_outer[0,1]),
            -2.0*np.imag(rho_outer[0,1]),
            np.real(rho_outer[0,0]-rho_outer[1,1]),
        ])
        sample_purity.append(pur)
        sample_coh.append(coh)
        sample_bloch.append(bloch)

    rho_sample_arr = np.asarray(rho_sample_arr, dtype=np.complex128).transpose(1,2,0)
    sample_bloch = np.asarray(sample_bloch, dtype=float).T
    sample_purity = np.asarray(sample_purity, dtype=float)
    sample_coh = np.asarray(sample_coh, dtype=float)
    actual_sample_times = np.asarray(actual_sample_times, dtype=float)

    max_norm_dev = float(np.max(np.abs(hist["norm"] - 1.0)))
    tx_step = int(round(tx / num.dt_fs))
    tx_candidates = np.where(np.isclose(times, tx_step*num.dt_fs, atol=1e-12))[0]
    if len(tx_candidates) == 0:
        tx_candidates = [int(np.argmin(np.abs(times - tx_step*num.dt_fs)))]
    idx_tx = tx_candidates[0]

    np.savez_compressed(
        data_path,
        times_fs=times,
        P1=hist["P1"], P2=hist["P2"], P3=hist["P3"],
        coherence=hist["coherence"], purity=hist["purity"],
        rx=hist["rx"], ry=hist["ry"], rz=hist["rz"],
        bloch_norm=hist["bloch_norm"], norm=hist["norm"],
        rho13_re=hist["rho13_re"], rho13_im=hist["rho13_im"],
        rho_outer_samples=rho_sample_arr,
        sample_times_fs_requested=sample_targets,
        sample_times_fs=actual_sample_times,
        bloch_samples=sample_bloch,
        purity_samples=sample_purity,
        coherence_samples=sample_coh,
        V0_meV=np.array(v0_meV), x0_nm=np.array(phys.x0_nm), width_nm=np.array(phys.width_nm),
        sigma_nm=np.array(phys.sigma_nm), dt_fs=np.array(num.dt_fs),
        nx=np.array(num.nx), ny=np.array(num.ny), WX_nm=np.array(num.WX_nm), WY_nm=np.array(num.WY_nm),
        hbar_meV_fs=np.array(phys.hbar_meV_fs), Delta12_meV=np.array(phys.Delta12_meV),
        Delta23_meV=np.array(phys.Delta23_meV), U2_meV=np.array(phys.U2_meV),
        J_signed_meV=np.array(effective_J_signed(phys)), J_abs_meV=np.array(effective_J_abs(phys)),
        Teff_fs=np.array(Teff), tx_fs=np.array(tx), tx_grid_fs=np.array(tx_step*num.dt_fs),
        hermiticity_error=np.array(herm_err), local_unitarity_error=np.array(unit_err),
        norm_deviation_max=np.array(max_norm_dev), runtime_s=np.array(elapsed),
    )

    with open(report_path, "w", encoding="utf-8") as f:
        f.write("PERTURBED LAYER-QUBIT DYNAMICS — FULL 3x3\n")
        f.write("="*88 + "\n")
        f.write("H11=U1+V(r); H22=U2; H33=U3; V atua SOMENTE em A11.\n\n")
        f.write(f"V0 = {v0_meV:.9f} meV\n")
        f.write(f"x0 = {phys.x0_nm:.9f} nm\n")
        f.write(f"w = {phys.width_nm:.9f} nm\n")
        f.write(f"sigma = {phys.sigma_nm:.9f} nm\n")
        f.write(f"Delta12 = {phys.Delta12_meV:.9f} meV\n")
        f.write(f"Delta23 = {phys.Delta23_meV:.9f} meV\n")
        f.write(f"U2 = {phys.U2_meV:.9f} meV\n")
        f.write(f"J_signed = {effective_J_signed(phys):.12f} meV\n")
        f.write(f"|J| = {effective_J_abs(phys):.12f} meV\n")
        f.write(f"Teff = {Teff:.12f} fs\n")
        f.write(f"tX ideal = {tx:.12f} fs\n")
        f.write(f"tX grid = {tx_step*num.dt_fs:.12f} fs\n")
        f.write(f"grid = {num.nx} x {num.ny}\n")
        f.write(f"box = {num.WX_nm} x {num.WY_nm} nm^2\n")
        f.write(f"dt = {num.dt_fs} fs\n")
        f.write(f"tmax = {num.tmax_ps} ps\n")
        f.write(f"Hermiticity error = {herm_err:.6e}\n")
        f.write(f"Local unitarity error = {unit_err:.6e}\n")
        f.write(f"Norm deviation max = {max_norm_dev:.6e}\n")
        f.write(f"P2_max = {np.max(hist['P2']):.12e}\n")
        f.write(f"P3_max = {np.max(hist['P3']):.12e}\n")
        f.write(f"coherence_max = {np.max(hist['coherence']):.12e}\n")
        f.write(f"purity_min = {np.min(hist['purity']):.12e}\n")
        f.write(f"bloch_norm_min = {np.min(hist['bloch_norm']):.12e}\n")
        f.write(f"F_X(tX_grid) = {hist['P3'][idx_tx]:.12f}\n")
        f.write(f"runtime_s = {elapsed:.6f}\n")

    print("\n" + "="*88)
    print("PERTURBED LAYER-QUBIT DYNAMICS — FULL 3x3")
    print("="*88)
    print(f"V0                   : {v0_meV:.6f} meV")
    print(f"eta=V0/(2|J|)       : {v0_meV/(2*effective_J_abs(phys)):.6f}")
    print(f"J_signed             : {effective_J_signed(phys):.9f} meV")
    print(f"|J|                  : {effective_J_abs(phys):.9f} meV")
    print(f"Teff                 : {Teff:.6f} fs")
    print(f"tX ideal             : {tx:.6f} fs")
    print(f"tX grid              : {tx_step*num.dt_fs:.6f} fs")
    print(f"Grid                 : {num.nx} x {num.ny}")
    print(f"V Hamiltonian only A11: PASS")
    print(f"Hermiticity error    : {herm_err:.3e}")
    print(f"Local unitarity err  : {unit_err:.3e}")
    print(f"Norm deviation max   : {max_norm_dev:.3e}")
    print(f"P2_max               : {np.max(hist['P2']):.10f}")
    print(f"P3_max               : {np.max(hist['P3']):.10f}")
    print(f"coherence_max        : {np.max(hist['coherence']):.10f}")
    print(f"purity_min           : {np.min(hist['purity']):.10f}")
    print(f"bloch_norm_min       : {np.min(hist['bloch_norm']):.10f}")
    print(f"F_X(tX_grid)         : {hist['P3'][idx_tx]:.10f}")
    # Publication-style figure matching the paper: two vertically stacked panels.
    # Panel (a): populations. Panel (b): reduced-state purity/coherence with
    # thin gray analytical/reference curves and the updated full 3x3 simulation.
    import matplotlib.pyplot as plt
    configure_matplotlib()
    t_ps = times / 1000.0

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(6.6, 7.35), dpi=300, sharex=True)
    fig.patch.set_alpha(0)
    plt.subplots_adjust(left=0.12, right=0.985, bottom=0.095, top=0.985, hspace=0.20)

    # Common analytical reference for the unperturbed effective qubit.
    # Purity remains unity; coherence follows |rho_13| = 1/2 |sin(Omega_eff t)|.
    Omega_eff_per_fs = 2.0 * effective_J_abs(phys) / phys.hbar_meV_fs
    t_fs = times
    purity_ref = np.ones_like(t_fs)
    coherence_ref = 0.5 * np.abs(np.sin(Omega_eff_per_fs * t_fs))

    # (a) Outer-layer populations.
    ax1.plot(t_ps, hist["P1"], color="blue", lw=1.7, label=r"$\rho_{11}$")
    ax1.plot(t_ps, hist["P3"], color="red", lw=1.7, ls="--", label=r"$\rho_{33}$")
    ax1.set_xlabel(r"Time (ps)", fontsize=20)
    ax1.set_ylabel(r"Population", fontsize=20)
    ax1.set_xlim(t_ps[0], t_ps[-1])
    ax1.set_ylim(-0.03, 1.18)
    ax1.text(0.03, 0.985, r"(a)", transform=ax1.transAxes, va="top")
    polish_axes(ax1)
    ax1.legend(loc="upper right", bbox_to_anchor=(0.985, 0.985),
               borderaxespad=0.0, frameon=False, fontsize=13,
               handlelength=1.7, handletextpad=0.4, labelspacing=0.28)

    # (b) Purity and interlayer coherence, in the same comparative style as the paper.
    # Purity reference: thin gray dashed horizontal line at 1.
    ax2.plot(
        t_ps, purity_ref, color="gray", lw=0.9, ls="--", alpha=0.8,
        label=r"$\mathrm{Tr}(\rho^2)$ theory"
    )
    ax2.plot(
        t_ps, hist["purity"], color="black", lw=1.8, ls="--",
        label=r"$\mathrm{Tr}(\rho^2)$ simulation"
    )
    # Coherence reference: thin gray line from the ideal effective two-level model.
    ax2.plot(
        t_ps, coherence_ref, color="gray", lw=0.9, ls=":", alpha=0.85,
        label=r"$|\rho_{13}|$ theory"
    )
    ax2.plot(
        t_ps, hist["coherence"], color="forestgreen", lw=1.8, ls="--",
        label=r"$|\rho_{13}|$ simulation"
    )

    ax2.set_xlabel(r"Time (ps)", fontsize=20)
    ax2.set_ylabel(r"Coherence / purity", fontsize=20)
    ax2.set_xlim(t_ps[0], t_ps[-1])
    ax2.set_ylim(-0.03, 1.24)
    ax2.text(0.03, 0.985, r"(b)", transform=ax2.transAxes, va="top")
    polish_axes(ax2)
    ax2.legend(loc="upper right", bbox_to_anchor=(0.985, 0.985),
               borderaxespad=0.0, frameon=False, fontsize=13,
               handlelength=1.65, handletextpad=0.4, labelspacing=0.28)

    fig_path = outdir / f"perturbed_layer_qubit_dynamics_V0_{sanitize_v0(v0_meV)}meV.pdf"
    fig.savefig(fig_path, format="pdf", dpi=300, bbox_inches="tight", pad_inches=.02)
    fig.savefig(fig_path.with_suffix('.png'), format="png", dpi=450, bbox_inches="tight", pad_inches=.02)
    plt.close(fig)

    print(f"Data                 : {data_path}")
    print(f"Report               : {report_path}")
    print(f"Figure               : {fig_path}")
    print("PERTURBED DYNAMICS: PASS")
    print("="*88)

    return data_path


def main():
    parser = argparse.ArgumentParser(description="Full 3x3 perturbed layer-qubit dynamics.")
    parser.add_argument("--V0", type=float, default=5.0, help="Perturbation amplitude V0 in meV (default: 5.0).")
    parser.add_argument("--quick", action="store_true", help="Short 4-ps validation run on a 96x96 grid.")
    args = parser.parse_args()
    run(args.V0, quick=args.quick)


if __name__ == "__main__":
    main()
