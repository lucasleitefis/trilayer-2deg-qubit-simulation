# Trilayer 2DEG Qubit Simulation

Numerical simulations and figure-generation codes supporting the paper on an effective layer qubit in a trilayer 2DEG system.

The repository is organized to follow the logical progression of the paper: coherent dynamics, qubit control, spatial perturbation, coherence/dephasing, and tomography. Validation scripts are kept separately from the production/figure scripts.

## Repository structure

```text
simulations/
  core/            Canonical full 3x3 solver
  coherent/        Coherent layer-qubit dynamics
  perturbation/    Perturbed dynamics
  coherence/       Coherence reference model
  tomography/      Full 3x3 tomography data generation

figures/
  fig02_coherent_dynamics/
  fig03_x_gate_detuning/
  fig04_effective_model/
  fig05-06_universal_control/
  fig07_perturbation/
  fig08_coherence/
  fig09_dephasing/
  fig10_tomography/

validation/         Numerical/model validation
archive/            Historical intermediate versions
```

## Figure map

| Figure | Main content | Code |
|---|---|---|
| Fig. 1 | Trilayer schematic | graphical figure; no simulation script |
| Fig. 2 | Full 3x3 coherent dynamics vs effective 2x2 model; intermediate-layer leakage | `figures/fig02_coherent_dynamics/` |
| Fig. 3 | X-gate fidelity vs detuning | `figures/fig03_x_gate_detuning/` |
| Fig. 4 | Fidelity and leakage vs $U_2/\Delta$ | `figures/fig04_effective_model/` |
| Fig. 5 | Bloch-sphere trajectory for Z-X-Z control | `figures/fig05-06_universal_control/` |
| Fig. 6 | Time-dependent $J(t)$ and $\delta U(t)$ controls | `figures/fig05-06_universal_control/` |
| Fig. 7 | Perturbation-strength sweep in $\eta$ | `figures/fig07_perturbation/` |
| Fig. 8 | Full dynamics vs local-frequency phase-dispersion reference | `figures/fig08_coherence/` |
| Fig. 9 | Populations, purity, and coherence under spatial perturbation | `figures/fig09_dephasing/` |
| Fig. 10 | Full 3x3 state tomography, density matrices, Bloch vectors, purity/coherence | `simulations/tomography/` + `figures/fig10_tomography/` |

## Validation

The `validation/` directory contains numerical and model checks used to verify fidelity convergence, the sign/convention of the effective coupling, and the 2x2 effective-model reduction.

## Historical versions

Intermediate figure implementations are retained in `archive/historical_versions/` for traceability and reproducibility of the revision history. They are not part of the primary figure-generation workflow.
