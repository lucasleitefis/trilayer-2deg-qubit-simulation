"""
Validation benchmark for the canonical homogeneous 3x3 trilayer model.

PURPOSE
-------
This script validates the internal 3x3 dynamics for V(r)=0 and fixes the sign
convention for the effective Raman coupling

    J = -Delta12 Delta23 / U2.

It compares the numerical split-operator evolution with the exact homogeneous
Hamiltonian benchmark and records the resulting numerical errors.

PHYSICAL MODEL
--------------
The benchmark uses the complete three-layer Hamiltonian. The effective 2x2 model
is not used as a replacement for the physical calculation.

FIGURES
-------
No publication figure is generated directly by this script. It is an audit and
validation tool.

OUTPUTS
-------
The script saves tabulated benchmark data and a text report containing the
relevant parameters and numerical checks.

ROLE IN THE REPRODUCTION CHAIN
------------------------------
Use this script to verify that the canonical 3x3 propagator is implemented
correctly before relying on production datasets.

NOTE
----
This is a validation script, not a production-figure generator.
"""

from __future__ import annotations


#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TRICAMADA — MODELO CANÔNICO 3x3

Base numérica para toda a cadeia de reprodução do manuscrito.

MODELO FÍSICO CONGELADO
-----------------------
Na base de camadas {|1>, |2>, |3>}:

    H(r) = T I_3 + H_layer(r),

    H_layer(r) =
        [[U1 + V(r),  Delta12,       0      ],
         [Delta12,    U2,            Delta23 ],
         [0,           Delta23,       U3      ]].

A perturbação espacial V(r) atua SOMENTE no elemento A_11.
Não existe +V/2 em A_11 e -V/2 em A_33.

Para a análise efetiva, a eliminação de Schrieffer-Wolff é feita no
problema sem V(r), produzindo

    J = - Delta12 Delta23 / U2.

No subespaço lógico {|1>, |3>}, a inclusão posterior da perturbação dá

    H_eff(r) = [[V(r), J], [J, 0]]
              = V(r)/2 I_2 + J sigma_x + V(r)/2 sigma_z.

O termo V(r)/2 I_2 é mantido no propagador efetivo porque V depende da
posição e, portanto, não constitui uma fase global para a dinâmica espacial.

EVOLUÇÃO
--------
A dinâmica espacial é propagada por split-operator simétrico:

    exp[-i H dt/hbar]
      ~= exp[-i T dt/(2 hbar)]
         exp[-i H_layer(r) dt/hbar]
         exp[-i T dt/(2 hbar)].

O propagador local de H_layer(r) é calculado por diagonalização espectral
batelada. A propagação continua sendo COMPLETA 3x3; o estado reduzido de
camada é obtido somente após a evolução, por traço sobre o espaço.

Este arquivo é deliberadamente separado da geração das figuras. Ele salva
os dados numéricos necessários para os scripts de publicação e executa
verificações internas de norma, hermiticidade e unitariedade.

Uso:
    python3 full_3x3_CANONICO.py

Para um teste curto, sem alterar os parâmetros congelados do arquivo:
    python3 full_3x3_CANONICO.py --quick

Para o benchmark homogêneo 3x3 (V=0), isolando a dinâmica interna:
    python3 full_3x3_CANONICO.py --benchmark

O benchmark não executa a grade espacial 384x384; ele compara a evolução
numérica 3x3 construída com o mesmo Hamiltoniano/propagador local contra
a solução exata do Hamiltoniano homogêneo.
"""

import argparse
import os
import time
from dataclasses import dataclass
from typing import Dict

import numpy as np


# =============================================================================
# PARÂMETROS FÍSICOS — CONJUNTO CONGELADO
# =============================================================================

@dataclass(frozen=True)
class PhysicalParameters:
    hbar_ev_s: float = 6.58211928e-16
    e_charge_C: float = 1.602176634e-19
    m_e_kg: float = 9.1093837015e-31

    m_eff_factor: float = 0.067

    Delta12_meV: float = 5.0
    Delta23_meV: float = 5.0
    Delta13_meV: float = 0.0

    U1_meV: float = 0.0
    U2_meV: float = 100.0
    U3_meV: float = 0.0

    V0_meV: float = 5.0
    x0_nm: float = 40.0
    width_nm: float = 10.0

    sigma_nm: float = 15.0
    k0_nm_inv: float = 0.0


@dataclass(frozen=True)
class NumericalParameters:
    nx: int = 384
    ny: int = 384
    WX_nm: float = 1200.0
    WY_nm: float = 1200.0
    dt_fs: float = 0.5
    tmax_ps: float = 20.0
    save_step: int = 40


# =============================================================================
# CONSTANTES / UTILIDADES
# =============================================================================

def hbar_mev_fs(phys: PhysicalParameters) -> float:
    return phys.hbar_ev_s * 1.0e3 * 1.0e15


def J_signed_meV(phys: PhysicalParameters) -> float:
    """Acoplamento efetivo assinado da eliminação de Schrieffer-Wolff."""
    return -phys.Delta12_meV * phys.Delta23_meV / phys.U2_meV


def J_abs_meV(phys: PhysicalParameters) -> float:
    """Magnitude de J, usada exclusivamente em escalas de frequência/tempo."""
    return abs(J_signed_meV(phys))


def kinetic_coefficient_ev_nm2(phys: PhysicalParameters) -> float:
    """hbar^2/(2m*) em eV nm^2, com conversão SI explícita."""
    m_eff = phys.m_eff_factor * phys.m_e_kg
    hbar_J_s = phys.hbar_ev_s * phys.e_charge_C
    return hbar_J_s**2 * 1.0e18 / (2.0 * m_eff * phys.e_charge_C)


def gaussian_packet(X, Y, sigma_nm, k0_nm_inv, dx_nm, dy_nm):
    psi = np.exp(
        -(X**2 + Y**2) / (2.0 * sigma_nm**2)
        + 1j * k0_nm_inv * X
    ).astype(np.complex128)
    norm = np.sqrt(np.sum(np.abs(psi)**2) * dx_nm * dy_nm)
    return psi / norm


def potential_gaussian(X, phys):
    return phys.V0_meV * np.exp(
        -((X - phys.x0_nm) ** 2) / (2.0 * phys.width_nm**2)
    )


# =============================================================================
# HAMILTONIANO LOCAL 3x3 — DEFINIÇÃO ÚNICA DO MODELO
# =============================================================================

def local_hamiltonian(V_meV: np.ndarray, phys: PhysicalParameters) -> np.ndarray:
    """
    Retorna H_layer(r) para todos os pontos da grade.

    DEFINIÇÃO FÍSICA:
        H11 = U1 + V(r)
        H22 = U2
        H33 = U3

    A perturbação NÃO é distribuída entre as camadas externas.
    """
    shape = V_meV.shape
    H = np.zeros(shape + (3, 3), dtype=np.complex128)

    H[..., 0, 0] = phys.U1_meV + V_meV
    H[..., 1, 1] = phys.U2_meV
    H[..., 2, 2] = phys.U3_meV

    H[..., 0, 1] = phys.Delta12_meV
    H[..., 1, 0] = phys.Delta12_meV

    H[..., 1, 2] = phys.Delta23_meV
    H[..., 2, 1] = phys.Delta23_meV

    H[..., 0, 2] = phys.Delta13_meV
    H[..., 2, 0] = phys.Delta13_meV

    return H


def build_local_propagator(V_meV: np.ndarray, phys: PhysicalParameters, dt_fs: float):
    """Constrói U_loc(r)=exp[-i H_layer(r) dt/hbar]."""
    H = local_hamiltonian(V_meV, phys)
    eigvals, eigvecs = np.linalg.eigh(H)
    phases = np.exp(-1j * eigvals * dt_fs / hbar_mev_fs(phys))
    U = np.einsum(
        "...ik,...k,...jk->...ij",
        eigvecs,
        phases,
        np.conjugate(eigvecs),
        optimize=True,
    )
    return U


def validate_local_operator(U_local: np.ndarray) -> float:
    """Maior erro ||U^dagger U-I||_F entre os pontos da grade."""
    ident = np.eye(3, dtype=np.complex128)
    UU = np.einsum("...ji,...jk->...ik", np.conjugate(U_local), U_local)
    err = np.max(np.linalg.norm(UU - ident, axis=(-2, -1)))
    return float(err)


def validate_hermiticity(H_local: np.ndarray) -> float:
    err = np.max(np.abs(H_local - np.conjugate(np.swapaxes(H_local, -1, -2))))
    return float(err)


# =============================================================================
# ESTADO REDUZIDO / OBSERVÁVEIS
# =============================================================================

def reduced_layer_density_matrix(Psi, dx_nm, dy_nm):
    """rho_ij = integral psi_i(r) psi_j*(r) d^2r."""
    return np.einsum(
        "ixy,jxy->ij", Psi, np.conjugate(Psi), optimize=True
    ) * dx_nm * dy_nm


def logical_observables(rho3) -> Dict[str, float]:
    rho11 = float(np.real(rho3[0, 0]))
    rho22 = float(np.real(rho3[1, 1]))
    rho33 = float(np.real(rho3[2, 2]))
    rho13 = complex(rho3[0, 2])

    rx = 2.0 * np.real(rho13)
    ry = -2.0 * np.imag(rho13)
    rz = rho11 - rho33

    rho_q = np.array(
        [[rho11, rho13], [np.conjugate(rho13), rho33]],
        dtype=np.complex128,
    )
    purity = float(np.real(np.trace(rho_q @ rho_q)))

    return {
        "P1": rho11,
        "P2": rho22,
        "P3": rho33,
        "coherence": abs(rho13),
        "purity": purity,
        "rx": float(rx),
        "ry": float(ry),
        "rz": float(rz),
        "bloch_norm": float(np.sqrt(rx**2 + ry**2 + rz**2)),
        "rho13_re": float(np.real(rho13)),
        "rho13_im": float(np.imag(rho13)),
        "norm": float(np.real(np.trace(rho3))),
    }


# =============================================================================
# SIMULAÇÃO
# =============================================================================

def run_simulation(phys: PhysicalParameters, num: NumericalParameters, outdir: str):
    os.makedirs(outdir, exist_ok=True)

    dx = num.WX_nm / num.nx
    dy = num.WY_nm / num.ny

    # Grade periódica FFT: endpoint=False é obrigatório.
    x = -num.WX_nm / 2.0 + np.arange(num.nx) * dx
    y = -num.WY_nm / 2.0 + np.arange(num.ny) * dy
    X, Y = np.meshgrid(x, y, indexing="ij")

    kx = 2.0 * np.pi * np.fft.fftfreq(num.nx, d=dx)
    ky = 2.0 * np.pi * np.fft.fftfreq(num.ny, d=dy)
    KX, KY = np.meshgrid(kx, ky, indexing="ij")
    K2 = KX**2 + KY**2

    kin_coeff = kinetic_coefficient_ev_nm2(phys)
    T_half = np.exp(
        -1j * kin_coeff * K2 * num.dt_fs
        / (2.0 * phys.hbar_ev_s * 1.0e15)
    )

    V = potential_gaussian(X, phys)
    H_local = local_hamiltonian(V, phys)
    herm_err = validate_hermiticity(H_local)

    print("=" * 88)
    print("DINÂMICA COMPLETA 3x3 — MODELO CANÔNICO")
    print("=" * 88)
    print("Hamiltoniano espacial:")
    print("  H11 = U1 + V(r)")
    print("  H22 = U2")
    print("  H33 = U3")
    print("  H12 = Delta12, H23 = Delta23, H13 = Delta13")
    print("-")
    print(f"Delta12              : {phys.Delta12_meV:.6f} meV")
    print(f"Delta23              : {phys.Delta23_meV:.6f} meV")
    print(f"U1                   : {phys.U1_meV:.6f} meV")
    print(f"U2                   : {phys.U2_meV:.6f} meV")
    print(f"U3                   : {phys.U3_meV:.6f} meV")
    J_signed = J_signed_meV(phys)
    J_abs = J_abs_meV(phys)
    print(f"J_signed             : {J_signed:.6f} meV")
    print(f"|J|                  : {J_abs:.6f} meV")
    print(f"V0                   : {phys.V0_meV:.6f} meV")
    print(f"x0                   : {phys.x0_nm:.6f} nm")
    print(f"w                    : {phys.width_nm:.6f} nm")
    print(f"sigma                : {phys.sigma_nm:.6f} nm")
    print(f"k0                   : {phys.k0_nm_inv:.6f} nm^-1")
    print(f"m*/me                : {phys.m_eff_factor:.6f}")
    print(f"hbar^2/(2m*)         : {kin_coeff:.9f} eV nm^2")
    print(f"Grid                 : {num.nx} x {num.ny}")
    print(f"Box                  : {num.WX_nm:.1f} x {num.WY_nm:.1f} nm^2")
    print(f"dx = dy              : {dx:.6f} nm")
    print(f"dt                   : {num.dt_fs:.6f} fs")
    print(f"Total time           : {num.tmax_ps:.6f} ps")
    print(f"save_step            : {num.save_step}")
    print(f"Hermiticity error    : {herm_err:.3e}")
    print("=" * 88)

    print("Construindo propagador local 3x3...")
    t0 = time.time()
    U_local = build_local_propagator(V, phys, num.dt_fs)
    local_unitarity_err = validate_local_operator(U_local)
    print(f"Propagador pronto em {time.time() - t0:.2f} s")
    print(f"Erro máximo U^dagger U-I: {local_unitarity_err:.3e}")

    Psi = np.zeros((3, num.nx, num.ny), dtype=np.complex128)
    Psi[0] = gaussian_packet(
        X, Y, phys.sigma_nm, phys.k0_nm_inv, dx, dy
    )

    nsteps = int(round(num.tmax_ps * 1000.0 / num.dt_fs))

    times = []
    history = {key: [] for key in (
        "P1", "P2", "P3", "coherence", "purity",
        "rx", "ry", "rz", "bloch_norm",
        "rho13_re", "rho13_im", "norm"
    )}

    def save_state(step):
        rho3 = reduced_layer_density_matrix(Psi, dx, dy)
        obs = logical_observables(rho3)
        times.append(step * num.dt_fs)
        for key in history:
            history[key].append(obs[key])

    def kinetic_half_step(field3):
        fk = np.fft.fft2(field3, axes=(1, 2))
        fk *= T_half[None, :, :]
        return np.fft.ifft2(fk, axes=(1, 2))

    print("Iniciando propagação 3x3...")
    t_start = time.time()
    save_state(0)

    for step in range(1, nsteps + 1):
        Psi = kinetic_half_step(Psi)

        Psi_last = np.moveaxis(Psi, 0, -1)
        Psi_last = np.einsum(
            "...ij,...j->...i", U_local, Psi_last, optimize=True
        )
        Psi = np.moveaxis(Psi_last, -1, 0)

        Psi = kinetic_half_step(Psi)

        if step % num.save_step == 0 or step == nsteps:
            save_state(step)

        if step % max(1, nsteps // 20) == 0:
            elapsed = time.time() - t_start
            frac = step / nsteps
            eta = elapsed * (1.0 - frac) / frac
            print(
                f"[{100.0*frac:6.2f}%] "
                f"t={step*num.dt_fs/1000.0:7.3f} ps | "
                f"elapsed={elapsed:8.1f} s | ETA={eta:8.1f} s"
            )

    elapsed = time.time() - t_start
    times = np.asarray(times, dtype=float)
    for key in history:
        history[key] = np.asarray(history[key], dtype=float)

    max_norm_dev = float(np.max(np.abs(history["norm"] - 1.0)))

    print("\n" + "=" * 88)
    print("RESULTADOS — MODELO CANÔNICO")
    print("=" * 88)
    print(f"Tempo de simulação       : {elapsed:.2f} s")
    print(f"Máximo P2               : {np.max(history['P2']):.10f}")
    print(f"P3 máximo               : {np.max(history['P3']):.10f}")
    print(f"Coerência máxima        : {np.max(history['coherence']):.10f}")
    print(f"Pureza mínima           : {np.min(history['purity']):.10f}")
    print(f"Máximo desvio da norma  : {max_norm_dev:.3e}")
    print(f"Bloch norm mínimo       : {np.min(history['bloch_norm']):.10f}")
    print("=" * 88)

    data = np.column_stack([
        times,
        history["P1"], history["P2"], history["P3"],
        history["coherence"], history["purity"],
        history["rx"], history["ry"], history["rz"],
        history["bloch_norm"], history["rho13_re"], history["rho13_im"],
        history["norm"],
    ])

    data_path = os.path.join(outdir, "full_3x3_CANONICO_dados.dat")
    np.savetxt(
        data_path,
        data,
        header=(
            "t_fs P1 P2 P3 coherence purity rx ry rz bloch_norm "
            "rho13_re rho13_im norm"
        ),
    )

    report_path = os.path.join(outdir, "full_3x3_CANONICO_relatorio.txt")
    with open(report_path, "w", encoding="utf-8") as f:
        f.write("TRICAMADA — MODELO CANÔNICO 3x3\n")
        f.write("=" * 88 + "\n")
        f.write("H11 = U1 + V(r); H22 = U2; H33 = U3\n")
        f.write("V(r) atua somente em A11.\n\n")
        f.write(f"Delta12 = {phys.Delta12_meV:.9f} meV\n")
        f.write(f"Delta23 = {phys.Delta23_meV:.9f} meV\n")
        f.write(f"J_signed = {J_signed:.12f} meV\n")
        f.write(f"abs(J) = {J_abs:.12f} meV\n")
        f.write(f"V0 = {phys.V0_meV:.9f} meV\n")
        f.write(f"x0 = {phys.x0_nm:.9f} nm\n")
        f.write(f"w = {phys.width_nm:.9f} nm\n")
        f.write(f"sigma = {phys.sigma_nm:.9f} nm\n")
        f.write(f"k0 = {phys.k0_nm_inv:.9f} nm^-1\n")
        f.write(f"nx, ny = {num.nx}, {num.ny}\n")
        f.write(f"WX, WY = {num.WX_nm}, {num.WY_nm} nm\n")
        f.write(f"dx, dy = {dx:.12f}, {dy:.12f} nm\n")
        f.write(f"dt = {num.dt_fs:.9f} fs\n")
        f.write(f"tmax = {num.tmax_ps:.9f} ps\n")
        f.write(f"Hermiticity error = {herm_err:.6e}\n")
        f.write(f"Local unitarity error = {local_unitarity_err:.6e}\n")
        f.write(f"Norm deviation max = {max_norm_dev:.6e}\n")
        f.write(f"P2_max = {np.max(history['P2']):.12e}\n")
        f.write(f"P3_max = {np.max(history['P3']):.12e}\n")
        f.write(f"coherence_max = {np.max(history['coherence']):.12e}\n")
        f.write(f"purity_min = {np.min(history['purity']):.12e}\n")
        f.write(f"bloch_norm_min = {np.min(history['bloch_norm']):.12e}\n")
        f.write(f"runtime_s = {elapsed:.6f}\n")

    return {
        "data_path": data_path,
        "report_path": report_path,
        "history": history,
        "times_fs": times,
        "hermiticity_error": herm_err,
        "local_unitarity_error": local_unitarity_err,
        "norm_deviation_max": max_norm_dev,
    }


# =============================================================================
# BENCHMARK HOMOGÊNEO 3x3 — ETAPA 2
# =============================================================================

def exact_internal_state(H0_meV: np.ndarray, psi0: np.ndarray, times_fs: np.ndarray,
                         phys: PhysicalParameters) -> np.ndarray:
    """Solução exata psi(t)=exp(-i H0 t/hbar) psi(0) por diagonalização espectral."""
    eigvals, eigvecs = np.linalg.eigh(H0_meV)
    coeff = eigvecs.conj().T @ psi0
    phases = np.exp(-1j * np.outer(times_fs, eigvals) / hbar_mev_fs(phys))
    return (phases * coeff[None, :]) @ eigvecs.conj().T


def benchmark_homogeneous_3x3(phys: PhysicalParameters):
    """
    Validação da dinâmica interna homogênea (V=0), sem FFT.

    O propagador de passo é construído pela mesma rotina local 3x3 usada na
    simulação completa. A referência é a solução exata do Hamiltoniano 3x3
    homogêneo. O estado inicial é |1>.
    """
    dt_fs = 0.5
    tmax_fs = 20_000.0
    save_every = 20

    H0 = local_hamiltonian(np.zeros((), dtype=float), phys)
    H0 = np.asarray(H0, dtype=np.complex128)
    # local_hamiltonian em um escalar retorna shape (3,3).
    if H0.shape != (3, 3):
        raise RuntimeError(f"Hamiltoniano homogêneo com shape inesperado: {H0.shape}")

    herm_err = validate_hermiticity(H0)
    U_step = build_local_propagator(np.array(0.0), phys, dt_fs)
    U_step = np.asarray(U_step, dtype=np.complex128)
    if U_step.shape != (3, 3):
        raise RuntimeError(f"Propagador homogêneo com shape inesperado: {U_step.shape}")
    unit_err = validate_local_operator(U_step)

    J_signed = J_signed_meV(phys)
    J_abs = J_abs_meV(phys)

    t_steps = int(round(tmax_fs / dt_fs))
    steps = np.arange(0, t_steps + 1, save_every, dtype=int)
    times_fs = steps * dt_fs

    psi0 = np.array([1.0 + 0.0j, 0.0 + 0.0j, 0.0 + 0.0j], dtype=np.complex128)
    psi_num = psi0.copy()
    numerical = np.empty((len(steps), 3), dtype=np.complex128)
    numerical[0] = psi_num

    out = 1
    for step in range(1, t_steps + 1):
        psi_num = U_step @ psi_num
        if step == steps[out]:
            numerical[out] = psi_num
            out += 1
            if out == len(steps):
                break

    exact = exact_internal_state(H0, psi0, times_fs, phys)

    p_num = np.abs(numerical) ** 2
    p_exact = np.abs(exact) ** 2
    max_state_err = float(np.max(np.linalg.norm(numerical - exact, axis=1)))
    max_p_err = float(np.max(np.abs(p_num - p_exact)))
    max_p1_err = float(np.max(np.abs(p_num[:, 0] - p_exact[:, 0])))
    max_p2_err = float(np.max(np.abs(p_num[:, 1] - p_exact[:, 1])))
    max_p3_err = float(np.max(np.abs(p_num[:, 2] - p_exact[:, 2])))
    norm_num = np.sum(p_num, axis=1)
    max_norm_dev = float(np.max(np.abs(norm_num - 1.0)))

    # Verificação adicional de que a redução SW produz o J assinado esperado.
    expected_J = -(phys.Delta12_meV * phys.Delta23_meV) / phys.U2_meV
    J_consistency_err = abs(J_signed - expected_J)

    # Escalas de tempo/frequência usam |J|, nunca J_signed.
    Omega_eff_rad_fs = 2.0 * J_abs / hbar_mev_fs(phys)
    T_eff_fs = np.pi * hbar_mev_fs(phys) / J_abs
    t_X_fs = T_eff_fs / 2.0

    print("=" * 88)
    print("BENCHMARK HOMOGÊNEO 3x3 — ETAPA 2")
    print("=" * 88)
    print("V(r) = 0 em toda a dinâmica; sem FFT/espaço: apenas dinâmica interna.")
    print("Hamiltoniano H0 [meV]:")
    print(H0)
    print("-")
    print(f"J_signed             : {J_signed:.12f} meV")
    print(f"|J|                  : {J_abs:.12f} meV")
    print(f"Omega_eff = 2|J|/hbar: {Omega_eff_rad_fs:.12e} fs^-1")
    print(f"T_eff                : {T_eff_fs:.6f} fs")
    print(f"t_X                  : {t_X_fs:.6f} fs")
    print(f"Hermiticity error    : {herm_err:.3e}")
    print(f"Local unitarity err  : {unit_err:.3e}")
    print(f"Max state error      : {max_state_err:.3e}")
    print(f"Max population error : {max_p_err:.3e}")
    print(f"Max P1 error         : {max_p1_err:.3e}")
    print(f"Max P2 error         : {max_p2_err:.3e}")
    print(f"Max P3 error         : {max_p3_err:.3e}")
    print(f"Max norm deviation   : {max_norm_dev:.3e}")
    print(f"J consistency error  : {J_consistency_err:.3e}")
    print("=" * 88)

    report = {
        "J_signed_meV": J_signed,
        "J_abs_meV": J_abs,
        "Omega_eff_rad_fs": Omega_eff_rad_fs,
        "T_eff_fs": T_eff_fs,
        "t_X_fs": t_X_fs,
        "hermiticity_error": herm_err,
        "local_unitarity_error": unit_err,
        "max_state_error": max_state_err,
        "max_population_error": max_p_err,
        "max_P1_error": max_p1_err,
        "max_P2_error": max_p2_err,
        "max_P3_error": max_p3_err,
        "max_norm_deviation": max_norm_dev,
        "J_consistency_error": J_consistency_err,
    }

    # Critérios próprios do benchmark: a tolerância de população é muito mais
    # frouxa que a precisão do operador, porque o erro aqui é de acumulação do
    # produto repetido do propagador de passo por 20 ps.
    passed = (
        herm_err < 1e-13
        and unit_err < 1e-12
        and max_state_err < 1e-10
        and max_p_err < 1e-10
        and max_norm_dev < 1e-10
        and J_consistency_err < 1e-14
    )

    if passed:
        print("BENCHMARK HOMOGÊNEO 3x3: PASS")
    else:
        print("BENCHMARK HOMOGÊNEO 3x3: FAIL")
        raise RuntimeError("Falha no benchmark homogêneo 3x3.")

    return report


# =============================================================================
# TESTE CURTO / EXECUÇÃO PRINCIPAL
# =============================================================================

def main():
    phys = PhysicalParameters()
    benchmark_homogeneous_3x3(phys)


if __name__ == "__main__":
    main()
