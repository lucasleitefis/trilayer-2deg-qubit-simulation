#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Validation of the effective 2x2 description of the trilayer qubit.

PURPOSE
-------
This script tests the Schrieffer-Wolff / adiabatic-elimination description of the
outer-layer logical subspace {|1>, |3>} against the exact 3x3 Hamiltonian.

The effective model is

    H_eff(V) = [[V, J],
                [J, 0]]

with

    J = -Delta12 Delta23 / U2.

It also checks the decomposition

    H_eff = V/2 I + J sigma_x + V/2 sigma_z

and compares the effective and full 3x3 dynamics at the nominal X-gate time.

FIGURES
-------
No publication figure is generated directly by this script.

OUTPUTS
-------
The script prints the benchmark quantities and comparison errors to the terminal.

ROLE IN THE REPRODUCTION CHAIN
------------------------------
This is an analytical/numerical validation tool. The full 3x3 model remains the
physical reference for the manuscript; the 2x2 model is used only for validation
and interpretation.

NOTE
----
This script should not be used as the production engine for the spatially
perturbed figures.
"""

from __future__ import annotations

import numpy as np

# -----------------------------------------------------------------------------
# Parâmetros congelados
# -----------------------------------------------------------------------------
U1 = 0.0       # meV
U2 = 100.0     # meV
U3 = 0.0       # meV
Delta12 = 5.0  # meV
Delta23 = 5.0  # meV
V0 = 5.0       # meV — working point do modelo espacial
hbar_meV_fs = 658.211928

J_signed = -Delta12 * Delta23 / U2
J_abs = abs(J_signed)

Omega_eff = 2.0 * J_abs / hbar_meV_fs
T_eff_fs = np.pi * hbar_meV_fs / J_abs
tX_fs = T_eff_fs / 2.0


def H3(V: float = 0.0) -> np.ndarray:
    return np.array(
        [
            [U1 + V, Delta12, 0.0],
            [Delta12, U2, Delta23],
            [0.0, Delta23, U3],
        ], dtype=complex
    )


def H2(V: float = 0.0) -> np.ndarray:
    # A ordem lógica é {|1>, |3>}.
    return np.array(
        [[V, J_signed], [J_signed, 0.0]], dtype=complex
    )


def expm_hermitian(H: np.ndarray, t_fs: float) -> np.ndarray:
    vals, vecs = np.linalg.eigh(H)
    return vecs @ np.diag(np.exp(-1j * vals * t_fs / hbar_meV_fs)) @ vecs.conj().T


def main() -> None:
    print("=" * 88)
    print("ETAPA 3 — VALIDAÇÃO DO MODELO EFETIVO 2x2")
    print("=" * 88)
    print(f"U2                  = {U2:.6f} meV")
    print(f"Delta12             = {Delta12:.6f} meV")
    print(f"Delta23             = {Delta23:.6f} meV")
    print(f"J_signed            = {J_signed:.12f} meV")
    print(f"|J|                 = {J_abs:.12f} meV")
    print(f"Omega_eff           = {Omega_eff:.12e} fs^-1")
    print(f"T_eff               = {T_eff_fs:.9f} fs")
    print(f"t_X                 = {tX_fs:.9f} fs")

    # -------------------------------------------------------------------------
    # 1) Verificação algébrica do H_eff
    # -------------------------------------------------------------------------
    I2 = np.eye(2, dtype=complex)
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)

    H_direct = H2(V0)
    H_pauli = (V0 / 2.0) * I2 + J_signed * sx + (V0 / 2.0) * sz
    err_decomp = np.max(np.abs(H_direct - H_pauli))

    # Compare with the historically incorrect expression that drops V I/2.
    H_no_identity = J_signed * sx + (V0 / 2.0) * sz
    missing_identity = np.max(np.abs(H_direct - H_no_identity))

    # -------------------------------------------------------------------------
    # 2) SW: splitting exato 3x3 vs 2|J|
    # -------------------------------------------------------------------------
    e3 = np.linalg.eigvalsh(H3(0.0))
    e3_low = np.sort(e3)[:2]
    split_3 = e3_low[1] - e3_low[0]
    split_eff = 2.0 * J_abs
    split_rel_err = abs(split_3 - split_eff) / split_eff

    # -------------------------------------------------------------------------
    # 3) Dinâmica homogênea em t_X
    # -------------------------------------------------------------------------
    psi3_0 = np.array([1.0, 0.0, 0.0], dtype=complex)
    psi2_0 = np.array([1.0, 0.0], dtype=complex)

    U3 = expm_hermitian(H3(0.0), tX_fs)
    U2_prop = expm_hermitian(H2(0.0), tX_fs)
    psi3 = U3 @ psi3_0
    psi2 = U2_prop @ psi2_0

    P1_3 = abs(psi3[0]) ** 2
    P2_3 = abs(psi3[1]) ** 2
    P3_3 = abs(psi3[2]) ** 2
    P1_2 = abs(psi2[0]) ** 2
    P3_2 = abs(psi2[1]) ** 2

    # Fidelity física do estado lógico alvo |3>, sem renormalizar o 3x3.
    F3_X = P3_3
    F2_X = P3_2

    # -------------------------------------------------------------------------
    # 4) Checagens numéricas
    # -------------------------------------------------------------------------
    unit3 = np.max(np.abs(U3.conj().T @ U3 - np.eye(3)))
    unit2 = np.max(np.abs(U2_prop.conj().T @ U2_prop - np.eye(2)))
    norm3 = abs(np.vdot(psi3, psi3) - 1.0)
    norm2 = abs(np.vdot(psi2, psi2) - 1.0)

    print("\n--- H_eff(V0) ---")
    print(H_direct)
    print(f"Erro da decomposição Pauli          : {err_decomp:.3e}")
    print(f"Erro com V I/2 omitido              : {missing_identity:.6f} meV")

    print("\n--- SW / splitting ---")
    print(f"Autovalores 3x3 (meV)               : {e3}")
    print(f"Dois níveis baixos 3x3 (meV)        : {e3_low}")
    print(f"Splitting exato 3x3                 : {split_3:.12f} meV")
    print(f"Splitting efetivo 2|J|              : {split_eff:.12f} meV")
    print(f"Erro relativo do splitting          : {split_rel_err:.6e}")

    print("\n--- Dinâmica em t_X ---")
    print(f"t_X                                 : {tX_fs:.9f} fs")
    print(f"3x3: P1={P1_3:.12f}, P2={P2_3:.12f}, P3={P3_3:.12f}")
    print(f"2x2: P1={P1_2:.12f}, P3={P3_2:.12f}")
    print(f"F_X no 3x3 (P3)                    : {F3_X:.12f}")
    print(f"F_X ideal no 2x2                   : {F2_X:.12f}")
    print(f"Leakage P2 no 3x3                  : {P2_3:.12f}")

    print("\n--- Unitaridade ---")
    print(f"Erro U3^†U3-I                       : {unit3:.3e}")
    print(f"Erro U2^†U2-I                       : {unit2:.3e}")
    print(f"Desvio de norma 3x3                 : {norm3:.3e}")
    print(f"Desvio de norma 2x2                 : {norm2:.3e}")

    passed = (
        err_decomp < 1e-12
        and unit3 < 1e-12
        and unit2 < 1e-12
        and norm3 < 1e-12
        and norm2 < 1e-12
        and J_signed < 0.0
        and abs(J_abs - 0.25) < 1e-12
    )

    print("=" * 88)
    print(f"ETAPA 3 — TESTES ESTRUTURAIS: {'PASS' if passed else 'FAIL'}")
    print("Obs.: diferença 3x3 vs 2x2 é física e esperada; o modelo 2x2 é efetivo.")
    print("=" * 88)

    if not passed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
