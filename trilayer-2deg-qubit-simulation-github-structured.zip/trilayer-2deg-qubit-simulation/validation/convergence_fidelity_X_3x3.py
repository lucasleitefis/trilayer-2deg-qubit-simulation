#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DEFINITIVE NUMERICAL CONVERGENCE OF THE MEAN X-GATE FIDELITY
==============================================================

Purpose
-------
This script addresses referee comment 2.8 by determining the numerical
convergence of the MEAN X-gate fidelity for the full trilayer 3x3 model.

The calculation uses:
    * the complete 3x3 layer Hamiltonian;
    * the full 2D wave-packet propagation;
    * the same split-operator Fourier method used in the manuscript;
    * V0 = 0, i.e. the coherent-gate benchmark.

Mean gate fidelity
------------------
The gate is characterized with the six Pauli/Bloch input states

    |0>, |1>, |+>, |->, |+_y>, |-_y>,

where |0> = |1_layer> and |1> = |3_layer>.

For each input state |psi>, the ideal target is X|psi>. The reported
fidelity is leakage-sensitive:

    F_X(psi) = <X psi | rho_logical | X psi>,

where rho_logical is the unnormalized {|1>,|3>} block of the full
3x3 reduced layer density matrix. Population in the auxiliary
intermediate layer therefore lowers the fidelity automatically.

The mean is

    F_X^avg = (1/6) sum_k F_X(psi_k).

Exact basis reduction used for computational efficiency
--------------------------------------------------------
The six input states are NOT propagated independently in the refinement
runs.

Because the Schrödinger evolution is linear, it is sufficient to
propagate only the two computational-basis inputs

    |0> = |1_layer>,
    |1> = |3_layer>,

and retain the full cross-density operators

    R_mn = Tr_sp[ |Psi_m><Psi_n| ],    m,n = 0,1.

For an arbitrary logical input

    |psi> = a|0> + b|1>,

its reduced layer state is reconstructed exactly as

    rho_out =
        |a|^2 R_00
      + |b|^2 R_11
      + a b* R_01
      + a* b R_10.

Therefore the six fidelities are obtained EXACTLY from the two propagated
basis states. This is not a physical approximation and does not replace
the full 3x3 dynamics. It only exploits linearity to avoid six independent
propagations.

The two basis states are propagated simultaneously in a batch, using the
same spatial grid, kinetic propagator, and local 3x3 propagator.

Production result reuse
------------------------
The production calculation

    N = 384 x 384
    dx = 3.125 nm
    dt = 0.50 fs
    t_X = 4135.5 fs

has already been performed for the six Bloch states. The script therefore
tries to reuse the existing production CSV. If it is found, the expensive
production propagation is NOT repeated.

Only the three refinement calculations are then propagated:

    (1) spatial refinement:
        N = 512 x 512, dt = 0.50 fs

    (2) temporal refinement:
        N = 384 x 384, dt = 0.25 fs

    (3) combined refinement/reference:
        N = 512 x 512, dt = 0.25 fs

All configurations are compared at the same physical gate time

    t_X = 4135.5 fs.

Numerical error estimate
------------------------
The reported numerical sensitivity is the maximum deviation of the
production mean fidelity from the three refined calculations:

    delta_F_num = max(
        |F_prod - F_spatial|,
        |F_prod - F_temporal|,
        |F_prod - F_reference|
    ).

This is a deterministic numerical-convergence estimate. It is not a
statistical uncertainty and is not claimed to be a rigorous truncation-
error bound.

Important distinction
---------------------
This calculation quantifies numerical convergence of the gate fidelity.
It is separate from the physical gate infidelity

    1 - F_X^avg,

and separate from the maximum intermediate-layer population P2_max.
The purpose here is specifically to provide the numerical-resolution
information requested by the referee.

Outputs
-------
The script creates:

    mean_fidelity_per_state_optimized.csv
    mean_fidelity_convergence_summary_optimized.csv
    mean_fidelity_convergence_report_optimized.txt
    mean_fidelity_convergence_optimized.pdf

The terminal prints the final

    F_X^avg +/- delta_F_num

for the production grid.
"""

from __future__ import annotations

import argparse
import csv
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np


# =============================================================================
# PHYSICAL PARAMETERS — MATCH THE CONSOLIDATED 384^2 STAGE-2 CALCULATION
# =============================================================================

@dataclass(frozen=True)
class PhysicalParameters:
    hbar_ev_s: float = 6.58211928e-16
    e_charge_c: float = 1.60217662e-19
    m_e_kg: float = 9.1093837e-31
    m_eff_factor: float = 0.067

    Delta12: float = 0.005       # eV = 5 meV
    Delta23: float = 0.005       # eV = 5 meV
    Delta13: float = 0.0         # eV

    U1: float = 0.0              # eV
    U2: float = 0.100            # eV = 100 meV
    U3: float = 0.0              # eV

    V0: float = 0.0              # coherent benchmark
    sigma_nm: float = 15.0
    k0_nm_inv: float = 0.0


@dataclass(frozen=True)
class NumericalConfiguration:
    N: int
    dt_fs: float
    W_nm: float = 1200.0
    sigma_nm: float = 15.0
    k0_nm_inv: float = 0.0


# =============================================================================
# CONSTANTS / GATE TIME
# =============================================================================

def hbar_ev_fs(phys: PhysicalParameters) -> float:
    return phys.hbar_ev_s * 1.0e15


def kinetic_coefficient_ev_nm2(phys: PhysicalParameters) -> float:
    """Return hbar^2/(2m*) in eV nm^2."""
    m_eff = phys.m_eff_factor * phys.m_e_kg
    hbar_j_s = phys.hbar_ev_s * phys.e_charge_c
    return hbar_j_s**2 * 1.0e18 / (
        2.0 * m_eff * phys.e_charge_c
    )


def gate_times(
    phys: PhysicalParameters,
) -> tuple[float, float, float]:
    """
    Return signed J, theoretical t_X, and common numerical t_X.

    The common numerical gate time is fixed to the production grid:
    dt = 0.5 fs -> t_X = 4135.5 fs.
    """
    J_signed = -(phys.Delta12 * phys.Delta23) / phys.U2
    J_abs = abs(J_signed)

    tX_theory_fs = (
        np.pi * phys.hbar_ev_s / (2.0 * J_abs) * 1.0e15
    )

    tX_prod_fs = round(tX_theory_fs / 0.5) * 0.5

    return J_signed, tX_theory_fs, tX_prod_fs


# =============================================================================
# SIX BLOCH INPUTS
# =============================================================================

def logical_input_states() -> tuple[list[str], np.ndarray]:
    """
    Return the six logical inputs as 3-component layer kets.

    Layer basis:
        (|1>, |2>, |3>)

    Logical basis:
        |0> = |1>
        |1> = |3>
    """
    s = 1.0 / np.sqrt(2.0)

    labels = ["0", "1", "+", "-", "+y", "-y"]

    states = np.array(
        [
            [1.0, 0.0, 0.0],
            [0.0, 0.0, 1.0],
            [s, 0.0, s],
            [s, 0.0, -s],
            [s, 0.0, 1j * s],
            [s, 0.0, -1j * s],
        ],
        dtype=np.complex128,
    )

    return labels, states


# Logical coefficients c = (a,b) for the six states.
def logical_coefficients() -> tuple[list[str], np.ndarray]:
    labels, states3 = logical_input_states()
    coeffs = states3[:, [0, 2]].copy()
    return labels, coeffs


# =============================================================================
# SPATIAL GRID / INITIAL PACKET
# =============================================================================

def make_grid(
    cfg: NumericalConfiguration,
) -> tuple[float, np.ndarray, np.ndarray]:
    dx = cfg.W_nm / cfg.N

    x = -cfg.W_nm / 2.0 + np.arange(cfg.N) * dx
    y = x.copy()

    X, Y = np.meshgrid(x, y, indexing="ij")

    kx = 2.0 * np.pi * np.fft.fftfreq(cfg.N, d=dx)
    ky = 2.0 * np.pi * np.fft.fftfreq(cfg.N, d=dx)

    KX, KY = np.meshgrid(kx, ky, indexing="ij")
    K2 = KX**2 + KY**2

    return dx, X, Y, K2


def initial_wavepacket(
    X: np.ndarray,
    Y: np.ndarray,
    cfg: NumericalConfiguration,
    dx: float,
) -> np.ndarray:
    phi = np.exp(
        -(X**2 + Y**2) / (2.0 * cfg.sigma_nm**2)
        + 1j * cfg.k0_nm_inv * X
    ).astype(np.complex128)

    norm = np.sqrt(np.sum(np.abs(phi) ** 2) * dx * dx)

    if norm == 0.0:
        raise RuntimeError("Initial wave-packet norm is zero.")

    return phi / norm


# =============================================================================
# LOCAL 3x3 PROPAGATOR
# =============================================================================

def build_local_propagator(
    phys: PhysicalParameters,
    dt_fs: float,
) -> np.ndarray:
    H = np.array(
        [
            [phys.U1, phys.Delta12, phys.Delta13],
            [phys.Delta12, phys.U2, phys.Delta23],
            [phys.Delta13, phys.Delta23, phys.U3],
        ],
        dtype=np.complex128,
    )

    eigvals, eigvecs = np.linalg.eigh(H)

    phases = np.exp(
        -1j * eigvals * dt_fs / hbar_ev_fs(phys)
    )

    return eigvecs @ np.diag(phases) @ eigvecs.conj().T


# =============================================================================
# TWO-BASIS PROPAGATION
# =============================================================================

def propagate_two_basis_states(
    phys: PhysicalParameters,
    cfg: NumericalConfiguration,
    target_t_fs: float,
    progress: bool = True,
) -> dict[str, object]:
    """
    Propagate only the two computational-basis inputs simultaneously.

    Array shape:
        Psi[basis_state, layer, x, y]

    basis_state = 0 -> |0> = |1_layer>
    basis_state = 1 -> |1> = |3_layer>

    The full reduced cross-density operators R_mn are constructed after
    propagation. They are sufficient to reconstruct all six Bloch-state
    outputs exactly.
    """
    basis_states = np.array(
        [
            [1.0, 0.0, 0.0],
            [0.0, 0.0, 1.0],
        ],
        dtype=np.complex128,
    )

    dx, X, Y, K2 = make_grid(cfg)

    phi0 = initial_wavepacket(X, Y, cfg, dx)

    norm0 = float(np.sum(np.abs(phi0) ** 2) * dx * dx)
    if abs(norm0 - 1.0) > 1.0e-12:
        raise RuntimeError(
            f"Initial wave-packet norm = {norm0:.16e}"
        )

    coeff = kinetic_coefficient_ev_nm2(phys)

    Uloc = build_local_propagator(
        phys,
        cfg.dt_fs,
    )

    # Psi[basis, layer, x, y]
    Psi = (
        basis_states[:, :, None, None]
        * phi0[None, None, :, :]
    )

    nsteps = int(round(target_t_fs / cfg.dt_fs))

    if abs(nsteps * cfg.dt_fs - target_t_fs) > 1.0e-9:
        raise RuntimeError(
            "The requested common gate time is not an integer multiple "
            "of the selected time step."
        )

    T_half = np.exp(
        -1j
        * coeff
        * K2
        * cfg.dt_fs
        / (2.0 * hbar_ev_fs(phys))
    )

    progress_every = max(1, nsteps // 40)

    t0 = time.perf_counter()

    for step in range(1, nsteps + 1):

        # First half kinetic step.
        Psi_k = np.fft.fft2(
            Psi,
            axes=(-2, -1),
        )

        Psi_k *= T_half[None, None, :, :]

        Psi = np.fft.ifft2(
            Psi_k,
            axes=(-2, -1),
        )

        # Local 3x3 layer evolution.
        Psi = np.einsum(
            "ab,sbij->saij",
            Uloc,
            Psi,
            optimize=True,
        )

        # Second half kinetic step.
        Psi_k = np.fft.fft2(
            Psi,
            axes=(-2, -1),
        )

        Psi_k *= T_half[None, None, :, :]

        Psi = np.fft.ifft2(
            Psi_k,
            axes=(-2, -1),
        )

        if progress and (
            step == nsteps or step % progress_every == 0
        ):
            elapsed = time.perf_counter() - t0
            frac = step / nsteps
            eta = elapsed * (1.0 - frac) / frac

            print(
                f"    [{100.0*frac:6.1f}%] "
                f"t={step*cfg.dt_fs:9.2f} fs "
                f"| ETA={eta:8.1f} s",
                flush=True,
            )

    runtime_s = time.perf_counter() - t0

    # -------------------------------------------------------------------------
    # R_mn = Tr_sp[ |Psi_m><Psi_n| ]
    #
    # Shape:
    #     rho_basis[m,n,layer,layer]
    #
    # Notice the explicit cross term m != n.
    # -------------------------------------------------------------------------
    rho_basis = np.einsum(
        "m a i j, n b i j -> m n a b",
        Psi,
        np.conjugate(Psi),
        optimize=True,
    )

    # einsum above treats dx^2 separately.
    rho_basis *= dx * dx

    # Numerical Hermiticity cleanup only at machine precision.
    rho_basis = 0.5 * (
        rho_basis
        + np.conjugate(
            np.swapaxes(
                np.swapaxes(rho_basis, 0, 1),
                2,
                3,
            )
        )
    )

    # -------------------------------------------------------------------------
    # Reconstruct the six input states exactly.
    # -------------------------------------------------------------------------
    labels, coeffs = logical_coefficients()

    # rho_out[s,a,b] = c_m c_n* R_mn[a,b]
    rho_out = np.einsum(
        "sm,sn,mnab->sab",
        coeffs,
        np.conjugate(coeffs),
        rho_basis,
        optimize=True,
    )

    # Logical 2x2 block {|1>,|3>}.
    rho_logical = rho_out[:, [0, 2], :][:, :, [0, 2]]

    # Ideal X target in logical basis: (a,b) -> (b,a).
    target = np.stack(
        [coeffs[:, 1], coeffs[:, 0]],
        axis=1,
    )

    # Leakage-sensitive state fidelity.
    F = np.real(
        np.einsum(
            "sa,sab,sb->s",
            np.conjugate(target),
            rho_logical,
            target,
            optimize=True,
        )
    )

    F = np.clip(F, 0.0, 1.0)

    # Full layer populations for each reconstructed input.
    P1 = np.real(rho_out[:, 0, 0]).astype(float)
    P2 = np.real(rho_out[:, 1, 1]).astype(float)
    P3 = np.real(rho_out[:, 2, 2]).astype(float)

    # Norm of each reconstructed output.
    norms = (
        P1 + P2 + P3
    )

    norm_error_max = float(
        np.max(np.abs(norms - 1.0))
    )

    return {
        "labels": labels,
        "F": F,
        "epsilon": 1.0 - F,
        "P1": P1,
        "P2": P2,
        "P3": P3,
        "rho_basis": rho_basis,
        "rho_out": rho_out,
        "dx_nm": dx,
        "t_numeric_fs": nsteps * cfg.dt_fs,
        "runtime_s": runtime_s,
        "norm_error_max": norm_error_max,
    }


# =============================================================================
# PRODUCTION CSV
# =============================================================================

def default_production_csv() -> Path:
    candidates = [
        (
            Path.home()
            / "resultados_etapa2_portaX_3x3_completa"
            / "portaX_estados_Bloch_3x3_completa.csv"
        ),
        Path.home()
        / "Downloads"
        / "portaX_estados_Bloch_3x3_completa.csv",
        Path.cwd()
        / "portaX_estados_Bloch_3x3_completa.csv",
    ]

    for path in candidates:
        if path.is_file():
            return path

    # Return the canonical first location for a useful error message.
    return candidates[0]


def load_production_csv(path: Path) -> dict[str, object]:
    labels = []
    F = []
    epsilon = []

    with path.open(
        "r",
        encoding="utf-8",
        newline="",
    ) as fh:

        reader = csv.DictReader(fh)

        if reader.fieldnames is None:
            raise ValueError(
                "Production CSV has no header."
            )

        if "F" not in reader.fieldnames:
            raise ValueError(
                "Production CSV does not contain column 'F'."
            )

        for i, row in enumerate(reader):
            labels.append(
                row.get("input", str(i))
            )

            F_i = float(row["F"])

            F.append(F_i)

            if "epsilon" in reader.fieldnames:
                epsilon.append(
                    float(row["epsilon"])
                )
            else:
                epsilon.append(
                    1.0 - F_i
                )

    if len(F) != 6:
        raise ValueError(
            "Expected exactly six production states, "
            f"but found {len(F)}."
        )

    F = np.asarray(F, dtype=float)
    epsilon = np.asarray(epsilon, dtype=float)

    return {
        "labels": labels,
        "F": F,
        "epsilon": epsilon,
        "F_avg": float(np.mean(F)),
        "F_std": float(np.std(F, ddof=0)),
        "F_min": float(np.min(F)),
        "F_max": float(np.max(F)),
    }


# =============================================================================
# OUTPUT HELPERS
# =============================================================================

def save_per_state_csv(
    path: Path,
    rows: list[dict[str, object]],
) -> None:

    keys = [
        "configuration",
        "N",
        "dt_fs",
        "dx_nm",
        "state",
        "F",
        "1_minus_F",
        "P1",
        "P2",
        "P3",
    ]

    with path.open(
        "w",
        newline="",
        encoding="utf-8",
    ) as fh:

        writer = csv.DictWriter(
            fh,
            fieldnames=keys,
        )

        writer.writeheader()
        writer.writerows(rows)


def save_summary_csv(
    path: Path,
    rows: list[dict[str, object]],
) -> None:

    keys = list(rows[0].keys())

    with path.open(
        "w",
        newline="",
        encoding="utf-8",
    ) as fh:

        writer = csv.DictWriter(
            fh,
            fieldnames=keys,
        )

        writer.writeheader()
        writer.writerows(rows)


def save_report(
    path: Path,
    phys: PhysicalParameters,
    summaries: list[dict[str, object]],
    analysis: dict[str, float],
    production_source: str,
) -> None:

    J_signed, tX_theory, tX_prod = gate_times(phys)

    with path.open(
        "w",
        encoding="utf-8",
    ) as fh:

        fh.write(
            "NUMERICAL CONVERGENCE OF THE MEAN X-GATE FIDELITY\n"
        )
        fh.write(
            "FULL 3x3 TRILAYER MODEL — TWO-BASIS EXACT RECONSTRUCTION\n"
        )
        fh.write("=" * 96 + "\n\n")

        fh.write("PHYSICAL PARAMETERS\n")
        fh.write("-" * 96 + "\n")

        fh.write(
            f"Delta12 = {phys.Delta12*1000:.6f} meV\n"
        )
        fh.write(
            f"Delta23 = {phys.Delta23*1000:.6f} meV\n"
        )
        fh.write(
            f"U2 = {phys.U2*1000:.6f} meV\n"
        )
        fh.write(
            f"J_signed = {J_signed*1000:.9f} meV\n"
        )
        fh.write(
            f"tX_theory = {tX_theory:.9f} fs\n"
        )
        fh.write(
            f"tX_common = {tX_prod:.9f} fs\n"
        )
        fh.write(
            f"V0 = {phys.V0*1000:.6f} meV\n"
        )
        fh.write(
            f"Production CSV = {production_source}\n\n"
        )

        fh.write("CONVERGENCE RESULTS\n")
        fh.write("-" * 96 + "\n")

        for row in summaries:
            fh.write(
                f"{row['configuration']}: "
                f"N={row['N']}x{row['N']}, "
                f"dx={row['dx_nm']:.6f} nm, "
                f"dt={row['dt_fs']:.3f} fs, "
                f"F_avg={row['F_avg']:.15f}, "
                f"std={row['F_std']:.6e}\n"
            )

        fh.write("\nFINAL RESULT\n")
        fh.write("-" * 96 + "\n")

        fh.write(
            f"F_avg(production) = "
            f"{analysis['F_production']:.15f}\n"
        )
        fh.write(
            f"F_avg(spatial) = "
            f"{analysis['F_spatial']:.15f}\n"
        )
        fh.write(
            f"F_avg(temporal) = "
            f"{analysis['F_temporal']:.15f}\n"
        )
        fh.write(
            f"F_avg(reference) = "
            f"{analysis['F_reference']:.15f}\n"
        )

        fh.write(
            f"delta_F_spatial = "
            f"{analysis['delta_F_spatial']:.12e}\n"
        )
        fh.write(
            f"delta_F_temporal = "
            f"{analysis['delta_F_temporal']:.12e}\n"
        )
        fh.write(
            f"delta_F_reference = "
            f"{analysis['delta_F_reference']:.12e}\n"
        )
        fh.write(
            f"delta_F_num = "
            f"{analysis['delta_F_num']:.12e}\n"
        )

        fh.write(
            f"1-F_avg(production) = "
            f"{analysis['infidelity_production']:.12e}\n"
        )

        fh.write("\nINTERPRETATION\n")
        fh.write("-" * 96 + "\n")
        fh.write(
            "delta_F_num is a deterministic numerical-convergence "
            "sensitivity estimate.\n"
        )
        fh.write(
            "It is not a statistical uncertainty and is not claimed "
            "as a rigorous truncation-error bound.\n"
        )
        fh.write(
            "The two-basis reduction is exact by linearity of the "
            "Schrodinger evolution; it does not change the physical "
            "3x3 propagation.\n"
        )


def make_plot(
    path: Path,
    summaries: list[dict[str, object]],
    analysis: dict[str, float],
) -> None:

    import matplotlib.pyplot as plt

    prod = summaries[0]
    spatial = summaries[1]
    temporal = summaries[2]
    reference = summaries[3]

    fig, axes = plt.subplots(
        1,
        2,
        figsize=(7.6, 3.3),
    )

    axes[0].plot(
        [
            prod["dx_nm"],
            spatial["dx_nm"],
            reference["dx_nm"],
        ],
        [
            prod["F_avg"],
            spatial["F_avg"],
            reference["F_avg"],
        ],
        "o-",
    )

    axes[0].set_xlabel(r"$\Delta x$ (nm)")
    axes[0].set_ylabel(r"$F_X^{\rm avg}(t_X)$")
    axes[0].invert_xaxis()
    axes[0].tick_params(
        direction="in",
        top=True,
        right=True,
    )
    axes[0].set_title("Spatial refinement")

    axes[1].plot(
        [
            prod["dt_fs"],
            temporal["dt_fs"],
            reference["dt_fs"],
        ],
        [
            prod["F_avg"],
            temporal["F_avg"],
            reference["F_avg"],
        ],
        "o-",
    )

    axes[1].set_xlabel(r"$\Delta t$ (fs)")
    axes[1].set_ylabel(r"$F_X^{\rm avg}(t_X)$")
    axes[1].tick_params(
        direction="in",
        top=True,
        right=True,
    )
    axes[1].set_title("Temporal refinement")

    fig.suptitle(
        rf"$F_X^{{\rm avg}}="
        rf"{analysis['F_production']:.10f}"
        rf"\pm{analysis['delta_F_num']:.1e}$",
        fontsize=10,
    )

    fig.tight_layout()

    fig.savefig(
        path,
        dpi=400,
        bbox_inches="tight",
        transparent=True,
    )

    plt.close(fig)


# =============================================================================
# MAIN
# =============================================================================

def main() -> None:

    parser = argparse.ArgumentParser(
        description=(
            "Numerical convergence of the mean X-gate fidelity "
            "for the full 3x3 trilayer model."
        )
    )

    parser.add_argument(
        "--production-csv",
        type=Path,
        default=None,
        help=(
            "Path to the existing six-state production CSV. "
            "If omitted, the standard location is searched automatically."
        ),
    )

    parser.add_argument(
        "--force-production-simulation",
        action="store_true",
        help=(
            "Recompute the production six-state calculation "
            "instead of reusing the CSV."
        ),
    )

    parser.add_argument(
        "--no-plot",
        action="store_true",
    )

    parser.add_argument(
        "--output",
        type=Path,
        default=Path(
            "convergencia_Favg_X_3x3_otimizada"
        ),
    )

    args = parser.parse_args()

    args.output.mkdir(
        parents=True,
        exist_ok=True,
    )

    phys = PhysicalParameters()

    labels, _ = logical_input_states()
    _, tX_theory, tX_common = gate_times(phys)

    production_cfg = NumericalConfiguration(
        N=384,
        dt_fs=0.5,
    )

    spatial_cfg = NumericalConfiguration(
        N=512,
        dt_fs=0.5,
    )

    temporal_cfg = NumericalConfiguration(
        N=384,
        dt_fs=0.25,
    )

    reference_cfg = NumericalConfiguration(
        N=512,
        dt_fs=0.25,
    )

    print()
    print("=" * 112)
    print("MEAN X-GATE FIDELITY CONVERGENCE — FULL 3x3 HAMILTONIAN")
    print("EXACT TWO-BASIS RECONSTRUCTION OF THE SIX BLOCH INPUTS")
    print("=" * 112)

    print(
        "Input states          = "
        + ", ".join(labels)
    )

    print(
        f"tX theoretical        = {tX_theory:.9f} fs"
    )

    print(
        f"tX common comparison  = {tX_common:.3f} fs"
    )

    print(
        f"Production            = "
        f"{production_cfg.N}x{production_cfg.N}, "
        f"dx={production_cfg.W_nm/production_cfg.N:.6f} nm, "
        f"dt={production_cfg.dt_fs:.3f} fs"
    )

    print(
        f"Spatial refinement    = "
        f"{spatial_cfg.N}x{spatial_cfg.N}, "
        f"dx={spatial_cfg.W_nm/spatial_cfg.N:.6f} nm, "
        f"dt={spatial_cfg.dt_fs:.3f} fs"
    )

    print(
        f"Temporal refinement   = "
        f"{temporal_cfg.N}x{temporal_cfg.N}, "
        f"dx={temporal_cfg.W_nm/temporal_cfg.N:.6f} nm, "
        f"dt={temporal_cfg.dt_fs:.3f} fs"
    )

    print(
        f"Combined reference    = "
        f"{reference_cfg.N}x{reference_cfg.N}, "
        f"dx={reference_cfg.W_nm/reference_cfg.N:.6f} nm, "
        f"dt={reference_cfg.dt_fs:.3f} fs"
    )

    print(
        "V0                    = 0 meV"
    )

    print("=" * 112)

    # -------------------------------------------------------------------------
    # Reuse production six-state data.
    # -------------------------------------------------------------------------
    csv_path = (
        args.production_csv
        if args.production_csv is not None
        else default_production_csv()
    )

    if (
        not args.force_production_simulation
        and csv_path.is_file()
    ):
        production = load_production_csv(csv_path)
        production_source = str(csv_path)

        print()
        print(
            "REUSING EXISTING PRODUCTION CSV:"
        )
        print(
            f"  {csv_path}"
        )

    else:
        raise FileNotFoundError(
            "\nProduction CSV was not found.\n"
            "The optimized calculation is deliberately configured not "
            "to rerun the six-state production case automatically.\n\n"
            "Expected file:\n"
            f"  {csv_path}\n\n"
            "Use --production-csv /path/to/portaX_estados_Bloch_3x3_completa.csv\n"
            "to specify it explicitly.\n"
        )

    # -------------------------------------------------------------------------
    # Summary table starts with the already completed production result.
    # -------------------------------------------------------------------------
    summaries: list[dict[str, object]] = [
        {
            "configuration": "production",
            "N": production_cfg.N,
            "dt_fs": production_cfg.dt_fs,
            "dx_nm": production_cfg.W_nm / production_cfg.N,
            "W_nm": production_cfg.W_nm,
            "t_numeric_fs": tX_common,
            "F_avg": production["F_avg"],
            "F_std": production["F_std"],
            "F_min": production["F_min"],
            "F_max": production["F_max"],
            "runtime_s": np.nan,
            "norm_error_max": np.nan,
        }
    ]

    per_state_rows: list[dict[str, object]] = []

    for state, F, eps in zip(
        production["labels"],
        production["F"],
        production["epsilon"],
    ):
        per_state_rows.append(
            {
                "configuration": "production",
                "N": production_cfg.N,
                "dt_fs": production_cfg.dt_fs,
                "dx_nm": production_cfg.W_nm / production_cfg.N,
                "state": state,
                "F": float(F),
                "1_minus_F": float(eps),
                "P1": np.nan,
                "P2": np.nan,
                "P3": np.nan,
            }
        )

    # -------------------------------------------------------------------------
    # Three refined calculations.
    # -------------------------------------------------------------------------
    refinement_specs = [
        ("spatial_refinement", spatial_cfg),
        ("temporal_refinement", temporal_cfg),
        ("combined_reference", reference_cfg),
    ]

    for name, cfg in refinement_specs:

        print()
        print("-" * 112)
        print(
            f"RUNNING {name.upper()} "
            f"— TWO BASIS STATES: "
            f"{cfg.N}x{cfg.N}, dt={cfg.dt_fs:.3f} fs"
        )
        print("-" * 112)

        result = propagate_two_basis_states(
            phys,
            cfg,
            tX_common,
            progress=True,
        )

        F = np.asarray(
            result["F"],
            dtype=float,
        )

        summary = {
            "configuration": name,
            "N": cfg.N,
            "dt_fs": cfg.dt_fs,
            "dx_nm": cfg.W_nm / cfg.N,
            "W_nm": cfg.W_nm,
            "t_numeric_fs": result["t_numeric_fs"],
            "F_avg": float(np.mean(F)),
            "F_std": float(np.std(F, ddof=0)),
            "F_min": float(np.min(F)),
            "F_max": float(np.max(F)),
            "runtime_s": result["runtime_s"],
            "norm_error_max": result["norm_error_max"],
        }

        summaries.append(summary)

        for state, f_i, eps_i, p1, p2, p3 in zip(
            result["labels"],
            result["F"],
            result["epsilon"],
            result["P1"],
            result["P2"],
            result["P3"],
        ):
            per_state_rows.append(
                {
                    "configuration": name,
                    "N": cfg.N,
                    "dt_fs": cfg.dt_fs,
                    "dx_nm": cfg.W_nm / cfg.N,
                    "state": state,
                    "F": float(f_i),
                    "1_minus_F": float(eps_i),
                    "P1": float(p1),
                    "P2": float(p2),
                    "P3": float(p3),
                }
            )

        print(
            f"\n  F_avg = {summary['F_avg']:.15f}"
        )
        print(
            f"  std   = {summary['F_std']:.3e}"
        )
        print(
            f"  min   = {summary['F_min']:.15f}"
        )
        print(
            f"  max   = {summary['F_max']:.15f}"
        )
        print(
            f"  max norm error = "
            f"{summary['norm_error_max']:.3e}"
        )
        print(
            f"  runtime = {summary['runtime_s'] / 60.0:.2f} min"
        )

    # -------------------------------------------------------------------------
    # Final convergence analysis.
    # -------------------------------------------------------------------------
    F_prod = float(summaries[0]["F_avg"])
    F_spatial = float(summaries[1]["F_avg"])
    F_temporal = float(summaries[2]["F_avg"])
    F_reference = float(summaries[3]["F_avg"])

    delta_spatial = abs(
        F_prod - F_spatial
    )

    delta_temporal = abs(
        F_prod - F_temporal
    )

    delta_reference = abs(
        F_prod - F_reference
    )

    delta_num = max(
        delta_spatial,
        delta_temporal,
        delta_reference,
    )

    analysis = {
        "F_production": F_prod,
        "F_spatial": F_spatial,
        "F_temporal": F_temporal,
        "F_reference": F_reference,
        "delta_F_spatial": delta_spatial,
        "delta_F_temporal": delta_temporal,
        "delta_F_reference": delta_reference,
        "delta_F_num": delta_num,
        "infidelity_production": 1.0 - F_prod,
    }

    save_per_state_csv(
        args.output
        / "mean_fidelity_per_state_optimized.csv",
        per_state_rows,
    )

    save_summary_csv(
        args.output
        / "mean_fidelity_convergence_summary_optimized.csv",
        summaries,
    )

    save_report(
        args.output
        / "mean_fidelity_convergence_report_optimized.txt",
        phys,
        summaries,
        analysis,
        production_source,
    )

    if not args.no_plot:
        make_plot(
            args.output
            / "mean_fidelity_convergence_optimized.pdf",
            summaries,
            analysis,
        )

    print()
    print("=" * 112)
    print("FINAL RESULT FOR THE MANUSCRIPT")
    print("=" * 112)

    print(
        f"F_X^avg(production) = "
        f"{F_prod:.15f}"
    )

    print(
        f"Numerical error bar = "
        f"{delta_num:.12e}"
    )

    print(
        f"F_X^avg = "
        f"{F_prod:.15f} +/- "
        f"{delta_num:.2e}"
    )

    print(
        f"1 - F_X^avg = "
        f"{1.0 - F_prod:.12e}"
    )

    print(
        f"delta spatial      = "
        f"{delta_spatial:.12e}"
    )

    print(
        f"delta temporal     = "
        f"{delta_temporal:.12e}"
    )

    print(
        f"delta reference    = "
        f"{delta_reference:.12e}"
    )

    print()
    print(
        "NOTE: delta_F_num is a deterministic numerical-convergence "
        "estimate, not a statistical uncertainty."
    )
    print("=" * 112)


if __name__ == "__main__":
    main()
