#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
FIGURE 04 — X-gate robustness against outer-layer energy detuning
===================================================================

PURPOSE
-------
This script reproduces the publication figure corresponding to Fig. 4
of the manuscript:

    "A minimal model for coherent dynamics, dephasing and coherence
     revival: effective trilayer 2DEG qubits"

The figure quantifies the robustness of the logical Pauli-X operation
against a static energy imbalance between the two outer layers,

    delta U = U1 - U3,

and compares the result obtained from:

    (a) the complete 3x3 trilayer Hamiltonian;
    (b) the effective 2x2 logical Hamiltonian.

The gate fidelity is evaluated at the nominal resonant X-gate time,

    t_X = pi * hbar / (2 |J|),

with

    J = - Delta12 * Delta23 / U2.

FIGURE LAYOUT
-------------
The publication figure uses two vertically stacked panels:

    (a) F_X(t_X) versus the physical detuning delta U (meV);
    (b) F_X(t_X) versus the dimensionless detuning
        delta U / (2 |J|).

The figure is intentionally wider than it is tall, with panel (a)
above panel (b). The graphical style is matched to the manuscript:

    - full three-layer model: Matplotlib tab:blue;
    - effective two-level model: Matplotlib tab:orange, dashed;
    - black dotted vertical reference line at zero detuning;
    - serif / Computer Modern typography;
    - inward ticks on all four sides;
    - panel labels "(a)" and "(b)";
    - explicit legends in both panels;
    - x-axis tick labels formatted with one decimal place;
    - y-axis tick labels formatted with two decimal places.

NUMERICAL MODEL
---------------
The full Hamiltonian is

        [ U1       Delta12      0     ]
    H = [ Delta12   U2       Delta23   ],
        [ 0        Delta23      U3     ],

with

    U1 = delta U / 2,
    U3 = -delta U / 2.

The effective logical Hamiltonian is

        [ delta U/2      J       ]
    Heff = [                ],
        [      J       -delta U/2 ].

The initial state is |0> = |1>, and the X-gate fidelity is the
population in the target logical state |1> = |3>.

OUTPUT
------
The script writes, in a local results directory:

    fig04_x_gate_detuning_robustness.pdf
    fig04_x_gate_detuning_robustness.png
    fig04_x_gate_detuning_robustness.dat

ROLE IN THE REPRODUCTION CHAIN
------------------------------
This is a self-contained publication-figure script. It performs the
detuning sweep, computes both the complete and effective-model
fidelities, checks unitarity, saves the numerical data, and generates
the publication-ready figure.

IMPORTANT
---------
The code below preserves the physical calculation used for the
manuscript. The modifications relative to the previous version are
restricted to figure naming, layout, typography, tick formatting,
panel arrangement, colors, legends, and publication styling.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import time

import numpy as np
import matplotlib

# Non-interactive backend for reproducible publication-figure generation.
matplotlib.use("Agg")

import matplotlib.pyplot as plt
from matplotlib.ticker import FormatStrFormatter


# =============================================================================
# PHYSICS
# =============================================================================

@dataclass(frozen=True)
class PhysicalParameters:
    """Physical parameters used in the Fig. 4 detuning sweep."""

    hbar_meV_fs: float = 658.211928
    Delta12_meV: float = 5.0
    Delta23_meV: float = 5.0
    U2_meV: float = 100.0


@dataclass(frozen=True)
class SweepParameters:
    """Numerical parameters for the outer-layer detuning sweep."""

    deltaU_min_meV: float = -1.0
    deltaU_max_meV: float = 1.0
    n_points: int = 21
    dt_fs: float = 0.5


@dataclass(frozen=True)
class FigureStyle:
    """Publication-style parameters for Fig. 4."""

    # Matplotlib default publication colors used by the manuscript-like plot.
    full: str = "#1f77b4"       # tab:blue
    effective: str = "#ff7f0e"  # tab:orange

    lw_main: float = 1.6
    panel_label_fontsize: float = 13.0
    axis_label_fontsize: int = 16
    tick_fontsize: int = 13
    legend_fontsize: float = 11.5


# =============================================================================
# MATPLOTLIB STYLE
# =============================================================================

def configure_matplotlib() -> None:
    """Configure typography and axes to match the publication figures."""

    plt.rcParams.update(
        {
            "text.usetex": True,
            "font.family": "serif",
            "font.serif": ["Computer Modern Roman"],
            "text.latex.preamble": r"\usepackage{amsmath}",

            "text.color": "black",
            "axes.labelcolor": "black",
            "axes.edgecolor": "black",
            "xtick.color": "black",
            "ytick.color": "black",

            "font.size": 15,
            "axes.labelsize": 24,
            "axes.titlesize": 24,
            "legend.fontsize": 16.5,
            "xtick.labelsize": 16,
            "ytick.labelsize": 16,

            "axes.linewidth": 0.75,

            "xtick.major.size": 5,
            "ytick.major.size": 5,
            "xtick.major.width": 0.75,
            "ytick.major.width": 0.75,

            "xtick.minor.visible": True,
            "ytick.minor.visible": True,
            "xtick.minor.size": 2.5,
            "ytick.minor.size": 2.5,
            "xtick.minor.width": 0.55,
            "ytick.minor.width": 0.55,

            "figure.dpi": 300,
            "savefig.dpi": 450,
        }
    )


def polish_axes(ax) -> None:
    """Apply the common publication-axis formatting."""

    ax.tick_params(
        which="major",
        direction="in",
        top=True,
        right=True,
        length=5,
        width=0.75,
    )

    ax.tick_params(
        which="minor",
        direction="in",
        top=True,
        right=True,
        length=2.5,
        width=0.55,
    )

    ax.grid(
        True,
        which="major",
        alpha=0.22,
        linewidth=0.55,
    )

    ax.grid(
        True,
        which="minor",
        alpha=0.10,
        linewidth=0.40,
    )


# =============================================================================
# HAMILTONIANS / PROPAGATORS
# =============================================================================

def effective_coupling(
    phys: PhysicalParameters,
) -> tuple[float, float]:
    """
    Return the signed and absolute effective coupling.

    J = -Delta12 * Delta23 / U2
    """

    J_signed = -(
        phys.Delta12_meV * phys.Delta23_meV
    ) / phys.U2_meV

    J_abs = abs(J_signed)

    return J_signed, J_abs


def hamiltonian_full_3x3(
    deltaU_meV: float,
    phys: PhysicalParameters,
) -> np.ndarray:
    """Construct the complete 3x3 trilayer Hamiltonian."""

    U1 = 0.5 * deltaU_meV
    U3 = -0.5 * deltaU_meV

    return np.array(
        [
            [U1, phys.Delta12_meV, 0.0],
            [phys.Delta12_meV, phys.U2_meV, phys.Delta23_meV],
            [0.0, phys.Delta23_meV, U3],
        ],
        dtype=np.complex128,
    )


def hamiltonian_effective_2x2(
    deltaU_meV: float,
    J_signed: float,
) -> np.ndarray:
    """Construct the effective 2x2 logical Hamiltonian."""

    return np.array(
        [
            [0.5 * deltaU_meV, J_signed],
            [J_signed, -0.5 * deltaU_meV],
        ],
        dtype=np.complex128,
    )


def unitary_from_hermitian(
    H: np.ndarray,
    t_fs: float,
    hbar_meV_fs: float,
) -> np.ndarray:
    """
    Construct exp(-i H t / hbar) using the Hermitian eigendecomposition.
    """

    evals, evecs = np.linalg.eigh(H)
    phase = np.exp(-1j * evals * t_fs / hbar_meV_fs)

    return (evecs * phase) @ evecs.conj().T


def fidelity_x_from_state(state: np.ndarray) -> float:
    """
    Return the population of the target state |3>.

    For the 3x3 model, this is the third component.
    For the 2x2 model, this is the second logical component.
    """

    return float(np.abs(state[-1]) ** 2)


# =============================================================================
# MAIN CALCULATION
# =============================================================================

def run_sweep(
    phys: PhysicalParameters,
    sweep: SweepParameters,
) -> dict:
    """Run the complete and effective-model detuning sweep."""

    J_signed, J_abs = effective_coupling(phys)

    # Ideal resonant X-gate time.
    t_X_fs = (
        np.pi
        * phys.hbar_meV_fs
        / (2.0 * J_abs)
    )

    # Full-model propagation is evaluated on the chosen temporal grid.
    t_gate_num_fs = (
        round(t_X_fs / sweep.dt_fs)
        * sweep.dt_fs
    )

    omega_eff_fs = (
        2.0 * J_abs / phys.hbar_meV_fs
    )

    deltaU = np.linspace(
        sweep.deltaU_min_meV,
        sweep.deltaU_max_meV,
        sweep.n_points,
    )

    FX_full = np.empty_like(deltaU)
    FX_eff = np.empty_like(deltaU)

    unitary_err_full = np.empty_like(deltaU)
    unitary_err_eff = np.empty_like(deltaU)

    # Logical input |0> = |1>.
    psi0_full = np.array(
        [1.0, 0.0, 0.0],
        dtype=np.complex128,
    )

    psi0_eff = np.array(
        [1.0, 0.0],
        dtype=np.complex128,
    )

    for i, dU in enumerate(deltaU):

        # ---------------------------------------------------------------------
        # Complete 3x3 model
        # ---------------------------------------------------------------------
        H3 = hamiltonian_full_3x3(
            dU,
            phys,
        )

        U3 = unitary_from_hermitian(
            H3,
            t_gate_num_fs,
            phys.hbar_meV_fs,
        )

        psi3 = U3 @ psi0_full

        FX_full[i] = fidelity_x_from_state(psi3)

        unitary_err_full[i] = np.max(
            np.abs(
                U3.conj().T @ U3 - np.eye(3)
            )
        )

        # ---------------------------------------------------------------------
        # Effective 2x2 model
        # ---------------------------------------------------------------------
        H2 = hamiltonian_effective_2x2(
            dU,
            J_signed,
        )

        U2 = unitary_from_hermitian(
            H2,
            t_X_fs,
            phys.hbar_meV_fs,
        )

        psi2 = U2 @ psi0_eff

        FX_eff[i] = fidelity_x_from_state(psi2)

        unitary_err_eff[i] = np.max(
            np.abs(
                U2.conj().T @ U2 - np.eye(2)
            )
        )

    return {
        "deltaU_meV": deltaU,
        "eta": deltaU / (2.0 * J_abs),
        "FX_full": FX_full,
        "FX_eff": FX_eff,
        "J_signed": J_signed,
        "J_abs": J_abs,
        "omega_eff_fs": omega_eff_fs,
        "t_X_fs": t_X_fs,
        "t_gate_num_fs": t_gate_num_fs,
        "dt_fs": sweep.dt_fs,
        "max_unitary_err_full": float(
            np.max(unitary_err_full)
        ),
        "max_unitary_err_eff": float(
            np.max(unitary_err_eff)
        ),
    }


# =============================================================================
# FIGURE 04
# =============================================================================

def make_figure(
    results: dict,
    outdir: Path,
    style: FigureStyle,
) -> Path:
    """
    Generate Fig. 4 in the manuscript-style layout.

    Panel (a):
        F_X(t_X) versus delta U.

    Panel (b):
        F_X(t_X) versus delta U/(2|J|).

    The panels are stacked vertically, and the overall figure is wider
    than it is tall, as requested for the publication layout.
    """

    deltaU = results["deltaU_meV"]
    eta = results["eta"]

    full = results["FX_full"]
    eff = results["FX_eff"]

    # -------------------------------------------------------------------------
    # Publication geometry: panel (a) above panel (b).
    # The figure is deliberately wider than it is tall.
    # -------------------------------------------------------------------------
    fig, axs = plt.subplots(
        2,
        1,
        figsize=(5.8, 5.5),
        dpi=300,
        sharey=True,
    )

    fig.patch.set_alpha(0.0)

    # =========================================================================
    # PANEL (a) — physical detuning
    # =========================================================================
    ax = axs[0]

    ax.plot(
        deltaU,
        full,
        color=style.full,
        lw=style.lw_main,
        linestyle="-",
        label=r"Full three-layer model",
    )

    ax.plot(
        deltaU,
        eff,
        color=style.effective,
        lw=style.lw_main,
        linestyle="--",
        label=r"Effective two-level model",
    )

    ax.axvline(
        0.0,
        color="black",
        lw=0.8,
        linestyle=":",
        alpha=0.65,
    )

    ax.set_xlim(-1.0, 1.0)
    ax.set_ylim(-0.02, 1.02)

    # Exact tick positions and formatting used in the manuscript.
    ax.set_xticks(
        [-1.0, -0.5, 0.0, 0.5, 1.0]
    )
    ax.set_yticks(
        [0.0, 0.2, 0.4, 0.6, 0.8, 1.0]
    )

    ax.xaxis.set_major_formatter(
        FormatStrFormatter("%.1f")
    )
    ax.yaxis.set_major_formatter(
        FormatStrFormatter("%.2f")
    )

    ax.set_xlabel(
        r"$\delta U=U_1-U_3$ (meV)",
        fontsize=style.axis_label_fontsize,
    )

    ax.set_ylabel(
        r"$F_X(t_X)$",
        fontsize=style.axis_label_fontsize,
    )

    ax.text(
        0.025,
        0.94,
        "(a)",
        transform=ax.transAxes,
        fontsize=style.panel_label_fontsize,
        va="top",
        ha="left",
    )

    # Keep the complete legend explicit, as in the paper.
    ax.legend(
        loc="lower center",
        bbox_to_anchor=(0.50, 0.02),
        ncol=1,
        frameon=False,
        fontsize=style.legend_fontsize,
        handlelength=2.3,
        borderaxespad=0.0,
    )

    polish_axes(ax)

    # =========================================================================
    # PANEL (b) — dimensionless detuning
    # =========================================================================
    ax = axs[1]

    ax.plot(
        eta,
        full,
        color=style.full,
        lw=style.lw_main,
        linestyle="-",
        label=r"Full three-layer model",
    )

    ax.plot(
        eta,
        eff,
        color=style.effective,
        lw=style.lw_main,
        linestyle="--",
        label=r"Effective two-level model",
    )

    ax.axvline(
        0.0,
        color="black",
        lw=0.8,
        linestyle=":",
        alpha=0.65,
    )

    ax.set_xlim(-2.0, 2.0)
    ax.set_ylim(-0.02, 1.02)

    ax.set_xticks(
        [-2.0, -1.0, 0.0, 1.0, 2.0]
    )
    ax.set_yticks(
        [0.0, 0.2, 0.4, 0.6, 0.8, 1.0]
    )

    ax.xaxis.set_major_formatter(
        FormatStrFormatter("%.1f")
    )
    ax.yaxis.set_major_formatter(
        FormatStrFormatter("%.2f")
    )

    # Match the manuscript's dimensionless variable.
    ax.set_xlabel(
        r"$\delta U/(2|J|)$",
        fontsize=style.axis_label_fontsize,
    )

    ax.set_ylabel(
        r"$F_X(t_X)$",
        fontsize=style.axis_label_fontsize,
    )

    ax.text(
        0.025,
        0.94,
        "(b)",
        transform=ax.transAxes,
        fontsize=style.panel_label_fontsize,
        va="top",
        ha="left",
    )

    ax.legend(
        loc="lower center",
        bbox_to_anchor=(0.50, 0.02),
        ncol=1,
        frameon=False,
        fontsize=style.legend_fontsize,
        handlelength=2.3,
        borderaxespad=0.0,
    )

    polish_axes(ax)

    # -------------------------------------------------------------------------
    # Final geometry and output
    # -------------------------------------------------------------------------
    fig.subplots_adjust(
        left=0.14,
        right=0.985,
        bottom=0.105,
        top=0.985,
        hspace=0.48,
    )

    outfile = (
        outdir
        / "fig04_x_gate_detuning_robustness.pdf"
    )

    fig.savefig(
        outfile,
        format="pdf",
        bbox_inches="tight",
        pad_inches=0.02,
    )

    fig.savefig(
        outfile.with_suffix(".png"),
        format="png",
        dpi=450,
        bbox_inches="tight",
        pad_inches=0.02,
    )

    plt.close(fig)

    return outfile


# =============================================================================
# SAVE DATA / REPORT
# =============================================================================

def save_results(
    results: dict,
    outdir: Path,
) -> None:
    """Save the sweep data used to construct Fig. 4."""

    table = np.column_stack(
        [
            results["deltaU_meV"],
            results["eta"],
            results["FX_full"],
            results["FX_eff"],
        ]
    )

    np.savetxt(
        outdir / "fig04_x_gate_detuning_robustness.dat",
        table,
        header=(
            "deltaU_meV "
            "deltaU_over_2absJ "
            "FX_full_3x3 "
            "FX_effective_2x2"
        ),
    )


# =============================================================================
# MAIN
# =============================================================================

def main() -> None:
    """Run the complete Fig. 4 reproduction chain."""

    configure_matplotlib()

    phys = PhysicalParameters()
    sweep = SweepParameters()
    style = FigureStyle()

    outdir = (
        Path(__file__).resolve().parent
        / "fig04_x_gate_detuning_robustness_results"
    )

    outdir.mkdir(
        parents=True,
        exist_ok=True,
    )

    J_signed, J_abs = effective_coupling(phys)

    t_X_fs = (
        np.pi
        * phys.hbar_meV_fs
        / (2.0 * J_abs)
    )

    print("=" * 88)
    print("FIGURE 04 — X-GATE DETUNING ROBUSTNESS")
    print("=" * 88)

    print(
        f"Delta12              : "
        f"{phys.Delta12_meV:.6f} meV"
    )

    print(
        f"Delta23              : "
        f"{phys.Delta23_meV:.6f} meV"
    )

    print(
        f"U2                   : "
        f"{phys.U2_meV:.6f} meV"
    )

    print(
        f"J_signed             : "
        f"{J_signed:.12f} meV"
    )

    print(
        f"|J|                  : "
        f"{J_abs:.12f} meV"
    )

    print(
        f"Omega_eff            : "
        f"{2 * J_abs / phys.hbar_meV_fs:.12e} fs^-1"
    )

    t_gate_num_fs_report = (
        round(t_X_fs / sweep.dt_fs)
        * sweep.dt_fs
    )

    print(
        f"t_X (ideal)          : "
        f"{t_X_fs:.12f} fs"
    )

    print(
        f"t_X (numerical grid) : "
        f"{t_gate_num_fs_report:.12f} fs"
    )

    print(
        f"dt                   : "
        f"{sweep.dt_fs:.3f} fs"
    )

    print(
        f"deltaU range         : "
        f"[{sweep.deltaU_min_meV:.3f}, "
        f"{sweep.deltaU_max_meV:.3f}] meV"
    )

    print(
        f"number of points     : "
        f"{sweep.n_points}"
    )

    print("-")

    tic = time.time()

    results = run_sweep(
        phys,
        sweep,
    )

    t_gate_num_fs = results[
        "t_gate_num_fs"
    ]

    elapsed = time.time() - tic

    i0 = int(
        np.argmin(
            np.abs(
                results["deltaU_meV"]
            )
        )
    )

    max_diff = float(
        np.max(
            np.abs(
                results["FX_full"]
                - results["FX_eff"]
            )
        )
    )

    print(
        f"F_X full at deltaU=0: "
        f"{results['FX_full'][i0]:.10f}"
    )

    print(
        f"numerical gate time : "
        f"{t_gate_num_fs:.6f} fs"
    )

    print(
        f"F_X eff  at deltaU=0: "
        f"{results['FX_eff'][i0]:.10f}"
    )

    print(
        f"max |F_full-F_eff|  : "
        f"{max_diff:.6e}"
    )

    print(
        f"max unitarity err 3x3: "
        f"{results['max_unitary_err_full']:.3e}"
    )

    print(
        f"max unitarity err 2x2: "
        f"{results['max_unitary_err_eff']:.3e}"
    )

    print(
        f"runtime              : "
        f"{elapsed:.3f} s"
    )

    save_results(
        results,
        outdir,
    )

    figpath = make_figure(
        results,
        outdir,
        style,
    )

    center_ok = (
        abs(
            results["FX_full"][i0]
            - 0.999932805866
        )
        < 2.0e-9
    )

    unitary_ok = (
        results["max_unitary_err_full"]
        < 1e-12
        and
        results["max_unitary_err_eff"]
        < 1e-12
    )

    finite_ok = (
        np.all(
            np.isfinite(
                results["FX_full"]
            )
        )
        and
        np.all(
            np.isfinite(
                results["FX_eff"]
            )
        )
    )

    print("-" * 88)

    print(
        "benchmark resonante     : "
        + ("PASS" if center_ok else "CHECK")
    )

    print(
        "unitariedade            : "
        + ("PASS" if unitary_ok else "FAIL")
    )

    print(
        "dados finitos           : "
        + ("PASS" if finite_ok else "FAIL")
    )

    print("=" * 88)

    overall_ok = (
        center_ok
        and unitary_ok
        and finite_ok
    )

    print(
        "FIGURE 04 — X-GATE DETUNING ROBUSTNESS: "
        + ("PASS" if overall_ok else "CHECK")
    )

    print(
        f"Figure: {figpath}"
    )


if __name__ == "__main__":
    main()
