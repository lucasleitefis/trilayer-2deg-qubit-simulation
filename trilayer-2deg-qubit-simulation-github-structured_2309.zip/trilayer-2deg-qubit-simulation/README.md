# trilayer-2deg-qubit-simulation

Reproducibility package for the paper:

> **A minimal model for coherent dynamics, dephasing and coherence revival: effective trilayer 2DEG qubits**

This repository contains the numerical codes, validation routines, figures, and supporting data used for the simulations presented in the manuscript.

## Overview

The project studies a minimal trilayer two-dimensional electron gas (2DEG) model in which the two outer layers form the logical qubit subspace and the central layer acts as an off-resonant auxiliary state.

In the large-detuning regime, virtual transitions through the intermediate layer generate an effective interlayer coupling. The numerical calculations compare the complete three-layer dynamics with the corresponding effective two-level description.

The repository also contains the calculations associated with the spatially dependent perturbation, reduced layer density matrix, interlayer coherence, purity, phase-dispersion reference, and coherence-revival analysis.

The simulations are deterministic and use a closed, globally unitary wave-packet evolution. The apparent loss of coherence discussed in the manuscript arises from correlations between the layer and spatial degrees of freedom in the reduced layer description.

The public release uses the frozen parameter set of the revised manuscript; historical auxiliary scripts with different numerical parameters are retained only for archival purposes.

## Main physical model

The trilayer Hamiltonian is

\begin{equation}
H =
\begin{pmatrix}
U_1 & \Delta_{12} & \Delta_{13} \\
\Delta_{12} & U_2 & \Delta_{23} \\
\Delta_{13} & \Delta_{23} & U_3
\end{pmatrix}.
\end{equation}

For the reference simulations,

- \(\Delta_{12}=\Delta_{23}=5\,\mathrm{meV}\),
- \(\Delta_{13}=0\),
- \(U_1=U_3=0\),
- \(U_2=100\,\mathrm{meV}\),
- \(U_2/\Delta=20\).

The effective outer-layer coupling is

\begin{equation}
|J|=\frac{\Delta^2}{U_2}=0.25\,\mathrm{meV}.
\end{equation}

The logical basis is

\begin{equation}
|0\rangle\equiv |1\rangle,
\qquad
|1\rangle\equiv |3\rangle.
\end{equation}

For the numerical simulations of the spatially extended system, the reference parameters are

- effective mass: \(m^*=0.067m_e\),
- spatial grid: \(384\times384\),
- simulation domain: \(1200\times1200\,\mathrm{nm}^2\),
- spatial resolution: \(3.125\,\mathrm{nm}\),
- initial wave-packet width: \(\sigma=15\,\mathrm{nm}\),
- initial momentum: \(k_0=0\),
- time step: \(0.5\,\mathrm{fs}\),
- simulation window: \(20\,\mathrm{ps}\),
- perturbation center: \(x_0=40\,\mathrm{nm}\),
- perturbation width: \(w=10\,\mathrm{nm}\).
- perturbation amplitude: \(V_0=5\,\mathrm{meV}\).

## Numerical methods

The numerical propagation is based on split-operator / split-step Fourier methods for the spatial dynamics, together with direct treatment of the layer Hamiltonian.

The repository separates:

1. the complete \(3\times3\) trilayer dynamics;
2. effective two-level calculations used as analytical/numerical references;
3. spatially perturbed dynamics;
4. reduced-density-matrix and tomography calculations;
5. convergence and independent numerical validation.

The effective two-level model is used as a reference description and does not replace the physical three-layer simulation.

## Repository structure

```text
trilayer-2deg-qubit-simulation/
├── simulations/
│   ├── core/
│   ├── coherent/
│   ├── perturbation/
│   └── tomography/
├── figures/
│   ├── fig02_coherent_dynamics/
│   ├── fig04_x_gate_detuning/
│   ├── fig05_effective_model/
│   ├── fig06-07_universal_control/
│   ├── fig08_perturbation/
│   ├── fig09_coherence/
│   ├── fig10_dephasing/
│   └── fig11_tomography/
├── validation/
├── data/
├── archive/
│   └── historical_versions/
├── .gitignore
└── README.md
```

The `archive/historical_versions/` directory is intended for development or historical scripts and is not required for reproducing the main manuscript results.

## Manuscript figures

The public release is organized around the figures of the revised manuscript.

### Fig. 1 — Schematic representation of the trilayer two-dimensional electron gas (2DEG)

Illustration of the three-layer structure and the layer degrees of freedom.

### Fig. 2 — Layer-population dynamics of the trilayer 2DEG in the large-detuning regime

Comparison of the complete three-layer dynamics with the effective two-level description, including the occupation of the intermediate layer.

### Fig. 3 — State tomography and Bloch-sphere representation of the coherent evolution of the effective layer-pseudospin qubit at five representative times

Tomographic representation of the coherent logical-state evolution.

### Fig. 4 — Fidelity of the X operation as a function of the static interlayer energy imbalance \(\delta U=U_1-U_3\)

Sensitivity of the \(X\)-operation to an outer-layer detuning.

### Fig. 5 — Dependence of the coherent dynamics on the dimensionless detuning parameter \(\epsilon=U_2/\Delta\)

Parameter dependence of the effective description in the large-detuning regime.

### Fig. 6 — Bloch-sphere trajectory of the layer-pseudospin state during the \(Z\)--\(X\)--\(Z\) control sequence

Illustrative sequence using the two available noncommuting control axes.

### Fig. 7 — Control parameters for the \(Z\)--\(X\)--\(Z\) sequence

Corresponding time-dependent effective coupling and outer-layer imbalance.

### Fig. 8 — Dependence of the reduced layer dynamics on the dimensionless spatial-inhomogeneity strength \(\eta=V_0/(2|J|)\)

Systematic perturbation-strength sweep, including population transfer, coherence, purity, and \(X\)-operation fidelity.

### Fig. 9 — Comparison between the complete reduced interlayer coherence and the analytical phase-dispersion reference for the spatially perturbed effective qubit

Comparison between the complete spatial dynamics and the local-frequency phase-dispersion reference.

### Fig. 10 — Dynamics of the reduced layer-pseudospin qubit under a spatially dependent perturbation

Reduced populations, coherence, and purity in the presence of the spatial perturbation.

### Fig. 11 — State tomography and Bloch-sphere representation of the effective layer-pseudospin qubit under a spatially dependent perturbation at five representative times

Tomographic visualization of the reduced state during the perturbed evolution.

## Validation

The `validation/` directory contains numerical checks associated with the manuscript, including:

- spatial and temporal convergence tests;
- fidelity sensitivity to numerical refinement;
- comparison of independent implementations of the local layer propagator;
- checks of the reduced-state observables.

For the benchmark \(X\)-operation, the complete three-layer calculation gives

\begin{equation}
F_X(t_X)=0.9999328.
\end{equation}

The reported numerical sensitivity is

\begin{equation}
\delta F_X^{\mathrm{num}}=5.9\times10^{-12},
\end{equation}

obtained from deterministic numerical refinements. This quantity is a numerical sensitivity measure, not a statistical uncertainty.

## Reduced-state analysis

The reduced layer state is obtained by tracing out the spatial degrees of freedom,

\begin{equation}
\rho_{\mathrm{layer}}(t)
=
\operatorname{Tr}_{\mathrm{spatial}}
\left[
|\Psi(t)\rangle\langle\Psi(t)|
\right].
\end{equation}

The principal reduced-state observables are:

- interlayer coherence \( |\rho_{13}| \);
- purity \( \mathrm{Tr}(\rho_{\mathrm{layer}}^2) \);
- layer populations;
- Bloch-vector components;
- state tomography.

The spatially dependent perturbation generates layer--spatial correlations. Consequently, the reduced layer state can lose coherence and purity even though the complete wave packet evolves unitarily.

Partial revivals are interpreted as reversible redistribution of phase information within the closed system rather than as irreversible dissipation caused by an external reservoir.

## Analytical phase-dispersion reference

For the spatial perturbation, the local effective oscillation frequency provides a phase-dispersion reference for the reduced coherence.

The analytical reference is used to identify the contribution associated with spatially distributed local frequencies. It is not treated as an exact replacement for the complete wave-packet dynamics.

For the reference parameter set,

\begin{equation}
\langle\Omega\rangle
=
8.22\times10^{11}\,\mathrm{s}^{-1},
\qquad
\sigma_\Omega
=
3.66\times10^{11}\,\mathrm{s}^{-1},
\end{equation}

giving the characteristic inhomogeneous-dephasing scale

\begin{equation}
T_2^*
=
\frac{1}{\sigma_\Omega}
\simeq 2.74\,\mathrm{ps}.
\end{equation}

The complete spatial dynamics contains additional effects associated with wave-packet propagation and layer--spatial correlations.

## Software requirements

The numerical scripts are written in Python and use standard scientific-computing packages, including:

- Python 3
- NumPy
- SciPy
- Matplotlib

Individual validation or analysis scripts may use additional standard Python packages. The scripts are intended to be run from the repository directories in which their relative paths are defined.

## Reproducing the calculations

Clone the repository:

```bash
git clone https://github.com/lucasleitefis/trilayer-2deg-qubit-simulation.git
cd trilayer-2deg-qubit-simulation
```

The manuscript-related calculations are organized by physical purpose and figure rather than by the historical names of development scripts.

The recommended workflow is:

1. run the coherent trilayer simulations;
2. reproduce the effective-model comparisons;
3. run the outer-layer detuning and \(U_2/\Delta\) parameter studies;
4. run the spatial-perturbation sweep;
5. reproduce the reduced-state coherence and purity calculations;
6. run the validation scripts;
7. generate the tomography and Bloch-sphere representations.

Numerical output should be compared with the values and trends reported in the manuscript rather than with historical development-script output stored in `archive/`.

## Scope and interpretation

This repository supports the numerical results of the manuscript. It does not constitute an experimental implementation of a trilayer 2DEG qubit.

In particular:

- the coupling \(J=0.25\,\mathrm{meV}\) is a parameter of the theoretical model;
- the Pauli-\(X\) operation is the gate explicitly benchmarked against the complete three-layer dynamics;
- the \(Z\)-axis control is provided by the outer-layer energy imbalance \(\delta U\);
- the \(Z\)--\(X\)--\(Z\) construction illustrates the available control structure, while arbitrary single-qubit operations are not independently benchmarked in the manuscript;
- the spatial perturbation represents a deterministic electrostatic inhomogeneity and is not a microscopic phonon or external-reservoir model.

## Citation

If you use this code or reproduce results from this repository, please cite the associated manuscript and the software release.

**L. B. O. Leite and R. N. Costa Filho**, *A minimal model for coherent dynamics, dephasing and coherence revival: effective trilayer 2DEG qubits* (2026).

Software reference:

**L. B. O. Leite and R. N. Costa Filho**, *trilayer-2deg-qubit-simulation*, version 1.0 (2026), source code for the numerical simulations.

Repository:

https://github.com/lucasleitefis/trilayer-2deg-qubit-simulation

## License

Unless otherwise specified in individual files, the repository contains research code provided for reproducibility of the associated scientific work.
